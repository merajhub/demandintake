import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { lastValueFrom } from 'rxjs';
import { INTAKE } from '../models/intake';
import { Observable } from 'rxjs'
import { environment } from '../../environments/environment';

export interface AccessRequest {
  Id?: number; // Primary Key, auto-incremented, so optional for new requests
  domain: string;
  role: string;
  role_id: string;
  reason: string;
  userid: string;
  request_date?: string;
  approved_by?: string;
  request_status?: number;
  status?: string;
  user_name?: string;
  email?: string;

}


@Injectable({
  providedIn: 'root',
})
export class AdminService {
  actionList: any = {
    AddRequestSafety: false,
    AddRequestClinical: false,
    AddRequestRegulatory: false,
    UpdateRequestSafety: false,
    UpdateRequestClinical: false,
    UpdateRequestRegulatory: false,
    ViewSafetyProjectsStatus: false,
    ViewClinicalProjectsStatus: false,
    ViewRegulatoryProjectsStatus: false,
    UpdateSafetyProjectsStatus: false,
    UpdateClinicalProjectsStatus: false,
    UpdateRegulatoryProjectsStatus: false,
    ApproveSafetyRequest: false,
    ApproveClinicalRequest: false,
    ApproveRegulatoryRequest: false,
  }

  loggedUser = {
    WWID: "",
    UserName: "",
    EmailID: "",
    Roles: "",
    IsSuperAdmin: false,
    PermissionName: [],
    Domain: ""
  }
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  assignAccess() {
    Object.keys(this.actionList).forEach(action_name => {
      let action = this.loggedUser.PermissionName.find(x => x == action_name);
      if (action) {
        this.actionList[action_name] = true;
      } else {

        this.actionList[action_name] = false;
      }
    });
  }

  async getAccessRequesbyUserId(userid: string) {
    let response = this.http.get<any>(`${this.apiUrl}/api/admin/getrequest/${userid}`);
    return await lastValueFrom(response);
  }

  saveReuest(data: any) {
    return this.http.post(`${this.apiUrl}/api/admin`, data, { withCredentials: true });
  }



  // Admin-specific method: Get all pending access requests
  async getPendingAccessRequests() {
    let response = this.http.get<any>(`${this.apiUrl}/api/admin/allrequests`);
    return await lastValueFrom(response);
  }

  async updateAccessRequestStatus(requestId: number, newStatus: number, requestorId: string, approvedBy: string, role_id: string) {
    let reqObj = {
      requestId: requestId,
      status: newStatus,
      requestorId: requestorId,
      approverId: approvedBy,
      roleid: role_id
    }
    let response = this.http.post(`${this.apiUrl}/api/admin/updateRequestStatus`, reqObj, { withCredentials: true });
    return await lastValueFrom(response);
  }

}
