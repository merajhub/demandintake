import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { lastValueFrom } from 'rxjs';
import { INTAKE } from '../models/intake';
import { Observable } from 'rxjs'
import { environment } from '../../environments/environment';
import { AdminService } from './admin-service';
import { DemandRoleService } from '../components/intake/demand-intake/services/demand-role.service';
import { DemandRole } from '../components/intake/demand-intake/models/demand-user.model';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private apiUrl = environment.apiUrl;


  constructor(private http: HttpClient, private adminService: AdminService, private roleService: DemandRoleService) { }

  async getUserDetails() {
    const options = { withCredentials: true };
    let response = this.http.get(this.apiUrl + "/getuserdetails", options);
    let resp: any = await lastValueFrom(response);
    this.adminService.loggedUser.WWID = resp.user.userid;
    this.adminService.loggedUser.UserName = resp.user.username;
    this.adminService.loggedUser.EmailID = resp.user.useremail;
    this.adminService.loggedUser.Roles = resp.user.roles;
    this.adminService.loggedUser.IsSuperAdmin = resp.user.roles.find((role: any) => role.id == 1) ? true : false;
    this.adminService.loggedUser.PermissionName = resp.user.permissions.split(",");
    this.adminService.loggedUser.Domain = resp.user.domain || '';
    this.adminService.assignAccess();

    // Set DemandRoleService currentUser from the API user
    const primaryRole = resp.user.roles?.[0]?.name as DemandRole || 'User';
    this.roleService.switchUser({
      id: resp.user.userid,
      name: resp.user.username,
      email: resp.user.useremail,
      role: primaryRole,
      domain: resp.user.domain || ''
    });
  }

  //*********Intake  ************/

  // Method to get all intake forms
  async getAllIntakeForms() {
    let url = "";
    url = `${this.apiUrl}/api/intake/all`;
    let response = this.http.get<INTAKE[]>(url);
    return await lastValueFrom(response);
  }

  async getMyIntakeFormsAsAdmin() {
    let url = "";
    url = `${this.apiUrl}/api/intake/myrequests/${this.adminService.loggedUser.WWID}`;
    let response = this.http.get<INTAKE[]>(url);
    return await lastValueFrom(response);
  }

  async getMyIntakeFormsAsUser() {
    let url = "";
    url = `${this.apiUrl}/api/intake/myrequests/${this.adminService.loggedUser.WWID}`;
    return this.http.get<INTAKE[]>(url);
  }

  getRecordById(id: string): Observable<INTAKE> {
    return this.http.get<INTAKE>(`${this.apiUrl}/api/intake/${id}`);
  }


  // Method to save the intake form data
  saveIntakeForm(record: INTAKE, attachments: File | null = null): Observable<any> {
    record["requestor_wwid"] = this.adminService.loggedUser.WWID;
    record["requestorEmail"] = this.adminService.loggedUser.EmailID;
    var data = new FormData()
    if (attachments) {
      data.append('files', attachments)
    }
    data.append("record", JSON.stringify(record));
    return this.http.post(`${this.apiUrl}/api/intake`, data, { withCredentials: true });
  }

  updateStatus(requestId: string, status: string): Observable<any> {
    const reqOBJ = {
      requestId,
      status
    };

    return this.http.post(`${this.apiUrl}/api/intake/updatestatus`, reqOBJ);
  }


  updateRecord(_requestId: string, updateData: any, attachments: File | null = null): Observable<any> {

    updateData["requestorEmail"] = this.adminService.loggedUser.EmailID;
    var data = new FormData();
    if (attachments) {
      data.append('files', attachments)
    }
    const { requestId, ...newobj } = updateData;
    data.append("rowdata", JSON.stringify(newobj));
    data.append("requestId", requestId);

    let reqOBJ = {
      requestId: _requestId,
      rowdata: newobj,
      whereclause: " "
    }


    return this.http.post(`${this.apiUrl}/api/intake/update`,  data, { withCredentials: true });
  }

  getSignedURL(filename: string, requestId: string) {
    return this.http.post(`${this.apiUrl}/getsignedurl`, { requestId: requestId, filename: filename }, { withCredentials: true });
  }

  //*********Intake Ends ************/

  //*********Tracking ************/

  getDomainRequestCount(): Observable<INTAKE[]> {
    let url = "";
    url = `${this.apiUrl}/api/tracking/domaincount`;
    return this.http.get<any[]>(url);
  }

  getrackingtRecordsByDomain(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/tracking/getdomainrequests/${id}`);
  }

  getTrackingStatusById(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/tracking/${id}`);
  }

  saveIntakeStatus(record: INTAKE): Observable<any> {
    record["requestor_wwid"] = this.adminService.loggedUser.WWID;
    record["requestorEmail"] = this.adminService.loggedUser.EmailID;
    var data = new FormData()
    data.append("record", JSON.stringify(record));
    //return this.http.post(`${this.apiUrl}/api/tracking`, data, { withCredentials: true });

    return this.http.post(`${this.apiUrl}/api/tracking`, record);
  }


  updateTracking(_requestId: string, updateData: any): Observable<any> {

    updateData["requestorEmail"] = this.adminService.loggedUser.EmailID;
    updateData["userWWID"] = this.adminService.loggedUser.WWID;
    const { requestId, ...newobj } = updateData;
    let reqOBJ = {
      requestId: _requestId,
      rowdata: newobj,
      whereclause: " "
    }


    return this.http.post(`${this.apiUrl}/api/tracking/update`, reqOBJ);
  }


  getTrackingAuditById(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/tracking/audit/${id}`);
  }


  //*********Tracking Ends************/


  //*********reporting starts ***************/


  getReportingChartData(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/reporting/chart`);
  }

  //*********reporting ends ***************/





}
