
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DemandTrackingRecord, DemandTrackingSavePayload, DemandTrackingAuditRecord } from '../models/demand-tracking.models';
import { environment } from '../../../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DemandTrackingApiService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  /** Fetch demand tracking insights summary for charts */
  getTrackingInsightsSummary(): Observable<{ status: boolean; data: any[] }> {
    return this.http.get<{ status: boolean; data: any[] }>(
      `${this.apiUrl}/api/mysql-demand-tracking-insights/summary`
    );
  }

  /** Fetch all approved requests with tracking data */
  getApprovedRequests(): Observable<{ status: boolean; data: DemandTrackingRecord[] }> {
    return this.http.get<{ status: boolean; data: DemandTrackingRecord[] }>(
      `${this.apiUrl}/api/mysql-demand-tracking`
    );
  }

  /** Fetch single tracking record by request ID */
  getTrackingByRequestId(requestId: string): Observable<{ status: boolean; data: DemandTrackingRecord }> {
    return this.http.get<{ status: boolean; data: DemandTrackingRecord }>(
      `${this.apiUrl}/api/mysql-demand-tracking/${requestId}`
    );
  }

  /** Fetch tracking audit history */
  getTrackingAudit(requestId: string): Observable<{ status: boolean; data: DemandTrackingAuditRecord[] }> {
    return this.http.get<{ status: boolean; data: DemandTrackingAuditRecord[] }>(
      `${this.apiUrl}/api/mysql-demand-tracking/audit/${requestId}`
    );
  }

  /** Create or update tracking record */
  saveTracking(payload: DemandTrackingSavePayload): Observable<{ status: boolean; message: string }> {
    return this.http.post<{ status: boolean; message: string }>(
      `${this.apiUrl}/api/mysql-demand-tracking`,
      payload
    );
  }

  /** Fetch status distribution for demand tracking insights */
  getTrackingStatusSummary(): Observable<{ status: boolean; data: any[] }> {
    return this.http.get<{ status: boolean; data: any[] }>(
      `${this.apiUrl}/api/mysql-demand-tracking-insights/status`
    );
  }

  /** Fetch domain breakdown for demand tracking insights */
  getTrackingDomainSummary(): Observable<{ status: boolean; data: any[] }> {
    return this.http.get<{ status: boolean; data: any[] }>(
      `${this.apiUrl}/api/mysql-demand-tracking-insights/domain`
    );
  }

  /** Fetch timeline trends for demand tracking insights */
  getTrackingTimelineSummary(): Observable<{ status: boolean; data: any[] }> {
    return this.http.get<{ status: boolean; data: any[] }>(
      `${this.apiUrl}/api/mysql-demand-tracking-insights/timeline`
    );
  }

  /** Fetch all metrics for demand tracking insights */
  getAllTrackingInsights(): Observable<{ status: boolean; data: any }> {
    return this.http.get<{ status: boolean; data: any }>(
      `${this.apiUrl}/api/mysql-demand-tracking-insights/all-metrics`
    );
  }
}
