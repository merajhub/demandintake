import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { DemandIntakeWorkflowService } from '../services/demand-intake-workflow.service';
import { DemandRoleService } from '../services/demand-role.service';
import { DemandApiService } from '../services/demand-api.service';
import {
  ProjectOverview,
  RequestorInformation,
  ProjectSpecification,
  ManagementNotes,
} from '../models/demand-intake.models';

@Component({
  selector: 'app-demand-intake-form',
  standalone: false,
  templateUrl: './demand-intake-form.html',
  styleUrl: './demand-intake-form.css',
})
export class DemandIntakeForm implements OnInit {
  @Input() requestId: string | null = null;

  // --- Project Overview ---
  formData: ProjectOverview = {
    projectTitle: '',
    domain: '',
    estimatedBudgetUsd: '',
    typeOfRequest: '',
    priorityLevel: '',
    dateOfSubmission: null,
    estimatedStartDate: null,
    estimatedCompletionDate: null,
  };

  // --- Requestor Information ---
  requestorData: RequestorInformation = {
    requestorName: '',
    department: '',
    contactEmail: '',
    contactPhone: '',
    projectManager: '',
  };

  // --- Project Specification ---
  specData: ProjectSpecification = {
    targetUsers: '',
    platform: '',
    technologyPreference: '',
    projectDescription: '',
    projectGoals: '',
    businessProblem: '',
    expectedOutcome: '',
    resourceRequirements: '',
    dependencies: '',
    complianceRequirements: '',
    attachments: [],
  };

  // --- Management & Notes ---
  mgmtData: ManagementNotes = {
    stakeholders: '',
    risks: '',
    reviewNotes: '',
    additionalNotes: '',
  };

  missingProperties: string[] = [];
  formSubmitted = false;
  isReadOnly = false;
  isLoading = false;
  uploadedFileNames: string[] = [];

  domainOptions = [
    { label: 'Safety', value: 'Safety' },
    { label: 'Clinical', value: 'Clinical' },
    { label: 'Regulatory', value: 'Regulatory' },
  ];

  requestTypes = [
    { label: 'New Development', value: 'New Development' },
    { label: 'Enhancement', value: 'Enhancement' },
  ];

  priorityOptions = [
    { label: 'Low', value: 'Low' },
    { label: 'Medium', value: 'Medium' },
    { label: 'High', value: 'High' },
  ];

  platformOptions = [
    { label: 'Web', value: 'Web' },
    { label: 'Mobile', value: 'Mobile' },
    { label: 'Desktop', value: 'Desktop' },
    { label: 'Cloud', value: 'Cloud' },
    { label: 'Cross-Platform', value: 'Cross-Platform' },
  ];

  technologyOptions = [
    { label: 'Angular', value: 'Angular' },
    { label: 'React', value: 'React' },
    { label: '.NET', value: '.NET' },
    { label: 'Java', value: 'Java' },
    { label: 'Python', value: 'Python' },
    { label: 'No Preference', value: 'No Preference' },
  ];

  constructor(
    private workflowService: DemandIntakeWorkflowService,
    public roleService: DemandRoleService,
    private apiService: DemandApiService,
    private messageService: MessageService,
    private router: Router,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const state = this.workflowService.current;
    if (state.projectOverview) {
      this.formData = {
        ...state.projectOverview,
        dateOfSubmission: this.toDate(state.projectOverview.dateOfSubmission),
        estimatedStartDate: this.toDate(state.projectOverview.estimatedStartDate),
        estimatedCompletionDate: this.toDate(state.projectOverview.estimatedCompletionDate),
      };
    }
    if (state.requestorInformation) {
      this.requestorData = { ...state.requestorInformation };
    }
    if (state.projectSpecification) {
      this.specData = { ...state.projectSpecification, attachments: state.projectSpecification.attachments || [] };
    }
    if (state.managementNotes) {
      this.mgmtData = { ...state.managementNotes };
    }

    // Read-only unless the user can edit: Users can edit their own drafts;
    // Scrub/Committee members can edit a draft they created.
    this.isReadOnly = !this.roleService.canEditIntakeForm(state.status, state.createdBy);
  }

  /** Convert an ISO date string (or Date) to a Date object for p-datepicker */
  private toDate(value: Date | string | null | undefined): Date | null {
    if (!value) return null;
    if (value instanceof Date) return value;
    const parsed = new Date(value);
    return isNaN(parsed.getTime()) ? null : parsed;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      const files = Array.from(input.files);
      this.specData.attachments = [...this.specData.attachments, ...files];
      this.uploadedFileNames = this.specData.attachments.map(f => f.name);
      input.value = ''; // reset so same file can be re-selected
    }
  }

  removeFile(index: number): void {
    this.specData.attachments.splice(index, 1);
    this.uploadedFileNames = this.specData.attachments.map(f => f.name);
  }

  private validate(): boolean {
    this.missingProperties = [];

    // Project Overview validations
    if (!this.formData.projectTitle) this.missingProperties.push('projectTitle');
    if (!this.formData.domain) this.missingProperties.push('domain');
    if (!this.formData.estimatedBudgetUsd) this.missingProperties.push('estimatedBudgetUsd');
    if (!this.formData.typeOfRequest) this.missingProperties.push('typeOfRequest');
    if (!this.formData.priorityLevel) this.missingProperties.push('priorityLevel');
    if (!this.formData.dateOfSubmission) this.missingProperties.push('dateOfSubmission');
    if (!this.formData.estimatedStartDate) this.missingProperties.push('estimatedStartDate');
    if (!this.formData.estimatedCompletionDate) this.missingProperties.push('estimatedCompletionDate');

    // Requestor Information validations
    if (!this.requestorData.requestorName) this.missingProperties.push('requestorName');
    if (!this.requestorData.department) this.missingProperties.push('department');
    if (!this.requestorData.contactEmail) this.missingProperties.push('contactEmail');
    if (!this.requestorData.contactPhone) this.missingProperties.push('contactPhone');
    if (!this.requestorData.projectManager) this.missingProperties.push('projectManager');

    // Project Specification validations
    if (!this.specData.projectDescription) this.missingProperties.push('projectDescription');
    if (!this.specData.projectGoals) this.missingProperties.push('projectGoals');
    if (!this.specData.businessProblem) this.missingProperties.push('businessProblem');

    return this.missingProperties.length === 0;
  }

  private buildPayload(status: string): any {
    return {
      createdBy: this.roleService.userId,
      createdByName: this.roleService.userName,
      status,
      projectOverview: this.formData,
      requestorInformation: this.requestorData,
      projectSpecification: { ...this.specData, attachments: [] }, // Files handled separately
      managementNotes: this.mgmtData,
    };
  }

  private saveAllSections(): void {
    this.workflowService.saveProjectOverview(this.formData);
    this.workflowService.saveRequestorInformation(this.requestorData);
    this.workflowService.saveProjectSpecification(this.specData);
    this.workflowService.saveManagementNotes(this.mgmtData);
  }

  onSaveDraft(): void {
    this.formSubmitted = true;
    if (!this.validate()) {
      this.messageService.add({
        severity: 'error',
        summary: 'Validation Failed',
        detail: 'Please fill in all required fields before saving.',
        life: 5000,
      });
      return;
    }

    this.saveAllSections();
    this.isLoading = true;

    const payload = this.buildPayload('draft');

    if (this.requestId) {
      this.apiService.updateRequest(this.requestId, payload).subscribe({
        next: () => {
          this.isLoading = false;
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'success',
            summary: 'Draft Saved',
            detail: 'Your draft has been saved successfully.',
            life: 3000,
          });
          setTimeout(() => this.navigateToList(), 1500);
        },
        error: (err) => {
          this.isLoading = false;
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'error',
            summary: 'Save Failed',
            detail: 'Failed to save draft. Please try again.',
            life: 5000,
          });
          console.error('Save draft failed:', err);
        },
      });
    } else {
      this.apiService.createRequest(payload).subscribe({
        next: () => {
          this.isLoading = false;
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'success',
            summary: 'Draft Saved',
            detail: 'Your draft has been saved successfully.',
            life: 3000,
          });
          setTimeout(() => this.navigateToList(), 1500);
        },
        error: (err) => {
          this.isLoading = false;
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'error',
            summary: 'Save Failed',
            detail: 'Failed to create draft. Please try again.',
            life: 5000,
          });
          console.error('Create draft failed:', err);
        },
      });
    }
  }

  onSubmit(): void {
    this.formSubmitted = true;
    if (!this.validate()) {
      this.messageService.add({
        severity: 'error',
        summary: 'Validation Failed',
        detail: 'Please fill in all required fields before submitting.',
        life: 5000,
      });
      return;
    }

    this.saveAllSections();
    this.isLoading = true;

    const payload = this.buildPayload('submitted');

    if (this.requestId) {
      this.apiService.updateRequest(this.requestId, payload).subscribe({
        next: () => {
          this.isLoading = false;
          this.workflowService.advanceTo('SCRUB_TEAM', 'in_review');
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'success',
            summary: 'Request Submitted',
            detail: 'Your request has been submitted successfully.',
            life: 3000,
          });
          setTimeout(() => this.navigateToList(), 1500);
        },
        error: (err) => {
          this.isLoading = false;
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'error',
            summary: 'Submission Failed',
            detail: 'Failed to submit request. Please try again.',
            life: 5000,
          });
          console.error('Submit failed:', err);
        },
      });
    } else {
      this.apiService.createRequest(payload).subscribe({
        next: () => {
          this.isLoading = false;
          this.workflowService.advanceTo('SCRUB_TEAM', 'in_review');
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'success',
            summary: 'Request Submitted',
            detail: 'Your request has been submitted successfully.',
            life: 3000,
          });
          setTimeout(() => this.navigateToList(), 1500);
        },
        error: (err) => {
          this.isLoading = false;
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'error',
            summary: 'Submission Failed',
            detail: 'Failed to submit request. Please try again.',
            life: 5000,
          });
          console.error('Submit failed:', err);
        },
      });
    }
  }

  onCancel(): void {
    this.navigateToList();
  }

  private navigateToList(): void {
    this.workflowService.resetState();
    this.router.navigate(['/intake/demand-intake'], { skipLocationChange: true });
  }
}
