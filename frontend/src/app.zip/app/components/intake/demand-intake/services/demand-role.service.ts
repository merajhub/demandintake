import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { DemandUser, DemandRole } from '../models/demand-user.model';

@Injectable({
  providedIn: 'root',
})
export class DemandRoleService {
  private currentUserSubject = new BehaviorSubject<DemandUser | null>(null);
  currentUser$ = this.currentUserSubject.asObservable();

  get currentUser(): DemandUser | null {
    return this.currentUserSubject.getValue();
  }

  get role(): DemandRole | null {
    return this.currentUser?.role ?? null;
  }

  get userId(): string {
    return this.currentUser?.id ?? '';
  }

  get userName(): string {
    return this.currentUser?.name ?? '';
  }

  get domain(): string {
    return this.currentUser?.domain ?? '';
  }

  switchUser(user: DemandUser): void {
    this.currentUserSubject.next(user);
  }

  isUser(): boolean {
    return this.role === 'User';
  }

  isScrubMember(): boolean {
    return this.role === 'Scrub_member';
  }

  isCommitteeMember(): boolean {
    return this.role === 'Committee_member';
  }

  /** True when the logged-in user is the original creator of the request */
  isRequestOwner(createdBy?: string): boolean {
    return !createdBy || createdBy === this.userId;
  }

  // Check if user can edit the intake form (Step 1)
  // Users can edit their own draft requests.
  // Scrub/Committee members can edit a request in draft status only if they created it.
  canEditIntakeForm(requestStatus: string, createdBy?: string): boolean {
    if (this.isUser()) {
      return requestStatus === 'draft';
    }
    if (this.isScrubMember() || this.isCommitteeMember()) {
      return requestStatus === 'draft' && this.isRequestOwner(createdBy);
    }
    return false;
  }

  /** True when a scrub/committee member can respond to clarification on their own submitted request */
  canRespondToScrubClarification(requestStatus: string, createdBy?: string): boolean {
    if (this.isUser()) return requestStatus === 'clarification_requested';
    return (this.isScrubMember() || this.isCommitteeMember())
      && requestStatus === 'clarification_requested'
      && this.isRequestOwner(createdBy);
  }

  canRespondToCommitteeClarification(requestStatus: string, createdBy?: string): boolean {
    if (this.isUser()) return requestStatus === 'committee_clarification_requested';
    return (this.isScrubMember() || this.isCommitteeMember())
      && requestStatus === 'committee_clarification_requested'
      && this.isRequestOwner(createdBy);
  }
}
