import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {
  WorkflowState,
  StepId,
  WorkflowStatus,
  ProjectOverview,
  RequestorInformation,
  ProjectSpecification,
  ManagementNotes,
  ScrubReview,
  CommitteeReview,
  STEP_INDEX,
} from '../models/demand-intake.models';

@Injectable({
  providedIn: 'root',
})
export class DemandIntakeWorkflowService {
  private readonly initialState: WorkflowState = {
    activeStep: 'INTAKE_FORM',
    status: 'draft',
  };

  private stateSubject = new BehaviorSubject<WorkflowState>({ ...this.initialState });
  state$ = this.stateSubject.asObservable();

  get current(): WorkflowState {
    return this.stateSubject.getValue();
  }

  get activeStepIndex(): number {
    return STEP_INDEX[this.current.activeStep];
  }

  saveProjectOverview(data: ProjectOverview): void {
    this.stateSubject.next({
      ...this.current,
      projectOverview: { ...data },
    });
  }

  saveRequestorInformation(data: RequestorInformation): void {
    this.stateSubject.next({
      ...this.current,
      requestorInformation: { ...data },
    });
  }

  saveProjectSpecification(data: ProjectSpecification): void {
    this.stateSubject.next({
      ...this.current,
      projectSpecification: { ...data },
    });
  }

  saveManagementNotes(data: ManagementNotes): void {
    this.stateSubject.next({
      ...this.current,
      managementNotes: { ...data },
    });
  }

  saveScrubReview(data: ScrubReview): void {
    this.stateSubject.next({
      ...this.current,
      scrubReview: { ...data },
    });
  }

  saveCommitteeReview(data: CommitteeReview): void {
    this.stateSubject.next({
      ...this.current,
      committeeReview: { ...data },
    });
  }

  setCreatedBy(createdBy: string): void {
    this.stateSubject.next({
      ...this.current,
      createdBy,
    });
  }

  advanceTo(step: StepId, status: WorkflowStatus): void {
    this.stateSubject.next({
      ...this.current,
      activeStep: step,
      status,
    });
  }

  setStep(step: StepId): void {
    this.stateSubject.next({
      ...this.current,
      activeStep: step,
    });
  }

  resetState(): void {
    this.stateSubject.next({ ...this.initialState });
  }
}
