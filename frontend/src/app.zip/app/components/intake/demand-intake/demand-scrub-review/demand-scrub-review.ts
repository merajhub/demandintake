import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { DemandIntakeWorkflowService } from '../services/demand-intake-workflow.service';
import { DemandRoleService } from '../services/demand-role.service';
import { DemandApiService } from '../services/demand-api.service';

interface ConversationMessage {
  from: string;
  fromName: string;
  role: string;
  remarks: string;
  createdAt: string;
  attachment?: {
    originalName: string;
    storedName: string;
    size: number;
    mimeType: string;
  };
}

interface ReviewThread {
  reviewerId: string;
  reviewerName: string;
  decision: string;
  conversation: ConversationMessage[];
}

@Component({
  selector: 'app-demand-scrub-review',
  standalone: false,
  templateUrl: './demand-scrub-review.html',
  styleUrl: './demand-scrub-review.css',
})
export class DemandScrubReview implements OnInit {
  @Input() requestId: string | null = null;

  reviewThreads: ReviewThread[] = [];
  collapsedThreads = new Set<string>(); // track collapsed thread reviewerIds
  newRemarks = '';
  clarificationRemarks: { [reviewerId: string]: string } = {}; // separate clarification remarks per reviewer thread
  decision = '';
  missingProperties: string[] = [];
  formSubmitted = false;
  isReadOnly = false;
  canEditRemarks = false;
  canSubmitterRespond = false;
  selectedFile: File | null = null;
  selectedFileName = '';
  isLoading = false;
  isSaving = false;

  decisionOptions = [
    { label: 'Needs Clarification', value: 'Needs Clarification' },
    { label: 'Approved', value: 'Approved' },
    { label: 'Deferred', value: 'Deferred' },
    { label: 'Rejected', value: 'Rejected' },
  ];

  constructor(
    private workflowService: DemandIntakeWorkflowService,
    public roleService: DemandRoleService,
    private apiService: DemandApiService,
    private messageService: MessageService,
    private router: Router,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const state = this.workflowService.current;
    const requestDomain = state.projectOverview?.domain || '';
    const reviewerDomain = this.roleService.domain;
    const domainMatch = !reviewerDomain || reviewerDomain === requestDomain;

    // Scrub members can only act when request is in scrub phase AND domain matches
    // AND they did not create the request themselves
    const scrubPhaseStatuses = ['submitted', 'in_review', 'clarification_requested'];
    const isOwnRequest = state.createdBy === this.roleService.userId;
    this.canEditRemarks = this.roleService.isScrubMember() && scrubPhaseStatuses.includes(state.status) && domainMatch && !isOwnRequest;
    this.isReadOnly = !this.canEditRemarks && !this.roleService.isUser() && !isOwnRequest;
    this.canSubmitterRespond = this.roleService.canRespondToScrubClarification(state.status, state.createdBy);

    if (this.requestId) {
      this.loadReviews();
    }
  }

  loadReviews(): void {
    this.isLoading = true;
    this.apiService.getReviews(this.requestId!, 'scrub').subscribe({
      next: (reviews) => {
        this.reviewThreads = reviews.map(r => ({
          reviewerId: r.reviewerId,
          reviewerName: r.reviewerName,
          decision: r.decision || '',
          conversation: r.conversation || [],
        }));

        // If the logged-in scrub member doesn't have a thread yet, create an empty placeholder
        if (this.canEditRemarks) {
          const myThread = this.reviewThreads.find(t => t.reviewerId === this.roleService.userId);
          if (myThread) {
            this.decision = myThread.decision;
          } else {
            this.reviewThreads.unshift({
              reviewerId: this.roleService.userId,
              reviewerName: this.roleService.userName,
              decision: '',
              conversation: [],
            });
          }
        }

        // Sort: logged-in user's thread first, then the rest in original order
        const myId = this.roleService.userId;
        this.reviewThreads.sort((a, b) => {
          if (a.reviewerId === myId) return -1;
          if (b.reviewerId === myId) return 1;
          return 0;
        });

        // Collapse all threads except the logged-in user's
        this.collapsedThreads.clear();
        this.reviewThreads.forEach(t => {
          if (t.reviewerId !== myId) {
            this.collapsedThreads.add(t.reviewerId);
          }
        });

        this.isLoading = false;
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Failed to load scrub reviews:', err);
        this.isLoading = false;
      },
    });
  }

  /** Toggle collapse/expand of a thread */
  toggleThread(thread: ReviewThread): void {
    if (this.collapsedThreads.has(thread.reviewerId)) {
      this.collapsedThreads.delete(thread.reviewerId);
    } else {
      this.collapsedThreads.add(thread.reviewerId);
    }
  }

  /** Check if a thread is collapsed */
  isCollapsed(thread: ReviewThread): boolean {
    return this.collapsedThreads.has(thread.reviewerId);
  }

  /** Check if this thread belongs to the logged-in user */
  isMyThread(thread: ReviewThread): boolean {
    return thread.reviewerId === this.roleService.userId;
  }

  /** Check if this thread still has pending clarification (last message is NOT from requestor) */
  isClarificationThread(thread: ReviewThread): boolean {
    return thread.decision === 'Needs Clarification' && !this.isClarificationProvided(thread);
  }

  /** Check if requestor has already replied (last message is from User) */
  isClarificationProvided(thread: ReviewThread): boolean {
    if (!thread.conversation || thread.conversation.length === 0) return false;
    const lastMsg = thread.conversation[thread.conversation.length - 1];
    return lastMsg.role === 'User';
  }

  /** Check if the logged-in scrub member's own thread is in "Clarification Required" state */
  isMyThreadAwaitingClarification(thread: ReviewThread): boolean {
    return this.isMyThread(thread) && this.isClarificationThread(thread);
  }

  /** Check if the logged-in scrub member's own thread has no decision yet (first review) */
  isMyThreadNew(thread: ReviewThread): boolean {
    return this.isMyThread(thread) && !this.isMyThreadAwaitingClarification(thread);
  }

  /**
   * Compute the effective status label for a thread:
   * - If decision is 'Needs Clarification' and last message is from requestor → "In Review"
   * - If decision is 'Needs Clarification' and last message is from reviewer → "Clarification Required"
   * - Otherwise show the raw decision (e.g. "No Questions")
   */
  getThreadStatus(thread: ReviewThread): string {
    if (thread.decision === 'Needs Clarification') {
      return this.isClarificationProvided(thread) ? 'In Review' : 'Clarification Required';
    }
    if (thread.decision === 'No Questions') return 'Approved'; // Backward compatibility
    return thread.decision;
  }

  /**
   * Return the CSS class for the thread status badge
   */
  getThreadStatusClass(thread: ReviewThread): string {
    const status = this.getThreadStatus(thread);
    switch (status) {
      case 'In Review': return 'badge-in-review';
      case 'Clarification Required': return 'badge-clarification';
      case 'Approved': return 'badge-approved';
      case 'Deferred': return 'badge-deferred';
      case 'Rejected': return 'badge-rejected';
      case 'No Questions': return 'badge-approved';
      default: return '';
    }
  }

  onSubmitReview(): void {
    this.formSubmitted = true;
    this.missingProperties = [];

    if (!this.decision) {
      this.missingProperties.push('decision');
    }
    if (!this.newRemarks) {
      this.missingProperties.push('newRemarks');
    }
    if (this.decision === 'Needs Clarification' && !this.newRemarks) {
      this.missingProperties.push('newRemarks');
    }
    if (this.missingProperties.length > 0) return;

    this.isSaving = true;

    const payload = {
      requestId: this.requestId,
      reviewType: 'scrub',
      reviewerId: this.roleService.userId,
      reviewerName: this.roleService.userName,
      decision: this.decision,
      remarks: this.newRemarks,
      from: this.roleService.userId,
      fromName: this.roleService.userName,
      role: 'Scrub_member',
    };

    this.apiService.createReview(payload).subscribe({
      next: () => {
        if (this.requestId) {
          if (this.decision === 'Needs Clarification') {
            // Directly set to clarification_requested
            this.apiService.updateRequestStatus(this.requestId, 'clarification_requested').subscribe({
              next: () => {
                this.isSaving = false;
                this.cdRef.detectChanges();
                this.messageService.add({
                  severity: 'success',
                  summary: 'Review Submitted',
                  detail: 'Clarification has been requested from the requestor.',
                  life: 3000,
                });
                setTimeout(() => this.navigateToList(), 1500);
              },
              error: (err) => {
                this.isSaving = false;
                this.cdRef.detectChanges();
                this.messageService.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: 'Failed to update request status. Please try again.',
                  life: 5000,
                });
                console.error('Status update failed:', err);
              },
            });
          } else {
            // "Approved", "Deferred", "Rejected" — check all threads
            this.apiService.getReviews(this.requestId!, 'scrub').subscribe({
              next: (allReviews) => {
                const allApproved = allReviews.length > 0 &&
                  allReviews.every(r => r.decision === 'Approved' || r.decision === 'No Questions');

                const anyRejected = allReviews.some(r => r.decision === 'Rejected');
                const anyDeferred = allReviews.some(r => r.decision === 'Deferred');

                let newStatus = 'in_review';
                let newStage = undefined;

                if (allApproved) {
                    newStatus = 'committee_review';
                    newStage = 'committee';
                } else if (anyRejected) {
                    newStatus = 'rejected';
                } else if (anyDeferred) {
                    newStatus = 'deferred';
                }

                this.apiService.updateRequestStatus(this.requestId!, newStatus, newStage).subscribe({
                  next: () => {
                    this.isSaving = false;
                    this.cdRef.detectChanges();
                    this.messageService.add({
                      severity: 'success',
                      summary: 'Review Submitted',
                      detail: 'Your review has been submitted successfully.',
                      life: 3000,
                    });
                    setTimeout(() => this.navigateToList(), 1500);
                  },
                  error: (err) => {
                    this.isSaving = false;
                    this.cdRef.detectChanges();
                    this.messageService.add({
                      severity: 'error',
                      summary: 'Error',
                      detail: 'Failed to update request status. Please try again.',
                      life: 5000,
                    });
                    console.error('Status update failed:', err);
                  },
                });
              },
              error: (err) => {
                this.isSaving = false;
                this.cdRef.detectChanges();
                this.messageService.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: 'Failed to verify reviews. Please try again.',
                  life: 5000,
                });
                console.error('Failed to check all reviews:', err);
              },
            });
          }
        }
      },
      error: (err) => {
        this.isSaving = false;
        this.cdRef.detectChanges();
        this.messageService.add({
          severity: 'error',
          summary: 'Submission Failed',
          detail: 'Failed to submit your review. Please try again.',
          life: 5000,
        });
        console.error('Create review failed:', err);
      },
    });
  }

  onSubmitClarification(thread: ReviewThread): void {
    this.formSubmitted = true;
    this.missingProperties = [];

    const threadRemarks = this.clarificationRemarks[thread.reviewerId];
    if (!threadRemarks || threadRemarks.trim() === '') {
      this.missingProperties.push('clarification_' + thread.reviewerId);
      return;
    }

    this.isSaving = true;

    // Append requestor's reply to that reviewer's thread
    const payload: any = {
      requestId: this.requestId,
      reviewType: 'scrub',
      reviewerId: thread.reviewerId,
      reviewerName: thread.reviewerName,
      remarks: threadRemarks,
      from: this.roleService.userId,
      fromName: this.roleService.userName,
      role: 'User',
    };

    const submitObs = this.selectedFile
      ? this.apiService.createReviewWithFile(payload, this.selectedFile)
      : this.apiService.createReview(payload);

    submitObs.subscribe({
      next: () => {
        if (this.requestId) {
          // Temporarily treat this thread as replied to for the clarification check
          const originalConversationLength = thread.conversation ? thread.conversation.length : 0;
          if (!thread.conversation) thread.conversation = [];

          thread.conversation.push({
            role: 'User',
            remarks: threadRemarks,
            createdAt: new Date().toISOString(),
            from: this.roleService.userId,
            fromName: this.roleService.userName
          });

          // Check if there are ANY OTHER threads that still require clarification
          const othersWaiting = this.reviewThreads.some(t =>
             this.isClarificationThread(t)
          );

          if (!othersWaiting) {
            // All clarifications have been provided, change request status to in_review
            this.apiService.updateRequestStatus(this.requestId, 'in_review').subscribe({
              next: () => {
                this.isSaving = false;
                this.selectedFile = null;
                this.selectedFileName = '';
                this.cdRef.detectChanges();
                this.messageService.add({
                  severity: 'success',
                  summary: 'Clarification Submitted',
                  detail: 'Your clarification has been submitted successfully.',
                  life: 3000,
                });
                setTimeout(() => this.navigateToList(), 1500);
              },
              error: (err) => {
                this.isSaving = false;
                this.cdRef.detectChanges();
                this.messageService.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: 'Failed to update request status. Please try again.',
                  life: 5000,
                });
                console.error('Status update failed:', err);
              },
            });
          } else {
             // Status remains unchanged (clarification_requested), just show success and reload
             this.isSaving = false;
             this.selectedFile = null;
             this.selectedFileName = '';
             this.clarificationRemarks[thread.reviewerId] = '';
             this.cdRef.detectChanges();
             this.messageService.add({
                severity: 'success',
                summary: 'Clarification Submitted',
                detail: 'Clarification sent. ' + this.reviewThreads.filter(t => this.isClarificationThread(t)).length + ' more reviewer(s) waiting for clarification.',
                life: 3000,
             });
             this.loadReviews();
          }
        }
      },
      error: (err) => {
        this.isSaving = false;
        this.cdRef.detectChanges();
        this.messageService.add({
          severity: 'error',
          summary: 'Submission Failed',
          detail: 'Failed to submit clarification. Please try again.',
          life: 5000,
        });
        console.error('Submit clarification failed:', err);
      },
    });
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      this.selectedFileName = file.name;
    }
  }

  removeFile(): void {
    this.selectedFile = null;
    this.selectedFileName = '';
  }

  getAttachmentUrl(storedName: string): string {
    return this.apiService.getAttachmentUrl(storedName);
  }

  formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  /** Scrub member adds follow-up remarks to their own thread (no decision change, no status change) */
  onAddFollowUpRemarks(): void {
    this.formSubmitted = true;
    this.missingProperties = [];

    if (!this.newRemarks) {
      this.missingProperties.push('newRemarks');
      return;
    }

    this.isSaving = true;

    const payload = {
      requestId: this.requestId,
      reviewType: 'scrub',
      reviewerId: this.roleService.userId,
      reviewerName: this.roleService.userName,
      decision: this.decision, // keep existing decision
      remarks: this.newRemarks,
      from: this.roleService.userId,
      fromName: this.roleService.userName,
      role: 'Scrub_member',
    };

    this.apiService.createReview(payload).subscribe({
      next: () => {
        this.isSaving = false;
        this.newRemarks = '';
        this.missingProperties = [];
        this.formSubmitted = false;
        this.messageService.add({
          severity: 'success',
          summary: 'Remarks Added',
          detail: 'Your follow-up remarks have been added successfully.',
          life: 3000,
        });
        // Reload the thread to show the new message
        this.loadReviews();
      },
      error: (err) => {
        this.isSaving = false;
        this.cdRef.detectChanges();
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to add follow-up remarks. Please try again.',
          life: 5000,
        });
        console.error('Add follow-up remarks failed:', err);
      },
    });
  }

  formatDate(dateStr: string): string {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  }

  getRoleLabel(role: string): string {
    switch (role) {
      case 'Scrub_member': return 'Scrub Member';
      case 'Committee_member': return 'Committee Member';
      case 'User': return 'Requestor';
      default: return role;
    }
  }

  getInitials(name: string): string {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  }

  onCancel(): void {
    this.navigateToList();
  }

  private navigateToList(): void {
    this.workflowService.resetState();
    this.router.navigate(['/intake/demand-intake'], { skipLocationChange: true });
  }
}
