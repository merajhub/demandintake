export type StepId = 'INTAKE_FORM' | 'SCRUB_TEAM' | 'COMMITTEE_TEAM' | 'APPROVED';

export type WorkflowStatus =
  | 'draft'
  | 'submitted'
  | 'in_review'
  | 'clarification_requested'
  | 'committee_review'
  | 'committee_clarification_requested'
  | 'approved'
  | 'rejected'
  | 'deferred';

export interface ProjectOverview {
  projectTitle: string;
  domain: string;
  estimatedBudgetUsd: number | string;
  typeOfRequest: string;
  priorityLevel: string;
  dateOfSubmission: Date | null;
  estimatedStartDate: Date | null;
  estimatedCompletionDate: Date | null;
}

export interface RequestorInformation {
  requestorName: string;
  department: string;
  contactEmail: string;
  contactPhone: string;
  projectManager: string;
}

export interface ProjectSpecification {
  targetUsers: string;
  platform: string;
  technologyPreference: string;
  projectDescription: string;
  projectGoals: string;
  businessProblem: string;
  expectedOutcome: string;
  resourceRequirements: string;
  dependencies: string;
  complianceRequirements: string;
  attachments: File[];
}

export interface ManagementNotes {
  stakeholders: string;
  risks: string;
  reviewNotes: string;
  additionalNotes: string;
}

export interface IntakeFormData {
  projectOverview: ProjectOverview;
  requestorInformation: RequestorInformation;
  projectSpecification: ProjectSpecification;
  managementNotes: ManagementNotes;
}

export interface ScrubReview {
  decision: string;
  scrubTeamRemarks: string;
  latestSubmitterRemarks: string;
  attachments: File[];
}

export interface CommitteeReview {
  decision: string;
  committeeTeamRemarks: string;
  latestSubmitterRemarks: string;
  attachments: File[];
}

export interface WorkflowState {
  activeStep: StepId;
  status: WorkflowStatus;
  createdBy?: string;
  projectOverview?: ProjectOverview;
  requestorInformation?: RequestorInformation;
  projectSpecification?: ProjectSpecification;
  managementNotes?: ManagementNotes;
  scrubReview?: ScrubReview;
  committeeReview?: CommitteeReview;
}

export const STEP_LIST: { label: string; key: StepId }[] = [
  { label: 'INTAKE FORM', key: 'INTAKE_FORM' },
  { label: 'SCRUB TEAM', key: 'SCRUB_TEAM' },
  { label: 'COMMITTEE TEAM', key: 'COMMITTEE_TEAM' },
  { label: 'APPROVED', key: 'APPROVED' },
];

export const STEP_INDEX: Record<StepId, number> = {
  INTAKE_FORM: 0,
  SCRUB_TEAM: 1,
  COMMITTEE_TEAM: 2,
  APPROVED: 3,
};
