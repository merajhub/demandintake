# Document Auto-Fill Agent

Reads data from an Excel file and a Word template, fills in values, and produces a new Word output file. Also includes a Node.js version of the same functionality.

---

## Project Structure

```
agent/
├── Sample-word.docx        # Word template (never modified)
├── Sample-excel.xlsx       # Excel data source (Version Spec sheet)
├── Word_Template.docx      # Secondary Word template (PAM guidelines)
├── data.json               # Sample project data for generate scripts
│
├── scope_fill.py           # Main Python script (reads Excel → fills Word)
├── generate.py             # Python script (fills Word_Template from data.json)
├── generate.js             # Node.js version of generate.py
│
├── requirements.txt        # Python dependencies
├── package.json            # Node.js dependencies
│
└── output/                 # Generated output files
    ├── Scope_Output.docx
    ├── Project_Alpha_py.docx
    ├── Project_Beta_py.docx
    └── Project_Gamma_py.docx
```

---

## Prerequisites

- Python 3.12+
- Node.js 18+ (for the JS version only)

---

## Installation

### Python

```bash
pip install -r requirements.txt
```

### Node.js

```bash
npm install
```

---

## Scripts

### 1. `scope_fill.py` — Fill Word template from Excel

Reads `Sample-word.docx` and `Sample-excel.xlsx`, resolves values for three sections, and writes `Scope_Output.docx`.

**Sections filled:**

| Section | Word Table Index | Method |
|---|---|---|
| Scope of the Project | 5 | `fill_scope_table` |
| Introduction and General Project Information | 10 | `fill_intro_table` |
| Design and Inputs | 11 | `fill_design_table` |

**Run:**

```bash
python scope_fill.py
```

**Output:** `Scope_Output.docx`

---

**How value lookup works:**

1. If the template's third column contains a `Version Spec!Bxx` reference → reads that exact Excel row directly (most accurate)
2. Ranges like `B41-43` are expanded to rows 41, 42, 43
3. If no reference → checks hand-crafted overrides (e.g. `Total Markets` → `Total # Markets`)
4. Falls back to exact key match against the Excel lookup dictionary
5. Falls back to normalised fuzzy match (all tokens of field name present in Excel key)
6. Returns `N/A` if nothing matched

**Scope of the Project format** is preserved as a single pipe-separated line:

```
**Job Name:** ASICS Brand Equity 1 dips | **Client Name:** ASICS | ...
```

---

### 2. `generate.py` — Fill PAM template from JSON (Python)

Reads `data.json` (array of project objects) and writes one `.docx` per project into `output/`.

**Run:**

```bash
python generate.py
```

**Output:** `output/Project_Alpha_py.docx`, `output/Project_Beta_py.docx`, `output/Project_Gamma_py.docx`

**JSON structure (`data.json`):**

```json
[
  {
    "name": "Project_Alpha",
    "Purpose": "...",
    "Schedule/Timeline": "...",
    "Renewal": "...",
    "Markets and categories": "...",
    "Data collection frequency": "...",
    "Frequency of changes": "..."
  }
]
```

Each object produces one Word file. Add more objects to generate more files.

---

### 3. `generate.js` — Fill PAM template from JSON (Node.js)

Same functionality as `generate.py` but implemented in Node.js using `adm-zip`.

**Run:**

```bash
node generate.js
```

**Output:** `output/Project_Alpha.docx`, `output/Project_Beta.docx`, `output/Project_Gamma.docx`

---

## Deploying to Azure Function App

### Prerequisites

- Azure subscription
- [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli)
- [Azure Functions Core Tools v4](https://learn.microsoft.com/en-us/azure/azure-functions/functions-run-local)

---

### Step 1 — Create Azure resources

```bash
az login

az group create \
  --name rnd-agent-rg \
  --location eastus

az storage account create \
  --name rndagentstorage \
  --resource-group rnd-agent-rg \
  --sku Standard_LRS

az functionapp create \
  --resource-group rnd-agent-rg \
  --consumption-plan-location eastus \
  --runtime python \
  --runtime-version 3.12 \
  --functions-version 4 \
  --name rnd-agent-func \
  --storage-account rndagentstorage \
  --os-type linux
```

---

### Step 2 — Scaffold the Function App project

```bash
func init rnd-agent-func --python
cd rnd-agent-func
func new --name FillDocument --template "HTTP trigger" --authlevel anonymous
```

---

### Step 3 — Adapt the code

- Copy `scope_fill.py`, `generate.py`, `requirements.txt` into the project folder
- In `function_app.py`, import and call the relevant `main()` logic inside the HTTP trigger handler
- Accept input files from **Azure Blob Storage** (download on function start, upload output back)
- Return the Blob URL or output filename in the HTTP response

---

### Step 4 — Update `requirements.txt`

```
azure-functions
azure-storage-blob
python-docx==1.2.0
openpyxl==3.1.5
```

---

### Step 5 — Configure Blob Storage connection

Store the connection string as an Application Setting (never hard-code credentials):

```bash
az functionapp config appsettings set \
  --name rnd-agent-func \
  --resource-group rnd-agent-rg \
  --settings "AzureWebJobsStorage=<your_connection_string>"
```

In code, read it via:

```python
import os
conn_str = os.environ["AzureWebJobsStorage"]
```

---

### Step 6 — Test locally

```bash
func start
```

Function runs at `http://localhost:7071/api/FillDocument`

---

### Step 7 — Deploy to Azure

```bash
func azure functionapp publish rnd-agent-func --python
```

---

### Step 8 — Security recommendations

- Change HTTP trigger `authlevel` to `function` or `admin` for key-based authentication
- Use **Managed Identity** instead of connection strings for Blob Storage access:
  ```bash
  az functionapp identity assign --name rnd-agent-func --resource-group rnd-agent-rg
  ```
- Store any secrets in **Azure Key Vault**, not in Application Settings

---

## Notes

- `Sample-word.docx` and `Sample-excel.xlsx` are **never modified** by any script
- All output is written to `output/` or `Scope_Output.docx`
- `N/A` is written when a field cannot be matched in the Excel source
