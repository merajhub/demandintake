"""
generate.py
Reads data.json and fills Word_Template.docx with project data,
writing one output file per project into the ./output/ folder.

Each project object in data.json must have these keys:
  Purpose, Schedule/Timeline, Renewal, Markets and categories,
  Data collection frequency, Frequency of changes
"""

import json
import os
import shutil
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


# ── helpers ──────────────────────────────────────────────────────────────────

def clear_cell(cell):
    """Remove all runs and SDT content controls from a cell, keeping paragraph."""
    para = cell.paragraphs[0]
    p_elem = para._p

    # Remove all run elements
    for r in p_elem.findall(qn("w:r")):
        p_elem.remove(r)

    # Remove all structured document tags (content controls / placeholders)
    for sdt in p_elem.findall(qn("w:sdt")):
        p_elem.remove(sdt)

    # Remove spell-check markers
    for tag in ("w:proofErr",):
        for el in p_elem.findall(qn(tag)):
            p_elem.remove(el)


def set_cell_text(cell, text: str):
    """Clear a cell then add a single styled run with *text*."""
    clear_cell(cell)

    para = cell.paragraphs[0]
    run = para.add_run(text)

    # Style: Arial 9 pt, blue (matching existing template style)
    rPr = run._r.get_or_add_rPr()

    fonts = OxmlElement("w:rFonts")
    fonts.set(qn("w:ascii"), "Arial")
    fonts.set(qn("w:hAnsi"), "Arial")
    fonts.set(qn("w:cs"), "Arial")
    rPr.insert(0, fonts)

    color = OxmlElement("w:color")
    color.set(qn("w:val"), "0070C0")
    rPr.append(color)

    sz = OxmlElement("w:sz")
    sz.set(qn("w:val"), "18")          # 9 pt = 18 half-points
    rPr.append(sz)

    szCs = OxmlElement("w:szCs")
    szCs.set(qn("w:val"), "18")
    rPr.append(szCs)


# Map each property name → 0-based row index in the first table
ROW_MAP = {
    "Purpose":                   2,
    "Schedule/Timeline":         3,
    "Renewal":                   4,
    "Markets and categories":    5,
    "Data collection frequency": 6,
    "Frequency of changes":      7,
}


def fill_template(template_path: str, project: dict, output_path: str):
    """Clone the template, fill in values, and save to output_path."""
    shutil.copy2(template_path, output_path)
    doc = Document(output_path)

    table = doc.tables[0]

    for prop, row_idx in ROW_MAP.items():
        value = project.get(prop, "")
        row = table.rows[row_idx]
        last_cell = row.cells[-1]
        set_cell_text(last_cell, value)

    doc.save(output_path)
    print(f"Created: {output_path}")


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data.json")
    template_path = os.path.join(base_dir, "Word_Template.docx")
    output_dir = os.path.join(base_dir, "output")

    os.makedirs(output_dir, exist_ok=True)

    with open(data_path, encoding="utf-8") as f:
        projects = json.load(f)

    for project in projects:
        name = project.get("name", f"Project_{projects.index(project) + 1}")
        out_file = os.path.join(output_dir, f"{name}_py.docx")
        fill_template(template_path, project, out_file)

    print(f"\nDone – {len(projects)} file(s) generated in ./output/")


if __name__ == "__main__":
    main()
