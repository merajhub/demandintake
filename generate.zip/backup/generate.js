"use strict";

const AdmZip = require("adm-zip");
const fs = require("fs");
const path = require("path");

// ─── helpers ────────────────────────────────────────────────────────────────

function escapeXml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/**
 * Replace everything between </w:pPr> and </w:p> in the last <w:tc>
 * of the given row XML with a single new text run.
 */
function setLastCellText(rowXml, newText) {
  const LAST_TC_OPEN = "<w:tc>";
  const LAST_TC_CLOSE = "</w:tc>";
  const PPR_CLOSE = "</w:pPr>";
  const P_CLOSE = "</w:p>";

  const lastTcStart = rowXml.lastIndexOf(LAST_TC_OPEN);
  const lastTcEnd = rowXml.lastIndexOf(LAST_TC_CLOSE) + LAST_TC_CLOSE.length;
  if (lastTcStart === -1 || lastTcEnd === -1) return rowXml;

  const cellXml = rowXml.substring(lastTcStart, lastTcEnd);

  // Find </w:pPr> and the last </w:p> inside this cell
  const pPrEndIdx = cellXml.lastIndexOf(PPR_CLOSE);
  const pEndIdx = cellXml.lastIndexOf(P_CLOSE);
  if (pPrEndIdx === -1 || pEndIdx === -1) return rowXml;

  const insertPoint = pPrEndIdx + PPR_CLOSE.length;

  // New run with Arial 9pt, blue colour (matching existing style)
  const runXml =
    `<w:r><w:rPr>` +
    `<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>` +
    `<w:color w:val="0070C0"/>` +
    `<w:sz w:val="18"/><w:szCs w:val="18"/>` +
    `</w:rPr>` +
    `<w:t xml:space="preserve">${escapeXml(newText)}</w:t>` +
    `</w:r>`;

  const newCellXml =
    cellXml.substring(0, insertPoint) +
    runXml +
    cellXml.substring(pEndIdx);       // keeps </w:p></w:tc>

  return (
    rowXml.substring(0, lastTcStart) +
    newCellXml +
    rowXml.substring(lastTcEnd)
  );
}

/**
 * Row index (0-based among all <w:tr> elements in the document) that
 * corresponds to each data property.
 */
const ROW_MAP = {
  "Purpose":                  2,
  "Schedule/Timeline":        3,
  "Renewal":                  4,
  "Markets and categories":   5,
  "Data collection frequency":6,
  "Frequency of changes":     7,
};

/**
 * Fill the template with one project's data and return the modified
 * document.xml string.
 */
function fillTemplate(templateXml, projectData) {
  // Collect all row spans (start, end, original xml)
  const rowPattern = /<w:tr[\s>][\s\S]*?<\/w:tr>/g;
  const rows = [];
  let m;
  while ((m = rowPattern.exec(templateXml)) !== null) {
    rows.push({ start: m.index, end: m.index + m[0].length, xml: m[0] });
  }

  // Process in descending row order so earlier offsets stay valid
  const targets = Object.entries(ROW_MAP)
    .map(([prop, idx]) => ({ prop, idx }))
    .sort((a, b) => b.idx - a.idx);

  let result = templateXml;
  for (const { prop, idx } of targets) {
    const row = rows[idx];
    if (!row) continue;
    const value = projectData[prop] !== undefined ? projectData[prop] : "";
    const newRowXml = setLastCellText(row.xml, value);

    // Recalculate position in the (possibly already modified) result
    // by counting occurrences up to this row index
    const allRowsInResult = [];
    const rp2 = /<w:tr[\s>][\s\S]*?<\/w:tr>/g;
    let m2;
    while ((m2 = rp2.exec(result)) !== null) {
      allRowsInResult.push({ start: m2.index, end: m2.index + m2[0].length });
    }
    const target2 = allRowsInResult[idx];
    if (!target2) continue;

    result =
      result.substring(0, target2.start) +
      newRowXml +
      result.substring(target2.end);
  }

  return result;
}

// ─── main ───────────────────────────────────────────────────────────────────

function main() {
  const dataPath = path.join(__dirname, "data.json");
  const templatePath = path.join(__dirname, "Word_Template.docx");
  const outputDir = path.join(__dirname, "output");

  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir);
  }

  const projects = JSON.parse(fs.readFileSync(dataPath, "utf8"));
  const templateXml = (() => {
    const zip = new AdmZip(templatePath);
    return zip.readAsText("word/document.xml");
  })();

  const generated = [];

  for (const project of projects) {
    const filledXml = fillTemplate(templateXml, project);

    // Clone the entire docx zip and replace only document.xml
    const zip = new AdmZip(templatePath);
    zip.updateFile("word/document.xml", Buffer.from(filledXml, "utf8"));

    const outFile = path.join(outputDir, `${project.name}.docx`);
    zip.writeZip(outFile);
    generated.push(outFile);
    console.log(`Created: ${outFile}`);
  }

  console.log(`\nDone – ${generated.length} file(s) generated in ./output/`);
}

main();
