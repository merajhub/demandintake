"""
scope_fill.py

Reads the 'Scope of the Project' field list from Sample-word.docx,
looks up each field value in Sample-excel.xlsx (sheet: Version Spec),
and writes a new Word file (Scope_Output.docx) with the values filled in.

The original Sample-word.docx is never modified.
"""

import re
import shutil
import os
import openpyxl
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

# ── config ────────────────────────────────────────────────────────────────────

BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
WORD_SRC     = os.path.join(BASE_DIR, "Sample-word.docx")
EXCEL_SRC    = os.path.join(BASE_DIR, "Sample-excel.xlsx")
WORD_OUT     = os.path.join(BASE_DIR, "Scope_Output.docx")
EXCEL_SHEET  = "Version Spec"

# Table index (0-based) in Sample-word.docx that holds the scope pipe-string
SCOPE_TABLE_IDX = 5


# ── Step 1: parse scope fields from Word ─────────────────────────────────────

def parse_scope_fields(doc: Document) -> list[str]:
    """
    Split the pipe-delimited scope string from table 5 and return
    clean field names (asterisks removed, whitespace stripped,
    inline Excel refs like 'Version Spec!B125' stripped).
    """
    raw_text = doc.tables[SCOPE_TABLE_IDX].rows[0].cells[0].text
    parts = raw_text.split("|")
    fields = []
    for part in parts:
        # Remove ** markers
        clean = part.replace("*", "")
        # Remove trailing/inline 'Version Spec!BXxx' references
        clean = re.sub(r"Version Spec![A-Z]+\d+", "", clean, flags=re.IGNORECASE)
        # Remove trailing colon and extra spaces
        clean = clean.strip().rstrip(":").strip()
        if clean:
            fields.append(clean)
    return fields


# ── Step 2: build lookup dict from Excel ─────────────────────────────────────

def build_excel_lookup(path: str, sheet: str) -> dict[str, str]:
    """
    Read column A (key) and column B (value) from the given sheet.
    Returns a dict with the original key strings preserved, plus
    a normalised version for fuzzy matching.
    """
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[sheet]
    lookup = {}
    for row in ws.iter_rows(min_col=1, max_col=2, values_only=True):
        key, val = row
        if key is not None:
            lookup[str(key).strip()] = val
    return lookup


def _normalise(text: str) -> str:
    """Lower-case, remove punctuation, collapse spaces for matching."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9 ]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


# Hand-crafted overrides for fields whose Excel key differs from the scope label
FIELD_OVERRIDES = {
    # scope field (normalised)  : exact Excel key to use
    "total markets"             : "Total # Markets",
    "total cells"               : "Total # Cells",
    "total sample size"         : "Total Sample Size (All Design Blocks)",
}


def lookup_value(field: str, lookup: dict[str, str]) -> str:
    """
    Find the value for *field* in the Excel lookup dict.
    Strategy:
      1. exact match
      2. hand-crafted overrides
      3. normalised substring match (field tokens all present in key)
    Special case: 'Client Name' → if value is 'Other', use 'Other Client Name'.
    """
    norm_field = _normalise(field)

    # 1. Override table (wins over ambiguous exact matches like "Total Sample Size")
    if norm_field in FIELD_OVERRIDES:
        key = FIELD_OVERRIDES[norm_field]
        val = lookup.get(key)
        return str(val) if val is not None else "N/A"

    # 2. Exact match
    if field in lookup:
        val = lookup[field]
        # Special: Client Name = "Other" → use Other Client Name
        if field == "Client Name" and str(val).strip() == "Other":
            val = lookup.get("Other Client Name", val)
        return str(val) if val is not None else "N/A"

    # 3. Normalised substring match
    tokens = norm_field.split()
    for key, val in lookup.items():
        norm_key = _normalise(key)
        if all(t in norm_key for t in tokens):
            if val is not None:
                return str(val)

    return "N/A"


# ── Step 3: write output Word file ───────────────────────────────────────────

def _clear_cell_runs(cell):
    """Remove all runs and content controls from a cell paragraph."""
    para = cell.paragraphs[0]
    p_elem = para._p
    for tag in (qn("w:r"), qn("w:sdt"), qn("w:hyperlink"), qn("w:proofErr")):
        for el in p_elem.findall(tag):
            p_elem.remove(el)


def _add_run(para, text: str, bold: bool = False, color: str | None = None,
             size_pt: float = 9):
    run = para.add_run(text)
    run.bold = bold
    run.font.size = Pt(size_pt)
    run.font.name = "Arial"
    if color:
        r, g, b = int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)
        run.font.color.rgb = RGBColor(r, g, b)
    return run


def fill_scope_table(doc: Document, fields: list[str], lookup: dict[str, str]):
    """
    Preserve the original pipe-separated, asterisk-wrapped format but replace
    placeholders with actual values.  Everything stays on a single line:
      **Job Name:** ASICS Brand Equity 1 dips | **Client Name:** ASICS | ...
    """
    table = doc.tables[SCOPE_TABLE_IDX]
    cell = table.rows[0].cells[0]
    _clear_cell_runs(cell)

    # Keep only the first paragraph; remove extras
    para_elems = cell._tc.findall(qn("w:p"))
    for p in para_elems[1:]:
        cell._tc.remove(p)

    para = cell.paragraphs[0]
    para.clear()
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT

    for i, field in enumerate(fields):
        value = lookup_value(field, lookup)

        if i > 0:
            _add_run(para, " | ", bold=False, color="000000")

        # Bold label wrapped in ** with colon, matching original style
        _add_run(para, f"**{field}:**", bold=True,  color="0070C0")
        _add_run(para, f" {value}",     bold=False, color="000000")


def main():
    # Copy template → output (never touch original)
    shutil.copy2(WORD_SRC, WORD_OUT)
    doc = Document(WORD_OUT)

    # Parse fields
    fields = parse_scope_fields(Document(WORD_SRC))
    print(f"Scope fields found ({len(fields)}):")
    for f in fields:
        print(f"  • {f}")

    # Build Excel lookup
    lookup = build_excel_lookup(EXCEL_SRC, EXCEL_SHEET)

    # Show resolved values
    print("\nResolved values:")
    for f in fields:
        v = lookup_value(f, lookup)
        print(f"  {f}: {v}")

    # Write filled output
    fill_scope_table(doc, fields, lookup)
    doc.save(WORD_OUT)
    print(f"\nSaved → {WORD_OUT}")


if __name__ == "__main__":
    main()
