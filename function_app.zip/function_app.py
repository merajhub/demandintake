"""
function_app.py

Azure Functions v2 HTTP trigger.

Accepts a POST request with a JSON body:
{
    "word_template": "<base64-encoded .docx bytes>",
    "excel_file":    "<base64-encoded .xlsx bytes>"
}

Returns the filled Word document as a binary download.

Local test:
    func start
    curl -X POST http://localhost:7071/api/fill-document \
         -H "Content-Type: application/json" \
         -d @test_payload.json \
         --output Scope_Output.docx
"""

import base64
import io
import logging
import zipfile

import azure.functions as func

from fill_from_copy_mapping import process_documents as process_documents_copy
from fill_quota_spec import process_quota_spec

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)


@app.route(route="fill-document", methods=["POST"])
def fill_document(req: func.HttpRequest) -> func.HttpResponse:
    """
    HTTP POST  /api/fill-document

    Flexible combined endpoint. Pass any combination of PAM and/or Quota:

    Body (JSON):
      PAM         – base64-encoded Word (.docx) template          [optional]
      Quota       – base64-encoded Quota Spec (.xlsm) template    [optional]
      excel_file  – base64-encoded Excel (.xlsx) data file        [required]

    Response:
      PAM + Quota → ZIP archive containing both output files (.docx + .xlsm)
      PAM only    → Word document (.docx)
      Quota only  → Excel macro-enabled workbook (.xlsm)
    """
    logging.info("fill-document triggered")

    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            '{"error": "Request body must be valid JSON"}',
            status_code=400,
            mimetype="application/json",
        )

    has_pam   = "PAM"   in body
    has_quota = "Quota" in body

    if not has_pam and not has_quota:
        return func.HttpResponse(
            '{"error": "Provide at least one of: PAM (Word template) or Quota (Quota Spec template)"}',
            status_code=400,
            mimetype="application/json",
        )
    if "excel_file" not in body:
        return func.HttpResponse(
            '{"error": "Missing required field: excel_file"}',
            status_code=400,
            mimetype="application/json",
        )

    try:
        excel_bytes = base64.b64decode(body["excel_file"])
        pam_bytes   = base64.b64decode(body["PAM"])   if has_pam   else None
        quota_bytes = base64.b64decode(body["Quota"]) if has_quota else None
    except Exception as exc:
        return func.HttpResponse(
            f'{{"error": "Base64 decode failed: {exc}"}}',
            status_code=400,
            mimetype="application/json",
        )

    pam_result   = None
    quota_result = None

    if has_pam:
        try:
            pam_result = process_documents_copy(pam_bytes, excel_bytes)
        except Exception as exc:
            logging.exception("PAM document processing failed")
            return func.HttpResponse(
                f'{{"error": "PAM processing failed: {exc}"}}',
                status_code=500,
                mimetype="application/json",
            )

    if has_quota:
        try:
            quota_result = process_quota_spec(quota_bytes, excel_bytes)
        except Exception as exc:
            logging.exception("Quota Spec processing failed")
            return func.HttpResponse(
                f'{{"error": "Quota processing failed: {exc}"}}',
                status_code=500,
                mimetype="application/json",
            )

    # Both: return a ZIP
    if pam_result and quota_result:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("Scope_Copy_Output.docx", pam_result)
            zf.writestr("Quota_Spec_Output.xlsm", quota_result)
        return func.HttpResponse(
            body=buf.getvalue(),
            status_code=200,
            mimetype="application/zip",
            headers={"Content-Disposition": 'attachment; filename="output.zip"'},
        )

    # PAM only
    if pam_result:
        return func.HttpResponse(
            body=pam_result,
            status_code=200,
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": 'attachment; filename="Scope_Copy_Output.docx"'},
        )

    # Quota only
    return func.HttpResponse(
        body=quota_result,
        status_code=200,
        mimetype="application/vnd.ms-excel.sheet.macroEnabled.12",
        headers={"Content-Disposition": 'attachment; filename="Quota_Spec_Output.xlsm"'},
    )


@app.route(route="fill-document-copy", methods=["POST"])
def fill_document_copy(req: func.HttpRequest) -> func.HttpResponse:
    """
    HTTP POST  /api/fill-document-copy
    Fills a Word template using template_mapping_copy_by_value.json.
    Body (JSON):
      word_template  – base64-encoded Word (.docx) template bytes
      excel_file     – base64-encoded Excel (.xlsx) data file bytes
    Response:
      200  application/vnd.openxmlformats-officedocument.wordprocessingml.document
      400  missing or invalid fields
      500  processing error
    """
    logging.info("fill-document-copy triggered")

    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            '{"error": "Request body must be valid JSON"}',
            status_code=400,
            mimetype="application/json",
        )

    missing = [f for f in ("word_template", "excel_file") if f not in body]
    if missing:
        return func.HttpResponse(
            f'{{"error": "Missing fields: {", ".join(missing)}"}}',
            status_code=400,
            mimetype="application/json",
        )

    try:
        word_bytes  = base64.b64decode(body["word_template"])
        excel_bytes = base64.b64decode(body["excel_file"])
    except Exception as exc:
        return func.HttpResponse(
            f'{{"error": "Base64 decode failed: {exc}"}}',
            status_code=400,
            mimetype="application/json",
        )

    try:
        result_bytes = process_documents_copy(word_bytes, excel_bytes)
    except Exception as exc:
        logging.exception("Document processing failed")
        return func.HttpResponse(
            f'{{"error": "Processing failed: {exc}"}}',
            status_code=500,
            mimetype="application/json",
        )

    return func.HttpResponse(
        body=result_bytes,
        status_code=200,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={
            "Content-Disposition": 'attachment; filename="Scope_Copy_Output.docx"',
        },
    )
