"""
function_app.py

Azure Functions v2 HTTP trigger.

Accepts a POST request with a JSON body:
{
    "word_template": "<base64-encoded .docx bytes>",
    "excel_file":    "<base64-encoded .xlsx bytes>"
}

Returns the filled Word document as a binary download.

Local test:
    func start
    curl -X POST http://localhost:7071/api/fill-document \
         -H "Content-Type: application/json" \
         -d @test_payload.json \
         --output Scope_Output.docx
"""

import base64
import logging

import azure.functions as func

from fill_from_copy_mapping import process_documents as process_documents_copy

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)




@app.route(route="fill-document-copy", methods=["POST"])
def fill_document_copy(req: func.HttpRequest) -> func.HttpResponse:
    """
    HTTP POST  /api/fill-document-copy
    Fills a Word template using template_mapping_copy_by_value.json.
    Body (JSON):
      word_template  – base64-encoded Word (.docx) template bytes
      excel_file     – base64-encoded Excel (.xlsx) data file bytes
    Response:
      200  application/vnd.openxmlformats-officedocument.wordprocessingml.document
      400  missing or invalid fields
      500  processing error
    """
    logging.info("fill-document-copy triggered")

    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            '{"error": "Request body must be valid JSON"}',
            status_code=400,
            mimetype="application/json",
        )

    missing = [f for f in ("word_template", "excel_file") if f not in body]
    if missing:
        return func.HttpResponse(
            f'{{"error": "Missing fields: {", ".join(missing)}"}}',
            status_code=400,
            mimetype="application/json",
        )

    try:
        word_bytes  = base64.b64decode(body["word_template"])
        excel_bytes = base64.b64decode(body["excel_file"])
    except Exception as exc:
        return func.HttpResponse(
            f'{{"error": "Base64 decode failed: {exc}"}}',
            status_code=400,
            mimetype="application/json",
        )

    try:
        result_bytes = process_documents_copy(word_bytes, excel_bytes)
    except Exception as exc:
        logging.exception("Document processing failed")
        return func.HttpResponse(
            f'{{"error": "Processing failed: {exc}"}}',
            status_code=500,
            mimetype="application/json",
        )

    return func.HttpResponse(
        body=result_bytes,
        status_code=200,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={
            "Content-Disposition": 'attachment; filename="Scope_Copy_Output.docx"',
        },
    )
