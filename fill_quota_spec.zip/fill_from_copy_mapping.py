"""
fill_from_copy_mapping.py

Fills Sample-Copy.docx from Sample.xlsx using
azure_function/template_mapping_copy_by_value.json as the source-of-truth.

Supported mapping source_types:
    name_lookup       — find first row in Excel column A matching excel_key, return column B
    multi_name_lookup — same for each key in excel_keys; returns "label: value | ..." pairs
    conditional       — evaluate condition(s) against Excel values; return if_true / if_false

Condition operators: eq, ne, gt, lt, gte, lte
Compound conditions: "all" (AND) / "any" (OR)

Usage (defaults):
    python fill_from_copy_mapping.py

Custom paths:
    python fill_from_copy_mapping.py \\
        --template  Sample-Copy.docx \\
        --excel     Sample.xlsx \\
        --mapping   azure_function/template_mapping_copy_by_value.json \\
        --output    output/Scope_Copy_Output.docx
"""

import argparse
import io
import json
import pathlib
import re

import openpyxl
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

EXCEL_SHEET = "Version Spec"

# Word table indices (0-based) inside Sample-Copy.docx for each section.
SECTION_TABLE_INDEX = {
    "Scope of the Project":                   5,
    "Introduction and General Project Info":  10,
    "Design and Inputs":                      11,
    "Sample, Fieldwork, and Data Protection": 12,
    "Data Delivery":                          13,
    "Finance, Administration, and Closure":   14,
}


# ── Excel helpers ──────────────────────────────────────────────────────────────

def _build_lookup(ws) -> dict:
    """Build {column_A_label: column_B_value} from the worksheet."""
    lookup = {}
    for row in ws.iter_rows(min_col=1, max_col=2, values_only=True):
        key, val = row
        if key is not None:
            lookup[str(key).strip()] = val
    return lookup


def _normalise(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9 ]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _name_lookup(key: str, lookup: dict) -> str:
    """
    Resolve a key against the Excel lookup using:
      1. Exact match
      2. Fuzzy match — all tokens of key present in some Excel key
    Special case: Client Name = 'Other' -> use 'Other Client Name'.
    """
    if key in lookup:
        val = lookup[key]
        if key == "Client Name" and str(val).strip() == "Other":
            val = lookup.get("Other Client Name", val)
        return str(val) if val is not None else "N/A"

    tokens = _normalise(key).split()
    for k, val in lookup.items():
        if all(t in _normalise(k) for t in tokens) and val is not None:
            return str(val)

    return "N/A"


# ── Condition evaluator ────────────────────────────────────────────────────────

def _eval_single_condition(c: dict, lookup: dict) -> bool:
    """Evaluate one condition clause {excel_key, operator, value} against lookup."""
    raw = lookup.get(c["excel_key"])
    actual_str = str(raw).strip() if raw is not None else ""

    # Legacy exact-match format
    if "must_equal" in c:
        return actual_str.lower() == c["must_equal"].lower()

    op = c.get("operator", "eq")
    cmp = c["value"]

    if op == "eq":
        return actual_str.lower() == str(cmp).lower()
    if op == "ne":
        return actual_str.lower() != str(cmp).lower()

    # Numeric comparisons
    try:
        actual_num = float(actual_str)
        cmp_num = float(cmp)
        if op == "gt":  return actual_num > cmp_num
        if op == "lt":  return actual_num < cmp_num
        if op == "gte": return actual_num >= cmp_num
        if op == "lte": return actual_num <= cmp_num
    except (ValueError, TypeError):
        pass

    return False


def _eval_condition(cond: dict, lookup: dict) -> bool:
    """Evaluate a condition block — supports 'all', 'any', or single clause."""
    if "all" in cond:
        return all(_eval_single_condition(c, lookup) for c in cond["all"])
    if "any" in cond:
        return any(_eval_single_condition(c, lookup) for c in cond["any"])
    return _eval_single_condition(cond, lookup)


# ── Value resolver ─────────────────────────────────────────────────────────────

def resolve_value(field_map: dict, lookup: dict) -> str:
    """
    Resolve the Excel value for one field using its JSON mapping entry.

    source_type values handled:
        name_lookup       — single excel_key fuzzy-matched in column A
        multi_name_lookup — list of excel_keys; joined as "label: value" pairs
        conditional       — evaluate condition; return if_true or if_false
    """
    st = field_map.get("source_type", "name_lookup")

    if st == "name_lookup":
        return _name_lookup(field_map["excel_key"], lookup)

    if st == "multi_name_lookup":
        parts = []
        for key in field_map["excel_keys"]:
            val = lookup.get(key)
            val_s = str(val) if val is not None else "N/A"
            parts.append(f"{key}: {val_s}")
        return " | ".join(parts)

    if st == "conditional":
        met = _eval_condition(field_map["condition"], lookup)

        if_false = field_map.get("if_false", "")
        if not met:
            return "" if if_false in ("blank (empty)", "") else str(if_false)

        if_true = field_map["if_true"]

        # Literal string result (e.g. "Yes")
        if isinstance(if_true, str):
            return if_true

        # Nested multi_name_lookup
        if isinstance(if_true, dict) and if_true.get("source_type") == "multi_name_lookup":
            parts = []
            for k in if_true["excel_keys"]:
                val = lookup.get(k)
                val_s = str(val) if val is not None else "N/A"
                parts.append(f"{k}: {val_s}")
            return " | ".join(parts)

    return "N/A"


# ── Word helpers ───────────────────────────────────────────────────────────────

def _add_run(para, text: str, bold: bool = False,
             color: str = "000000", size_pt: float = 9):
    run = para.add_run(text)
    run.bold = bold
    run.font.size = Pt(size_pt)
    run.font.name = "Arial"
    r, g, b = int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)
    run.font.color.rgb = RGBColor(r, g, b)
    return run


def _clear_cell(cell):
    """Remove all runs and inline elements from the cell's first paragraph."""
    p_elem = cell.paragraphs[0]._p
    for tag in (qn("w:r"), qn("w:sdt"), qn("w:hyperlink"), qn("w:proofErr")):
        for el in p_elem.findall(tag):
            p_elem.remove(el)


def _set_cell_text(cell, text: str):
    """Replace cell content with a single blue Arial 9pt run."""
    _clear_cell(cell)
    for p in cell._tc.findall(qn("w:p"))[1:]:
        cell._tc.remove(p)
    para = cell.paragraphs[0]
    para.clear()
    _add_run(para, text, bold=False, color="0070C0")


# ── Section fillers ────────────────────────────────────────────────────────────

def _fill_scope(doc: Document, section_map: dict, lookup: dict):
    """
    Scope of the Project is a single pipe-delimited cell.
    Written as:  **Field:** value | **Field:** value | ...
    """
    tbl_idx = SECTION_TABLE_INDEX["Scope of the Project"]
    cell = doc.tables[tbl_idx].rows[0].cells[0]
    _clear_cell(cell)
    for p in cell._tc.findall(qn("w:p"))[1:]:
        cell._tc.remove(p)

    para = cell.paragraphs[0]
    para.clear()
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT

    for i, (field, field_map) in enumerate(section_map.items()):
        value = resolve_value(field_map, lookup)
        if i > 0:
            _add_run(para, " | ", color="000000")
        _add_run(para, f"**{field}:**", bold=True, color="0070C0")
        _add_run(para, f" {value}", bold=False, color="000000")


def _fill_section_table(doc: Document, tbl_idx: int, section_map: dict, lookup: dict):
    """
    Fill a 3-column Area | Guidelines | Value table.
    Resolved values are written into column index 2 for each matching row.
    Rows whose first cell is a header or footer are skipped.
    """
    table = doc.tables[tbl_idx]
    for row in table.rows:
        field = row.cells[0].text.strip()
        if (not field
                or field.lower().startswith("area")
                or field.lower().startswith("include any")):
            continue
        if field not in section_map:
            continue
        value = resolve_value(section_map[field], lookup)
        _set_cell_text(row.cells[2], value)


# ── Shared fill logic ─────────────────────────────────────────────────────────

def _fill_all(doc: Document, mapping: dict, lookup: dict):
    """Apply all section mappings to an already-loaded Document."""
    for section_name, section_map in mapping.items():
        tbl_idx = SECTION_TABLE_INDEX.get(section_name)
        if tbl_idx is None:
            print(f"WARNING: no table index configured for '{section_name}', skipping")
            continue
        if section_name == "Scope of the Project":
            _fill_scope(doc, section_map, lookup)
        else:
            _fill_section_table(doc, tbl_idx, section_map, lookup)


# ── In-memory entry point (used by Azure Function) ────────────────────────────

def process_documents(word_bytes: bytes, excel_bytes: bytes) -> bytes:
    """
    Accept raw bytes for the Word template and Excel data file.
    Returns the filled Word document as raw bytes.

    Loads template_mapping_copy_by_value.json from the same directory as this file.
    Called by the Azure Function HTTP trigger.
    """
    mapping_path = pathlib.Path(__file__).parent / "template_mapping_copy_by_value.json"
    with open(mapping_path, encoding="utf-8") as f:
        mapping = json.load(f)
    mapping.pop("_description", None)

    doc = Document(io.BytesIO(word_bytes))
    wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), data_only=True)
    ws = wb[EXCEL_SHEET]
    lookup = _build_lookup(ws)

    _fill_all(doc, mapping, lookup)

    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


# ── Disk-based entry point (used by CLI / local runs) ─────────────────────────

def fill_document(template_path: str, excel_path: str,
                  mapping_path: str, output_path: str):
    """Load files from disk, fill document, save to output_path."""
    with open(mapping_path, encoding="utf-8") as f:
        mapping = json.load(f)
    mapping.pop("_description", None)

    doc = Document(template_path)
    wb = openpyxl.load_workbook(excel_path, data_only=True)
    ws = wb[EXCEL_SHEET]
    lookup = _build_lookup(ws)

    _fill_all(doc, mapping, lookup)

    pathlib.Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    doc.save(output_path)
    print(f"Done — saved to {output_path}")


if __name__ == "__main__":
    base = pathlib.Path(__file__).parent
    parser = argparse.ArgumentParser(
        description="Fill Sample-Copy.docx from Excel via template_mapping_copy_by_value.json"
    )
    parser.add_argument(
        "--template",
        default=str(base / "Sample-Copy.docx"),
        help="Word template path (default: Sample-Copy.docx)"
    )
    parser.add_argument(
        "--excel",
        default=str(base / "Sample.xlsx"),
        help="Excel data file path (default: Sample.xlsx)"
    )
    parser.add_argument(
        "--mapping",
        default=str(base / "azure_function" / "template_mapping_copy_by_value.json"),
        help="JSON mapping file path"
    )
    parser.add_argument(
        "--output",
        default=str(base / "output" / "Scope_Copy_Output.docx"),
        help="Output Word document path (default: output/Scope_Copy_Output.docx)"
    )
    args = parser.parse_args()
    fill_document(args.template, args.excel, args.mapping, args.output)
