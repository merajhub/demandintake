"""
fill_quota_spec.py

Reads data from Sample.xlsx (sheet: "Version Spec") and fills the
"Quota Spec" sheet in Quota Spec.xlsm using a two-pass strategy:

  Pass 1 — Name lookup (preferred):
    For every field defined in quota_spec_mapping.json with a source_type
    of "name_lookup", resolve the value by finding the first row in
    Version Spec where column A equals excel_key, then write column B
    directly to the mapped cell coordinate.

  Pass 2 — Row-reference fallback:
    Any remaining cells that still contain a placeholder like
    "Version Spec!B49" (not covered by the mapping) are resolved by
    extracting the row number and reading column B at that row.

Saves the result as:  output/Quota_Spec_Output.xlsx

Usage (defaults):
    python fill_quota_spec.py

Custom paths:
    python fill_quota_spec.py \\
        --template  "Quota Spec.xlsm" \\
        --excel     Sample.xlsx \\
        --mapping   quota_spec_mapping.json \\
        --output    output/Quota_Spec_Output.xlsx
"""

import argparse
import io
import json
import pathlib
import re

import openpyxl

EXCEL_SHEET    = "Version Spec"
QUOTA_SHEET    = "Quota Spec"
PLACEHOLDER_RE = re.compile(r"^Version Spec!B(\d+)$", re.IGNORECASE)

DEFAULT_MAPPING = pathlib.Path(__file__).parent / "quota_spec_mapping.json"


# ── helpers ───────────────────────────────────────────────────────────────────

def _build_name_lookup(ws) -> dict[str, object]:
    """Return {column_A_label: column_B_value} for every row (first occurrence wins)."""
    lookup: dict[str, object] = {}
    for row in ws.iter_rows(min_col=1, max_col=2, values_only=True):
        key, val = row
        if key is not None:
            k = str(key).strip()
            if k not in lookup:  # first occurrence wins; later duplicates are ignored
                lookup[k] = val
    return lookup


def _build_row_lookup(ws) -> dict[int, object]:
    """Return {row_number: column_B_value} for every row."""
    lookup: dict[int, object] = {}
    for row in ws.iter_rows(min_col=2, max_col=2):
        cell = row[0]
        if cell.value is not None:
            lookup[cell.row] = cell.value
    return lookup


def _resolve_by_row(placeholder: str, row_lookup: dict[int, object]) -> object:
    """Resolve a 'Version Spec!B<n>' placeholder via row number."""
    m = PLACEHOLDER_RE.match(str(placeholder).strip())
    if not m:
        return placeholder
    return row_lookup.get(int(m.group(1)))


def _scale_for_pct(cell, value: object) -> object:
    """
    If the target cell is percentage-formatted (number_format contains '%')
    and the value is a whole-number percentage (e.g. 20 meaning 20%),
    divide by 100 so Excel renders it correctly as 20% instead of 2000%.
    """
    if (
        value is not None
        and isinstance(value, (int, float))
        and "%" in (cell.number_format or "")
    ):
        return value / 100
    return value


# ── main logic ────────────────────────────────────────────────────────────────

def fill_quota_spec(
    template_path: str = "Quota Spec.xlsm",
    excel_path: str    = "Sample.xlsx",
    mapping_path: str  = None,
    output_path: str   = "output/Quota_Spec_Output.xlsx",
) -> None:
    template_path = pathlib.Path(template_path)
    excel_path    = pathlib.Path(excel_path)
    mapping_path  = pathlib.Path(mapping_path) if mapping_path else DEFAULT_MAPPING
    output_path   = pathlib.Path(output_path)

    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_path}")
    if not excel_path.exists():
        raise FileNotFoundError(f"Excel data file not found: {excel_path}")
    if not mapping_path.exists():
        raise FileNotFoundError(f"Mapping file not found: {mapping_path}")

    # --- load mapping ----------------------------------------------------
    with open(mapping_path, encoding="utf-8") as fh:
        mapping: dict = json.load(fh)

    # --- read source data ------------------------------------------------
    print(f"Reading data from: {excel_path}  (sheet: {EXCEL_SHEET!r})")
    src_wb = openpyxl.load_workbook(excel_path, data_only=True)
    if EXCEL_SHEET not in src_wb.sheetnames:
        raise ValueError(
            f"Sheet {EXCEL_SHEET!r} not found in {excel_path}. "
            f"Available: {src_wb.sheetnames}"
        )
    src_ws       = src_wb[EXCEL_SHEET]
    name_lookup  = _build_name_lookup(src_ws)
    row_lookup   = _build_row_lookup(src_ws)

    # --- open template ---------------------------------------------------
    print(f"Opening template:  {template_path}  (sheet: {QUOTA_SHEET!r})")
    tpl_wb = openpyxl.load_workbook(template_path, data_only=True)
    if QUOTA_SHEET not in tpl_wb.sheetnames:
        raise ValueError(
            f"Sheet {QUOTA_SHEET!r} not found in {template_path}. "
            f"Available: {tpl_wb.sheetnames}"
        )
    ws = tpl_wb[QUOTA_SHEET]

    # ── Pass 1: name lookup from mapping (preferred) ──────────────────────
    print("\n── Pass 1: name lookup from mapping ──────────────────────────────")
    mapped_cells: set[str] = set()
    replaced = 0

    for section, fields in mapping.items():
        if section.startswith("_"):
            continue
        for field_name, field_def in fields.items():
            if not isinstance(field_def, dict):
                continue
            source_type = field_def.get("source_type")
            cell_coord  = field_def.get("cell")
            excel_key   = field_def.get("excel_key")

            if source_type == "name_lookup" and cell_coord and excel_key:
                new_val = name_lookup.get(excel_key)
                target_cell = ws[cell_coord]
                scaled_val = _scale_for_pct(target_cell, new_val)
                print(
                    f"  [{section}] {field_name:35s}  "
                    f"{cell_coord}: key={excel_key!r:35s}  →  {scaled_val!r}"
                    + (f"  (scaled from {new_val!r})" if scaled_val != new_val else "")
                )
                target_cell.value = scaled_val
                mapped_cells.add(cell_coord.upper())
                replaced += 1

    print(f"\nPass 1 filled {replaced} cell(s) by name lookup.")

    # ── Pass 2: row-reference fallback for unmapped placeholders ─────────
    print("\n── Pass 2: row-reference fallback for remaining placeholders ─────")
    fallback = 0

    for row in ws.iter_rows():
        for cell in row:
            if cell.coordinate.upper() in mapped_cells:
                continue  # already filled by Pass 1
            if (
                cell.value is not None
                and isinstance(cell.value, str)
                and PLACEHOLDER_RE.match(cell.value.strip())
            ):
                new_val = _resolve_by_row(cell.value, row_lookup)
                scaled_val = _scale_for_pct(cell, new_val)
                print(
                    f"  {cell.coordinate}: {cell.value!r:30s}  →  {scaled_val!r}"
                    + (f"  (scaled from {new_val!r})" if scaled_val != new_val else "")
                )
                cell.value = scaled_val
                fallback += 1

    if fallback:
        print(f"\nPass 2 filled {fallback} cell(s) by row-reference fallback.")
    else:
        print("\nNo remaining placeholders — Pass 2 had nothing to do.")

    # --- save output -----------------------------------------------------
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tpl_wb.save(output_path)
    print(f"\nSaved output to:   {output_path}")


# ── Azure Function in-memory entry point ─────────────────────────────────────

def process_quota_spec(quota_bytes: bytes, excel_bytes: bytes) -> bytes:
    """
    In-memory entry point for the Azure Function.
    Accepts raw bytes for the Quota Spec template and the Excel data file.
    Returns the filled workbook as raw .xlsx bytes.
    """
    mapping_path = pathlib.Path(__file__).parent / "quota_spec_mapping.json"
    with open(mapping_path, encoding="utf-8") as fh:
        mapping: dict = json.load(fh)

    # load source Excel data
    src_wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), data_only=True)
    if EXCEL_SHEET not in src_wb.sheetnames:
        raise ValueError(f"Sheet {EXCEL_SHEET!r} not found in the uploaded Excel file.")
    src_ws      = src_wb[EXCEL_SHEET]
    name_lookup = _build_name_lookup(src_ws)
    row_lookup  = _build_row_lookup(src_ws)

    # load Quota Spec template
    tpl_wb = openpyxl.load_workbook(io.BytesIO(quota_bytes), data_only=True)
    if QUOTA_SHEET not in tpl_wb.sheetnames:
        raise ValueError(f"Sheet {QUOTA_SHEET!r} not found in the uploaded Quota Spec file.")
    ws = tpl_wb[QUOTA_SHEET]

    # Pass 1: name lookup from mapping
    mapped_cells: set[str] = set()
    for section, fields in mapping.items():
        if section.startswith("_"):
            continue
        for field_def in fields.values():
            if not isinstance(field_def, dict):
                continue
            if field_def.get("source_type") == "name_lookup":
                cell_coord = field_def.get("cell")
                excel_key  = field_def.get("excel_key")
                if cell_coord and excel_key:
                    new_val     = name_lookup.get(excel_key)
                    target_cell = ws[cell_coord]
                    target_cell.value = _scale_for_pct(target_cell, new_val)
                    mapped_cells.add(cell_coord.upper())

    # Pass 2: row-reference fallback
    for row in ws.iter_rows():
        for cell in row:
            if cell.coordinate.upper() in mapped_cells:
                continue
            if (
                cell.value is not None
                and isinstance(cell.value, str)
                and PLACEHOLDER_RE.match(cell.value.strip())
            ):
                new_val   = _resolve_by_row(cell.value, row_lookup)
                cell.value = _scale_for_pct(cell, new_val)

    buf = io.BytesIO()
    tpl_wb.save(buf)
    return buf.getvalue()


# ── CLI entry point ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fill Quota Spec Excel from Version Spec data.")
    parser.add_argument("--template", default="Quota Spec.xlsm",
                        help="Path to Quota Spec template (default: Quota Spec.xlsm)")
    parser.add_argument("--excel",    default="Sample.xlsx",
                        help="Path to Sample.xlsx data file (default: Sample.xlsx)")
    parser.add_argument("--mapping",  default=None,
                        help="Path to quota_spec_mapping.json (default: quota_spec_mapping.json next to this script)")
    parser.add_argument("--output",   default="output/Quota_Spec_Output.xlsx",
                        help="Where to save the filled output (default: output/Quota_Spec_Output.xlsx)")
    args = parser.parse_args()

    fill_quota_spec(
        template_path=args.template,
        excel_path=args.excel,
        mapping_path=args.mapping,
        output_path=args.output,
    )
