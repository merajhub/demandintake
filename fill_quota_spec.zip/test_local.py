"""
test_local.py

Generates a test JSON payload from the two sample files and calls the
Azure Function running locally (func start).

Usage:
    # Terminal 1 — start the function
    cd azure_function
    func start

    # Terminal 2 — run this test
    cd azure_function
    python test_local.py
"""

import base64
import io
import json
import os
import urllib.request
import urllib.error
import zipfile

BASE_DIR        = os.path.dirname(os.path.abspath(__file__))
WORD_COPY_FILE  = os.path.join(BASE_DIR, "..", "Sample-Copy.docx")
QUOTA_FILE      = os.path.join(BASE_DIR, "..", "Quota Spec.xlsm")
EXCEL_FILE      = os.path.join(BASE_DIR, "..", "Sample.xlsx")

FUNCTION_COPY_URL     = "http://localhost:7071/api/fill-document-copy"
FUNCTION_COMBINED_URL = "http://localhost:7071/api/fill-document"


def encode_file(path: str) -> str:
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()


def call_copy_endpoint():
    """Original fill-document-copy: Word only."""
    url      = FUNCTION_COPY_URL
    out_path = os.path.join(BASE_DIR, "Scope_Copy_Output.docx")
    print(f"\n[fill-document-copy] Encoding input files ...")
    payload = {
        "word_template": encode_file(WORD_COPY_FILE),
        "excel_file":    encode_file(EXCEL_FILE),
    }
    _post_and_save(url, payload, out_path)


def call_combined_pam_only():
    """New fill-document endpoint: PAM (Word) only."""
    url      = FUNCTION_COMBINED_URL
    out_path = os.path.join(BASE_DIR, "Combined_PAM_Output.docx")
    print(f"\n[fill-document / PAM only] Encoding input files ...")
    payload = {
        "PAM":        encode_file(WORD_COPY_FILE),
        "excel_file": encode_file(EXCEL_FILE),
    }
    _post_and_save(url, payload, out_path)


def call_combined_quota_only():
    """New fill-document endpoint: Quota only."""
    url      = FUNCTION_COMBINED_URL
    out_path = os.path.join(BASE_DIR, "Combined_Quota_Output.xlsx")
    print(f"\n[fill-document / Quota only] Encoding input files ...")
    payload = {
        "Quota":      encode_file(QUOTA_FILE),
        "excel_file": encode_file(EXCEL_FILE),
    }
    _post_and_save(url, payload, out_path)


def call_combined_both():
    """New fill-document endpoint: PAM + Quota → ZIP."""
    url = FUNCTION_COMBINED_URL
    print(f"\n[fill-document / PAM + Quota] Encoding input files ...")
    payload = {
        "PAM":        encode_file(WORD_COPY_FILE),
        "Quota":      encode_file(QUOTA_FILE),
        "excel_file": encode_file(EXCEL_FILE),
    }
    body = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    print(f"Calling {url} ...")
    try:
        with urllib.request.urlopen(req) as resp:
            result_bytes = resp.read()
        # unpack the ZIP
        with zipfile.ZipFile(io.BytesIO(result_bytes)) as zf:
            for name in zf.namelist():
                out_path = os.path.join(BASE_DIR, name)
                zf.extract(name, BASE_DIR)
                print(f"  Extracted: {out_path}")
        print("Success!")
    except urllib.error.HTTPError as exc:
        print(f"HTTP {exc.code}: {exc.read().decode()}")
    except urllib.error.URLError as exc:
        print(f"Connection error: {exc.reason}")
        print("Is 'func start' running in the azure_function directory?")


def _post_and_save(url: str, payload: dict, out_path: str):
    body = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    print(f"Calling {url} ...")
    try:
        with urllib.request.urlopen(req) as resp:
            result_bytes = resp.read()
            with open(out_path, "wb") as f:
                f.write(result_bytes)
            print(f"Success! Output saved to: {out_path}")
    except urllib.error.HTTPError as exc:
        print(f"HTTP {exc.code}: {exc.read().decode()}")
    except urllib.error.URLError as exc:
        print(f"Connection error: {exc.reason}")
        print("Is 'func start' running in the azure_function directory?")


def main():
    call_copy_endpoint()       # existing route: Word only
    call_combined_pam_only()   # new route: PAM only  → .docx
    call_combined_quota_only() # new route: Quota only → .xlsx
    call_combined_both()       # new route: both       → .zip


if __name__ == "__main__":
    main()
