"""
scope_logic.py

Core document-filling logic.
Works entirely in memory using BytesIO — no local file paths required.
Called by the Azure Function HTTP trigger in function_app.py.
"""

import io
import re

import openpyxl
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

# ── table indices (0-based) in the Word template ─────────────────────────────
SCOPE_TABLE_IDX  = 5   # Scope of the Project  (single-cell, pipe-delimited)
INTRO_TABLE_IDX  = 10  # Introduction and General Project Information
DESIGN_TABLE_IDX = 11  # Design and Inputs
SAMPLE_TABLE_IDX   = 12  # Sample, Fieldwork, and Data Protection
DELIVERY_TABLE_IDX = 13  # Data Delivery
FINANCE_TABLE_IDX  = 14  # Finance, Administration, and Closure

EXCEL_SHEET = "Version Spec"

# ── hand-crafted overrides for ambiguous field names ─────────────────────────
FIELD_OVERRIDES = {
    "total markets"   : "Total # Markets",
    "total cells"     : "Total # Cells",
    "total sample size": "Total Sample Size (All Design Blocks)",
}


# ── Excel helpers ─────────────────────────────────────────────────────────────

def _build_lookup(ws) -> dict:
    """Build key→value dict from columns A and B of the worksheet."""
    lookup = {}
    for row in ws.iter_rows(min_col=1, max_col=2, values_only=True):
        key, val = row
        if key is not None:
            lookup[str(key).strip()] = val
    return lookup


def _normalise(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9 ]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def lookup_value(field: str, lookup: dict) -> str:
    """
    Resolve a field name to its Excel value using three strategies:
      1. Hand-crafted overrides (handles ambiguous duplicate keys)
      2. Exact key match
      3. Normalised fuzzy match (all tokens of field present in key)
    Special case: Client Name = 'Other' → uses 'Other Client Name'.
    """
    norm = _normalise(field)

    # 1. overrides
    if norm in FIELD_OVERRIDES:
        val = lookup.get(FIELD_OVERRIDES[norm])
        return str(val) if val is not None else "N/A"

    # 2. exact
    if field in lookup:
        val = lookup[field]
        if field == "Client Name" and str(val).strip() == "Other":
            val = lookup.get("Other Client Name", val)
        return str(val) if val is not None else "N/A"

    # 3. fuzzy
    tokens = norm.split()
    for key, val in lookup.items():
        if all(t in _normalise(key) for t in tokens) and val is not None:
            return str(val)

    return "N/A"


def _parse_cell_refs(text: str) -> list:
    """
    Extract Excel row numbers from 'Version Spec!Bxx' references.
    Ranges like B41-43 are expanded to [41, 42, 43].
    """
    seen, result = set(), []

    # Pass 1 – expand ranges
    range_text = text
    for m in re.finditer(r"Version Spec!B(\d+)-(\d+)", text, re.IGNORECASE):
        for r in range(int(m.group(1)), int(m.group(2)) + 1):
            if r not in seen:
                seen.add(r)
                result.append(r)
        range_text = range_text[:m.start()] + " " * (m.end() - m.start()) + range_text[m.end():]

    # Pass 2 – single refs
    for m in re.finditer(r"Version Spec!B(\d+)", range_text, re.IGNORECASE):
        r = int(m.group(1))
        if r not in seen:
            seen.add(r)
            result.append(r)

    return result


# ── Word helpers ──────────────────────────────────────────────────────────────

def _add_run(para, text: str, bold: bool = False,
             color: str = "000000", size_pt: float = 9):
    run = para.add_run(text)
    run.bold = bold
    run.font.size = Pt(size_pt)
    run.font.name = "Arial"
    r, g, b = int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)
    run.font.color.rgb = RGBColor(r, g, b)
    return run


def _clear_cell(cell):
    """Remove all runs, SDTs, and proofErr from the first paragraph of a cell."""
    p_elem = cell.paragraphs[0]._p
    for tag in (qn("w:r"), qn("w:sdt"), qn("w:hyperlink"), qn("w:proofErr")):
        for el in p_elem.findall(tag):
            p_elem.remove(el)


def _set_cell_text(cell, text: str):
    """Clear a cell and write text as a single blue Arial 9pt run."""
    _clear_cell(cell)
    # Keep only the first paragraph
    for p in cell._tc.findall(qn("w:p"))[1:]:
        cell._tc.remove(p)
    para = cell.paragraphs[0]
    para.clear()
    _add_run(para, text, bold=False, color="0070C0")


# ── Section fillers ───────────────────────────────────────────────────────────

def _parse_scope_fields(doc: Document) -> list:
    """Extract clean field names from the pipe-delimited scope table cell."""
    raw = doc.tables[SCOPE_TABLE_IDX].rows[0].cells[0].text
    fields = []
    for part in raw.split("|"):
        clean = part.replace("*", "")
        clean = re.sub(r"Version Spec![A-Z]+\d+", "", clean, flags=re.IGNORECASE)
        clean = clean.strip().rstrip(":").strip()
        if clean:
            fields.append(clean)
    return fields


def fill_scope_table(doc: Document, lookup: dict):
    """
    Write resolved values into the Scope of the Project cell,
    preserving the original pipe-separated **Field:** value format.
    """
    fields = _parse_scope_fields(doc)
    table = doc.tables[SCOPE_TABLE_IDX]
    cell = table.rows[0].cells[0]
    _clear_cell(cell)

    for p in cell._tc.findall(qn("w:p"))[1:]:
        cell._tc.remove(p)

    para = cell.paragraphs[0]
    para.clear()
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT

    for i, field in enumerate(fields):
        value = lookup_value(field, lookup)
        if i > 0:
            _add_run(para, " | ", color="000000")
        _add_run(para, f"**{field}:**", bold=True,  color="0070C0")
        _add_run(para, f" {value}",     bold=False, color="000000")


# Matches both straight quotes and Word smart/curly quotes
_CONDITIONAL_REF_RE = re.compile(
    r'Version Spec!B(\d+)=["\u201c\u201d]([^"\u201c\u201d]+)["\u201c\u201d]\s+then\s+Version Spec!B(\d+)-(\d+)',
    re.IGNORECASE,
)


def _resolve_conditional(cell_text: str, ws) -> str | None:
    """
    Parse 'Version Spec!B<cond_row>="<val>" then Version Spec!B<start>-<end>'
    from cell_text (handles both straight and Word smart quotes).
    Returns resolved value string if pattern found, else None.
    If condition is not met, returns empty string.
    """
    m = _CONDITIONAL_REF_RE.search(cell_text)
    if not m:
        return None
    cond_row  = int(m.group(1))
    cond_val  = m.group(2).strip().lower()
    start_row = int(m.group(3))
    end_row   = int(m.group(4))

    actual = str(ws.cell(row=cond_row, column=2).value or "").strip().lower()
    if actual != cond_val:
        return ""

    parts = []
    for r in range(start_row, end_row + 1):
        label = str(ws.cell(row=r, column=1).value or "").strip()
        val   = ws.cell(row=r, column=2).value
        val_s = str(val) if val is not None else "N/A"
        n_rows = end_row - start_row + 1
        parts.append(f"{label}: {val_s}" if n_rows > 1 else val_s)
    return " | ".join(parts)


def _fill_guidelines_table(doc: Document, ws, lookup: dict, table_idx: int):
    """
    Generic filler for 3-column Area | Guidelines | Questions tables.
    Resolves values for each data row and writes into column 2 (third cell).
    """
    table = doc.tables[table_idx]
    for row in table.rows:
        field = row.cells[0].text.strip()
        if (not field
                or field.lower().startswith("area")
                or field.lower().startswith("include any")):
            continue

        cell_text = row.cells[2].text.strip()

        # Check for conditional pattern first
        conditional_value = _resolve_conditional(cell_text, ws)
        if conditional_value is not None:
            _set_cell_text(row.cells[2], conditional_value)
            continue

        ref_rows = _parse_cell_refs(cell_text)

        if ref_rows:
            parts = []
            for r in ref_rows:
                label = str(ws.cell(row=r, column=1).value or "").strip()
                val   = ws.cell(row=r, column=2).value
                val_s = str(val) if val is not None else "N/A"
                parts.append(f"{label}: {val_s}" if len(ref_rows) > 1 else val_s)
            value = " | ".join(parts)
        else:
            value = lookup_value(field, lookup)

        _set_cell_text(row.cells[2], value)


def fill_intro_table(doc: Document, ws, lookup: dict):
    """Fill the Introduction and General Project Information table."""
    _fill_guidelines_table(doc, ws, lookup, INTRO_TABLE_IDX)


def fill_design_table(doc: Document, ws, lookup: dict):
    """Fill the Design and Inputs table."""
    _fill_guidelines_table(doc, ws, lookup, DESIGN_TABLE_IDX)


def fill_sample_table(doc: Document, ws, lookup: dict):
    """Fill the Sample, Fieldwork, and Data Protection table."""
    _fill_guidelines_table(doc, ws, lookup, SAMPLE_TABLE_IDX)


def fill_delivery_table(doc: Document, ws, lookup: dict):
    """Fill the Data Delivery table."""
    _fill_guidelines_table(doc, ws, lookup, DELIVERY_TABLE_IDX)


def fill_finance_table(doc: Document, ws, lookup: dict):
    """Fill the Finance, Administration, and Closure table."""
    _fill_guidelines_table(doc, ws, lookup, FINANCE_TABLE_IDX)


# ── Public entry point ────────────────────────────────────────────────────────

def process_documents(word_bytes: bytes, excel_bytes: bytes) -> bytes:
    """
    Accept raw bytes for the Word template and Excel data file.
    Returns the filled Word document as raw bytes.

    Called by the Azure Function HTTP trigger.
    """
    # Load Word template from bytes
    doc = Document(io.BytesIO(word_bytes))

    # Load Excel
    wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), data_only=True)
    ws = wb[EXCEL_SHEET]
    lookup = _build_lookup(ws)

    # Fill all sections in sequence
    fill_scope_table(doc, lookup)
    fill_intro_table(doc, ws, lookup)
    fill_design_table(doc, ws, lookup)
    fill_sample_table(doc, ws, lookup)
    fill_delivery_table(doc, ws, lookup)
    fill_finance_table(doc, ws, lookup)

    # Serialize back to bytes
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()
