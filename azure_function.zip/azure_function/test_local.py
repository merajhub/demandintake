"""
test_local.py

Generates a test JSON payload from the two sample files and calls the
Azure Function running locally (func start).

Usage:
    # Terminal 1 — start the function
    cd azure_function
    func start

    # Terminal 2 — run this test
    cd azure_function
    python test_local.py
"""

import base64
import json
import os
import urllib.request
import urllib.error

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
WORD_FILE  = os.path.join(BASE_DIR, "..", "Sample-word.docx")
EXCEL_FILE = os.path.join(BASE_DIR, "..", "Sample-excel.xlsx")
OUT_FILE   = os.path.join(BASE_DIR, "Scope_Output.docx")

FUNCTION_URL = "http://localhost:7071/api/fill-document"


def encode_file(path: str) -> str:
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()


def main():
    print("Encoding input files...")
    payload = {
        "word_template": encode_file(WORD_FILE),
        "excel_file":    encode_file(EXCEL_FILE),
    }

    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        FUNCTION_URL,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    print(f"Calling {FUNCTION_URL} ...")
    try:
        with urllib.request.urlopen(req) as resp:
            result_bytes = resp.read()
            with open(OUT_FILE, "wb") as f:
                f.write(result_bytes)
            print(f"Success! Output saved to: {OUT_FILE}")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode()
        print(f"HTTP {exc.code}: {body}")
    except urllib.error.URLError as exc:
        print(f"Connection error: {exc.reason}")
        print("Is 'func start' running in the azure_function directory?")


if __name__ == "__main__":
    main()
