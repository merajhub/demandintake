"""
fill_from_mapping.py

Fills a Word template from an Excel data file using template_mapping.json
as the source-of-truth for where each document field comes from in Excel.

The JSON encodes the fetch logic (which row, which range, conditional rules).
This script reads it and applies it — no hardcoded row numbers here.

Usage (defaults):
    python fill_from_mapping.py

Custom paths:
    python fill_from_mapping.py --template Sample.docx --excel Sample.xlsx \
        --mapping template_mapping.json --output Scope_Output.docx
"""

import argparse
import io
import json
import pathlib
import re

import openpyxl
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

EXCEL_SHEET = "Version Spec"

# Structural: Word template table indices (0-based) per section.
# These cannot be expressed in the mapping JSON because they describe
# where in the document each section lives, not where values come from.
SECTION_TABLE_INDEX = {
    "Scope of the Project":                   5,
    "Introduction and General Project Info":  10,
    "Design and Inputs":                      11,
    "Sample, Fieldwork, and Data Protection": 12,
    "Data Delivery":                          13,
    "Finance, Administration, and Closure":   14,
}


# ── Excel helpers ──────────────────────────────────────────────────────────────

def _build_lookup(ws) -> dict:
    """Build {row_label: value} dict from columns A and B of the worksheet."""
    lookup = {}
    for row in ws.iter_rows(min_col=1, max_col=2, values_only=True):
        key, val = row
        if key is not None:
            lookup[str(key).strip()] = val
    return lookup


def _normalise(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9 ]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _name_lookup(key: str, lookup: dict) -> str:
    """
    Resolve a field by name against Excel column A using three strategies:
      1. Exact match
      2. Fuzzy match (all tokens of key present in some Excel key)
    Special case: Client Name = 'Other' → use 'Other Client Name'.
    """
    if key in lookup:
        val = lookup[key]
        if key == "Client Name" and str(val).strip() == "Other":
            val = lookup.get("Other Client Name", val)
        return str(val) if val is not None else "N/A"

    tokens = _normalise(key).split()
    for k, val in lookup.items():
        if all(t in _normalise(k) for t in tokens) and val is not None:
            return str(val)

    return "N/A"


# ── Value resolver (JSON-driven) ───────────────────────────────────────────────

def resolve_value(field_map: dict, ws, lookup: dict) -> str:
    """
    Resolve the Excel value for a single field based on its JSON mapping entry.

    source_type values handled:
        single_ref   — one explicit excel_row
        single_refs  — one or more explicit excel_rows; joined if multiple
        row_range    — a contiguous range of excel_rows joined as "label: value" pairs
        conditional  — check condition row; read data rows if met, else return ""
        name_lookup  — fuzzy match by excel_key against Excel column A
    """
    st = field_map.get("source_type", "name_lookup")

    if st == "single_ref":
        r = field_map["excel_row"]
        val = ws.cell(row=r, column=2).value
        return str(val) if val is not None else "N/A"

    if st == "single_refs":
        rows = field_map["excel_rows"]
        if len(rows) == 1:
            val = ws.cell(row=rows[0], column=2).value
            return str(val) if val is not None else "N/A"
        parts = []
        for r in rows:
            label = str(ws.cell(row=r, column=1).value or "").strip()
            val = ws.cell(row=r, column=2).value
            parts.append(f"{label}: {str(val) if val is not None else 'N/A'}")
        return " | ".join(parts)

    if st == "row_range":
        rows = field_map["excel_rows"]
        parts = []
        for r in rows:
            label = str(ws.cell(row=r, column=1).value or "").strip()
            val = ws.cell(row=r, column=2).value
            parts.append(f"{label}: {str(val) if val is not None else 'N/A'}")
        return " | ".join(parts)

    if st == "conditional":
        cond = field_map["condition"]
        actual = str(ws.cell(row=cond["excel_row"], column=2).value or "").strip().lower()
        if actual != cond["must_equal"].lower():
            return ""  # condition not met — leave blank
        rows = field_map["if_true"]["excel_rows"]
        parts = []
        for r in rows:
            label = str(ws.cell(row=r, column=1).value or "").strip()
            val = ws.cell(row=r, column=2).value
            val_s = str(val) if val is not None else "N/A"
            parts.append(f"{label}: {val_s}" if len(rows) > 1 else val_s)
        return " | ".join(parts)

    # default: name_lookup
    return _name_lookup(field_map.get("excel_key", ""), lookup)


# ── Word helpers ───────────────────────────────────────────────────────────────

def _add_run(para, text: str, bold: bool = False,
             color: str = "000000", size_pt: float = 9):
    run = para.add_run(text)
    run.bold = bold
    run.font.size = Pt(size_pt)
    run.font.name = "Arial"
    r, g, b = int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)
    run.font.color.rgb = RGBColor(r, g, b)
    return run


def _clear_cell(cell):
    """Remove all runs, SDTs, and proofErr elements from the cell's first paragraph."""
    p_elem = cell.paragraphs[0]._p
    for tag in (qn("w:r"), qn("w:sdt"), qn("w:hyperlink"), qn("w:proofErr")):
        for el in p_elem.findall(tag):
            p_elem.remove(el)


def _set_cell_text(cell, text: str):
    """Clear a cell and write text as a single blue Arial 9pt run."""
    _clear_cell(cell)
    for p in cell._tc.findall(qn("w:p"))[1:]:
        cell._tc.remove(p)
    para = cell.paragraphs[0]
    para.clear()
    _add_run(para, text, bold=False, color="0070C0")


# ── Section fillers ────────────────────────────────────────────────────────────

def _fill_scope(doc: Document, section_map: dict, ws, lookup: dict):
    """
    Scope of the Project uses a single pipe-delimited cell.
    Each field is written as  **Field:** value | **Field:** value ...
    """
    tbl_idx = SECTION_TABLE_INDEX["Scope of the Project"]
    cell = doc.tables[tbl_idx].rows[0].cells[0]
    _clear_cell(cell)
    for p in cell._tc.findall(qn("w:p"))[1:]:
        cell._tc.remove(p)

    para = cell.paragraphs[0]
    para.clear()
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT

    for i, (field, field_map) in enumerate(section_map.items()):
        value = resolve_value(field_map, ws, lookup)
        if i > 0:
            _add_run(para, " | ", color="000000")
        _add_run(para, f"**{field}:**", bold=True, color="0070C0")
        _add_run(para, f" {value}", bold=False, color="000000")


def _fill_guidelines_table(doc: Document, tbl_idx: int, section_map: dict,
                            ws, lookup: dict):
    """
    Generic filler for 3-column  Area | Guidelines | Value  tables.
    Writes the resolved value into column index 2 for each matching row.
    """
    table = doc.tables[tbl_idx]
    for row in table.rows:
        field = row.cells[0].text.strip()
        if (not field
                or field.lower().startswith("area")
                or field.lower().startswith("include any")):
            continue
        if field not in section_map:
            continue
        value = resolve_value(section_map[field], ws, lookup)
        _set_cell_text(row.cells[2], value)


# ── Main entry point ───────────────────────────────────────────────────────────

def _fill_all(doc: Document, mapping: dict, ws, lookup: dict):
    """Apply all section mappings to an already-loaded Document and worksheet."""
    for section_name, section_map in mapping.items():
        tbl_idx = SECTION_TABLE_INDEX.get(section_name)
        if tbl_idx is None:
            print(f"WARNING: no table index configured for section '{section_name}', skipping")
            continue
        if section_name == "Scope of the Project":
            _fill_scope(doc, section_map, ws, lookup)
        else:
            _fill_guidelines_table(doc, tbl_idx, section_map, ws, lookup)


def process_documents(word_bytes: bytes, excel_bytes: bytes) -> bytes:
    """
    Accept raw bytes for the Word template and Excel data file.
    Returns the filled Word document as raw bytes.

    Loads template_mapping.json from the same directory as this file.
    Called by the Azure Function HTTP trigger.
    """
    mapping_path = pathlib.Path(__file__).parent / "template_mapping.json"
    with open(mapping_path, encoding="utf-8") as f:
        mapping = json.load(f)

    doc = Document(io.BytesIO(word_bytes))
    wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), data_only=True)
    ws = wb[EXCEL_SHEET]
    lookup = _build_lookup(ws)

    _fill_all(doc, mapping, ws, lookup)

    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


def fill_document(template_path: str, excel_path: str,
                  mapping_path: str, output_path: str):
    """Load files from disk, fill document, save to output_path."""
    with open(mapping_path, encoding="utf-8") as f:
        mapping = json.load(f)

    doc = Document(template_path)
    wb = openpyxl.load_workbook(excel_path, data_only=True)
    ws = wb[EXCEL_SHEET]
    lookup = _build_lookup(ws)

    _fill_all(doc, mapping, ws, lookup)

    doc.save(output_path)
    print(f"Done — saved to {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Fill a Word template from Excel data using a JSON field mapping."
    )
    parser.add_argument("--template", default="Sample.docx",           help="Word template path")
    parser.add_argument("--excel",    default="Sample.xlsx",            help="Excel data path")
    parser.add_argument("--mapping",  default="template_mapping.json",  help="JSON mapping path")
    parser.add_argument("--output",   default="Scope_Output.docx",      help="Output Word document path")
    args = parser.parse_args()

    fill_document(args.template, args.excel, args.mapping, args.output)
