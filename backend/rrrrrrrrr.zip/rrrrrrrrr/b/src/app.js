const path = require('path');
const express = require('express');
const cors = require("cors");
const { v4: uuidv4 } = require('uuid');
const bodyParser = require('body-parser');
const cookieParser = require("cookie-parser");
const app = express();
const { PostJSON, PostLog } = require("./util/apiservice");
const moment = require('moment-timezone');
const util = require("./util/apiservice");
const multer = require("multer");
const upload = multer({ storage: multer.memoryStorage() });
const { ssologin, getSSOUser, ssologinRelay } = require("./ssoservice/ssoservice")
const { verifyToken } = require("./auth/authservice");
const Storage_Service_URL = process.env.StorageServiceURL || "http://localhost:8083"; //todo
const { SendNotification } = require("./common/notification");
const GCC_FILE_BUCKET = process.env.FILE_BUCKET;
var FormData = require('form-data');



app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }));
app.use(cookieParser());
var jwt = require('jsonwebtoken');
const e = require('express');
require(`./config/appconfig`);

const corsOptions = {
    credentials: true,
    origin: true,
}
app.use(cors(corsOptions));
app.use(express.static(path.join(__dirname, 'public')));

const intakeRouter = require('./routes/intake');
const trackingRouter = require('./routes/tracking');
const reportingRouter = require('./routes/reporting');
const adminRouter = require('./routes/admin');
const demandRequestsRouter = require('./routes/demand-requests');
const demandReviewsRouter = require('./routes/demand-reviews');
const demandCommentsRouter = require('./routes/demand-comments');
const demandUsersRouter = require('./routes/demand-users');

// MySQL-backed route modules (prefix: mysql-)
const mysqlIntakeRouter = require('./routes/mysql-intake');
const mysqlTrackingRouter = require('./routes/mysql-tracking');
const mysqlReportingRouter = require('./routes/mysql-reporting');
const mysqlAdminRouter = require('./routes/mysql-admin');
const mysqlDemandRequestsRouter = require('./routes/mysql-demand-requests');
const mysqlDemandReviewsRouter = require('./routes/mysql-demand-reviews');
const mysqlDemandCommentsRouter = require('./routes/mysql-demand-comments');
const mysqlDemandUsersRouter = require('./routes/mysql-demand-users');
const mysqlDemandInsightsRouter = require('./routes/mysql-demand-insights');

const mysqlDemandTrackingRouter = require('./routes/mysql-demand-tracking');
const mysqlDemandTrackingInsightsRouter = require('./routes/mysql-demand-tracking-insights');


app.use('/api/intake', intakeRouter);
app.use('/api/tracking', trackingRouter);
app.use('/api/reporting', reportingRouter);
app.use('/api/admin', adminRouter);
app.use('/api/demand-requests', demandRequestsRouter);
app.use('/api/demand-reviews', demandReviewsRouter);
app.use('/api/demand-comments', demandCommentsRouter);
app.use('/api/demand-users', demandUsersRouter);

// MySQL-backed API routes
app.use('/api/mysql-intake', mysqlIntakeRouter);
app.use('/api/mysql-tracking', mysqlTrackingRouter);
app.use('/api/mysql-reporting', mysqlReportingRouter);
app.use('/api/mysql-admin', mysqlAdminRouter);
app.use('/api/mysql-demand-requests', mysqlDemandRequestsRouter);
app.use('/api/mysql-demand-reviews', mysqlDemandReviewsRouter);
app.use('/api/mysql-demand-comments', mysqlDemandCommentsRouter);
app.use('/api/mysql-demand-users', mysqlDemandUsersRouter);
app.use('/api/mysql-demand-insights', mysqlDemandInsightsRouter);

app.use('/api/mysql-demand-tracking', mysqlDemandTrackingRouter);
app.use('/api/mysql-demand-tracking-insights', mysqlDemandTrackingInsightsRouter);




let CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL// || " http://safetyverse-s2.jnj.com/gcpsqldatabase-service";
const StorageService_URI = process.env.StorageServiceURL;
const BUCKET_NAME = process.env.StorageBucketName;
const DB_NAME = global.config.SAFETY_DB;


app.get("/health", function (req, res) {
    res.send("API is up and running")
});

app.get("/", async function (req, res) {

    app.use(express.static(__dirname + "/public/browser"));
    res.sendFile(path.join(__dirname, "public/browser/index.html"));

    // let token = req.cookies.token;
    // if (!token) {
    //     ssologin(req, res);
    // } else {
    //     jwt.verify(token, global.config.JWT_Secret, async function (err, decoded) {
    //         if (err) {
    //             ssologin(req, res);
    //         } else {
    //             if (decoded.data.userid == "") {
    //                 console.log("stale user object");
    //                 ssologin(req, res);
    //             } else {
    //                 let userid = decoded.data.userid;
    //                 let correlationID = uuidv4();

    //                 let token = jwt.sign({
    //                     data: { userid: userid }
    //                 }, global.config.JWT_Secret, { expiresIn: global.config.JWT_TOKEN_TIMEOUT });

    //                 let refreshtoken = jwt.sign({
    //                     data: { userid: userid }
    //                 }, global.config.REFRESH_TOKEN_SECRET, { expiresIn: global.config.REFRESH_TOKEN_SECRET_TIMEOUT });

    //                 res.cookie("token", token, { httpOnly: true, secure: true });
    //                 res.cookie("refreshtoken", refreshtoken, { httpOnly: true, secure: true });

    //                 app.use(express.static(__dirname + "/public/browser"));
    //                 res.sendFile(path.join(__dirname, "public/browser/index.html"));
    //             }
    //         }
    //     });
    // }
});


app.post("/loginresponse", async function (req, res) {
    const { cca } = require("./ssoservice/authconfig")
    try {
        const { id_token } = req.body;
        const decoded = jwt.decode(id_token);
        debugger;
        const wwid = decoded?.employeeId;

        const username = decoded?.name;
        const output = username.replace(/\s*\[.*?\]\s*/g, '');

        let ssouserobj = {
            user_wwid: wwid,
            firstname: output ? output.split(',')[1] ? output.split(',')[1].trim() : "" : '',
            lastname: output ? output.split(',')[1] ? output.split(',')[0].trim() : "" : '',
            emailid: decoded?.email ? decoded?.email : '',
            businessunit: '',

        }
        SaveUser(ssouserobj, uuidv4());
        let token = jwt.sign({
            data: { userid: wwid }
        }, global.config.JWT_Secret, { expiresIn: global.config.JWT_TOKEN_TIMEOUT });

        let refreshtoken = jwt.sign({
            data: { userid: wwid }
        }, global.config.REFRESH_TOKEN_SECRET, { expiresIn: global.config.REFRESH_TOKEN_SECRET_TIMEOUT });

        res.cookie("token", token, { httpOnly: true, secure: true });
        res.cookie("refreshtoken", refreshtoken, { httpOnly: true, secure: true });
        app.use(express.static(__dirname + "/public/browser"));
        res.sendFile(path.join(__dirname, "public/browser/index.html"));
    } catch (error) {
        console.log(error);
        res.status(500).send(error);
    }


    //     const tokenRequest = {
    //         code: req.query.code,
    //         scopes: ["user.read"],
    //         redirectUri: global.config.REDIRECT_URI
    //     };

    //     const response = await cca.acquireTokenByCode(tokenRequest);

    //     let correlationID = uuidv4();
    //     let ssouserobj = await getSSOUser(response.accessToken);
    //     SaveUser(ssouserobj, uuidv4());
    //     console.log("----------------------------------SaveUser");

    //     let easternTime = moment(new Date()).utc().format('YYYY-MM-DD HH:mm:ss');
    //     PostLog("info", JSON.stringify({ "message": `User ${ssouserobj.firstname} ${ssouserobj.lastname} [${ssouserobj.user_wwid}] logged in at ${easternTime}` }));


    //     let userObj = {
    //         "wwid": ssouserobj.user_wwid,
    //         "UserName": ssouserobj.firstname + " " + ssouserobj.lastname,
    //         "EmailID": ssouserobj.emailid,
    //     }


    //     let token = jwt.sign({
    //         data: { userid: userObj.wwid }
    //     }, global.config.JWT_Secret, { expiresIn: global.config.JWT_TOKEN_TIMEOUT });

    //     let refreshtoken = jwt.sign({
    //         data: { userid: userObj.wwid }
    //     }, global.config.REFRESH_TOKEN_SECRET, { expiresIn: global.config.REFRESH_TOKEN_SECRET_TIMEOUT });

    //     res.cookie("token", token, { httpOnly: true, secure: true });
    //     res.cookie("refreshtoken", refreshtoken, { httpOnly: true, secure: true });

    //     app.use(express.static(__dirname + "/public/browser"));
    //     res.sendFile(path.join(__dirname, "public/browser/index.html"));

    // } catch (error) {
    //     console.log(error);
    //     res.status(500).send(error);
    // }
});

app.get("/getuserdetails", async function (req, res) {
    let userid = req.userid;
    ///console.log("------------------", userid)
    let userobj = {};
    let correlationID = uuidv4();
    let userinfo_res = await GetUSerDetail(userid, correlationID);

    userobj["userid"] = userinfo_res.status ? userinfo_res.data.data[0].User_WWID : "";
    userobj["username"] = userinfo_res.status ? userinfo_res.data.data[0].UserName : "";
    userobj["useremail"] = userinfo_res.status ? userinfo_res.data.data[0].EmailID : "";
    userobj["roles"] = userinfo_res.status ? userinfo_res.data.data.filter(x => x.RoleID).map(x => ({ id: x.RoleID, name: x.RoleName })) : {};
    userobj["permissions"] = userinfo_res.status ? userinfo_res.data.data.map(x => JSON.parse(x.PermissionName)).join() : "";

    //console.log(userobj);
    let obj = {
        user: {
            userid: "2",
            username: "Bob Smith",
            useremail:  "bob@jnj.com",
            roles: [
                {
                    id: "1",
                    name: "Scrub_member"
                }
            ],
            permissions: "Admin",
            domain : "Safety"
            
        }
    }



    res.json(obj)
});

app.post('/getsignedurl', verifyToken, function (req, res) {
    let filepath = `GCCHYD/IntakeForm/REQ-${req.body.requestId}/${req.body.filename}`
    var reqobj = {
        filepath: [filepath],
        bucketname: BUCKET_NAME
    }

    PostJSON(`${StorageService_URI}/getsignedurl`, reqobj).then(data => {
        res.send(data);
    });

});


async function SaveUser(userOBJ, correlationID) {
    req_obj = {
        "queryName": "INSERT_USER",
        "database": DB_NAME,
        "parameters": {
            "ID": uuidv4(),
            "wwid": userOBJ.user_wwid,
            "UserName": userOBJ.firstname + " " + userOBJ.lastname,
            "EmailID": userOBJ.emailid,
            "BussinessUnit": userOBJ.businessunit,
            "wher_wwid": userOBJ.user_wwid
        }
    }
    let url = CLOUD_SQL_API_URL + "/customInsert"
    var queryResponse = await PostJSON(url, req_obj, correlationID);
    console.log("----------------------------------SaveUser", queryResponse);
    return queryResponse
}

async function GetUSerDetail(userid, correlationID) {
    let req_obj = {
        "queryName": "FETCH_USER_DETAIL",
        "database": DB_NAME,
        "parameters": {
            "userid": userid,
        }
    }

    let url = CLOUD_SQL_API_URL + "/customRetrieve"
    var queryResponse = await PostJSON(url, req_obj, correlationID);
    if (queryResponse.status) {
        let userinfo = queryResponse.res.length > 0 ? { status: true, data: JSON.parse(queryResponse.res) } : { status: false, data: [] };
        return userinfo;
    }

    return queryResponse
}


module.exports = app;


// select ud.user_wwid User_WWID, ud.user_name UserName,ud.email EmailID, ur.role_id RoleID , r.role_name RoleName
//      from pms_rnd.User_Details ud
//       left outer join pms_rnd.User_Role ur on ud.user_wwid = ur.user_wwid
//     left outer join pms_rnd.Role r on ur.role_id = r.Id
//           where ud.user_wwid = %s