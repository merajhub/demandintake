var jwt = require('jsonwebtoken');
require(`../config/appconfig`);

function verifyToken(req, res, next) {    
    let token = req.cookies.token;
    if (!token) {
        res.status(401).send({
            auth: false,
            message: "Token Missing!"
        })
    }
    else {
        jwt.verify(token, global.config.REFRESH_TOKEN_SECRET, function (err, decoded) {
          
            if (err) {
                console.log("JWT Verify Error came ==>", err)
                res.status(401).send({
                    auth: false,
                    message: "Failed to Authentication!"
                })
            } else {
                req.userid = decoded.data.userid;
                //req.user = decoded.user;
                next();
            }
        });
    }
    
}

module.exports = { verifyToken }