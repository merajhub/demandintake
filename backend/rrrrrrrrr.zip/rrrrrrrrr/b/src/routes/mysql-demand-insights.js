/**
 * MySQL Demand Insights Routes
 *
 * Provides aggregate / analytics data for the Demand Insights dashboard.
 * All endpoints use the Cloud SQL customRetrieve API with pre-registered queries.
 *
 * Endpoints:
 *   GET /api/mysql-demand-insights/count-by-status
 *   GET /api/mysql-demand-insights/count-by-domain
 *   GET /api/mysql-demand-insights/count-by-priority
 *   GET /api/mysql-demand-insights/count-by-type
 *   GET /api/mysql-demand-insights/count-by-domain-status
 *   GET /api/mysql-demand-insights/count-by-month
 *   GET /api/mysql-demand-insights/budget-by-domain
 *   GET /api/mysql-demand-insights/count-by-priority-domain
 *   GET /api/mysql-demand-insights/count-by-type-domain
 *   GET /api/mysql-demand-insights/count-by-month-domain
 *   GET /api/mysql-demand-insights/drilldown
 */
const express = require('express');
const router = express.Router();
const { PostJSON } = require('../util/apiservice');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME = "pms_rnd_intake";

// ─── helper: run a named custom query with no params ──────────────────────────
async function runCustomQuery(queryName, parameters = {}) {
    const reqObj = {
        queryName,
        database: DB_NAME,
        parameters
    };
    const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);
    if (response.status && response.res.length > 0) {
        return JSON.parse(response.res).data;
    }
    return [];
}

// ─── GET /count-by-status ─────────────────────────────────────────────────────
router.get('/count-by-status', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_STATUS');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-status error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch status counts' });
    }
});

// ─── GET /count-by-domain ─────────────────────────────────────────────────────
router.get('/count-by-domain', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_DOMAIN');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-domain error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch domain counts' });
    }
});

// ─── GET /count-by-priority ───────────────────────────────────────────────────
router.get('/count-by-priority', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_PRIORITY');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-priority error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch priority counts' });
    }
});

// ─── GET /count-by-type ───────────────────────────────────────────────────────
router.get('/count-by-type', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_TYPE');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-type error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch type counts' });
    }
});

// ─── GET /count-by-domain-status ──────────────────────────────────────────────
router.get('/count-by-domain-status', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_DOMAIN_AND_STATUS');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-domain-status error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch domain-status counts' });
    }
});

// ─── GET /count-by-month ──────────────────────────────────────────────────────
router.get('/count-by-month', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_MONTH');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-month error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch monthly counts' });
    }
});

// ─── GET /budget-by-domain ────────────────────────────────────────────────────
router.get('/budget-by-domain', async (req, res) => {
    try {
        const data = await runCustomQuery('BUDGET_BY_DOMAIN');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – budget-by-domain error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch budget data' });
    }
});

// ─── GET /count-by-priority-domain ────────────────────────────────────────────
router.get('/count-by-priority-domain', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_PRIORITY_AND_DOMAIN');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-priority-domain error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch priority-domain counts' });
    }
});

// ─── Cross-tab endpoints for client-side domain filtering ─────────────────────
//
// Required custom queries (register in custom_queries table):
//
// -- COUNT_REQUESTS_BY_TYPE_AND_DOMAIN
// INSERT INTO custom_queries (query_name, query, type) VALUES (
//   'COUNT_REQUESTS_BY_TYPE_AND_DOMAIN',
//   'SELECT COALESCE(type_of_request, ''Unspecified'') AS type_of_request, COALESCE(domain, ''Unspecified'') AS domain, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' GROUP BY type_of_request, domain ORDER BY type_of_request, domain',
//   'fetch'
// );
//
// -- COUNT_REQUESTS_BY_MONTH_AND_DOMAIN
// INSERT INTO custom_queries (query_name, query, type) VALUES (
//   'COUNT_REQUESTS_BY_MONTH_AND_DOMAIN',
//   'SELECT DATE_FORMAT(created_at, ''%Y-%m'') AS month, COALESCE(domain, ''Unspecified'') AS domain, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) GROUP BY month, domain ORDER BY month ASC, domain',
//   'fetch'
// );

router.get('/count-by-type-domain', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_TYPE_AND_DOMAIN');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-type-domain error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch type-domain counts' });
    }
});

router.get('/count-by-month-domain', async (req, res) => {
    try {
        const data = await runCustomQuery('COUNT_REQUESTS_BY_MONTH_AND_DOMAIN');
        res.json({ status: true, data });
    } catch (error) {
        console.error('Insights – count-by-month-domain error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch month-domain counts' });
    }
});

// ─── GET /drilldown ───────────────────────────────────────────────────────────
// Returns actual request rows matching chart-click filters.
// Query params (all optional):  status, domain, priority_level, type_of_request, month
// e.g. /drilldown?status=approved  or  /drilldown?domain=Safety&status=submitted
router.get('/drilldown', async (req, res) => {
    try {
        const { status, domain, priority_level, type_of_request, month } = req.query;

        // Build WHERE clauses dynamically
        const conditions = ["status != 'draft'"];
        const parameters = {};

        if (status) {
            const statusList = status.split(',').map(s => s.trim()).filter(Boolean);
            if (statusList.length === 1) {
                conditions.push(`status = '${statusList[0]}'`);
            } else {
                const inClause = statusList.map(s => `'${s}'`).join(',');
                conditions.push(`status IN (${inClause})`);
            }
        }
        if (domain) {
            if (domain === 'Unspecified') {
                conditions.push('(domain IS NULL OR domain = \'\')');
            } else {
                conditions.push(`domain = '${domain}'`);
                parameters.domain = domain;
            }
        }
        if (priority_level) {
            if (priority_level === 'Unspecified') {
                conditions.push('(priority_level IS NULL OR priority_level = \'\')');
            } else {
                conditions.push(`priority_level = '${priority_level}'`);
                parameters.priorityLevel = priority_level;
            }
        }
        if (type_of_request) {
            if (type_of_request === 'Unspecified') {
                conditions.push('(type_of_request IS NULL OR type_of_request = \'\')');
            } else {
                conditions.push(`type_of_request = '${type_of_request}'`);
                parameters.typeOfRequest = type_of_request;
            }
        }
        if (month) {
            // month comes as "YYYY-MM"
            conditions.push(`DATE_FORMAT(created_at, '%Y-%m') = '${month}'`);
            parameters.month = month;
        }

        const whereClause = conditions.join(' AND ');
        console.log("----", whereClause)
        //const sql = `SELECT id, project_title, domain, status, priority_level, type_of_request, estimated_budget_usd, requestor_name, department, created_at FROM pms_rnd_intake.demand_requests WHERE ${whereClause} ORDER BY created_at DESC`;

        const reqObj = {
            queryName: 'GET_CHART_DRILL_DOWN_DATA',
            database: DB_NAME,
            parameters: {
                "where_clause": whereClause
            }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetriveQueryWithoutPagination`, reqObj);
        if (response.status && response.res.length > 0) {
            const data = JSON.parse(response.res);
            res.json({ status: true, data });
        } else {
            res.json({ status: true, data: [] });
        }
    } catch (error) {
        console.error('Insights – drilldown error:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch drilldown data' });
    }
});

module.exports = router;
