/**
 * MySQL Reporting Routes
 *
 * Mirrors reporting.js but uses the MySQL demand_requests table schema
 * defined in mysql-schema-and-queries.sql.
 *
 * Endpoints:
 *   GET /api/mysql-reporting/chart
 *   GET /api/mysql-reporting/count-by-status
 *   GET /api/mysql-reporting/count-by-domain
 *   GET /api/mysql-reporting/count-by-priority
 */
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { PostJSON } = require('../util/apiservice');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME = global.config.SAFETY_DB;

// ─── GET /chart — get chart data via stored procedure ─────────────────────────
router.get('/chart', async (req, res) => {
    try {
        let reqObj = {
            sp_name: 'getChartData',
            database: DB_NAME,
            parameters: {
                param0: 'fake param',
            }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj);
        res.send(response);
    } catch (error) {
        console.error('Error fetching chart data:', error);
        res.send({ status: false, message: 'Failed to fetch chart data' });
    }
});

// ─── GET /count-by-status — count requests grouped by status ──────────────────
router.get('/count-by-status', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'COUNT_REQUESTS_BY_STATUS',
            database: DB_NAME,
            parameters: {}
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error('Error fetching status counts:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch status counts' });
    }
});

// ─── GET /count-by-domain — count requests grouped by domain ──────────────────
router.get('/count-by-domain', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'COUNT_REQUESTS_BY_DOMAIN',
            database: DB_NAME,
            parameters: {}
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error('Error fetching domain counts:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch domain counts' });
    }
});

// ─── GET /count-by-priority — count requests grouped by priority ─────────────
router.get('/count-by-priority', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'COUNT_REQUESTS_BY_PRIORITY',
            database: DB_NAME,
            parameters: {}
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error('Error fetching priority counts:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch priority counts' });
    }
});

module.exports = router;
