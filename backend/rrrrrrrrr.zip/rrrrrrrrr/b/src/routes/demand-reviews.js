const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');
const { readJSON, writeJSON } = require('../util/json-store');

const REVIEWS_FILE = 'demand-reviews.json';

// ── File upload setup ──
const UPLOADS_DIR = path.join(__dirname, '..', 'data', 'review-attachments');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const unique = `${Date.now()}-${uuidv4().slice(0, 8)}`;
    cb(null, `${unique}-${file.originalname}`);
  },
});
const upload = multer({ storage });

// GET /api/demand-reviews?requestId=xxx&reviewType=xxx
router.get('/', (req, res) => {
  try {
    let reviews = readJSON(REVIEWS_FILE);
    const { requestId, reviewType } = req.query;

    if (requestId) {
      reviews = reviews.filter(r => r.requestId === requestId);
    }
    if (reviewType) {
      reviews = reviews.filter(r => r.reviewType === reviewType);
    }

    // Sort by createdAt asc (oldest first)
    reviews.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    res.json(reviews);
  } catch (err) {
    console.error('Error reading reviews:', err);
    res.status(500).json({ error: 'Failed to read reviews' });
  }
});

// POST /api/demand-reviews — create or update (upsert) a review
// If a review already exists for the same requestId + reviewType + reviewerId, update it.
// Otherwise create a new one.
// Supports optional file upload via multipart/form-data (field name: "file")
router.post('/', upload.single('file'), (req, res) => {
  try {
    const reviews = readJSON(REVIEWS_FILE);
    const body = req.body;

    // Build attachment info if a file was uploaded
    let attachment = null;
    if (req.file) {
      attachment = {
        originalName: req.file.originalname,
        storedName: req.file.filename,
        size: req.file.size,
        mimeType: req.file.mimetype,
      };
    }

    // Find existing review for this reviewer on this request+type
    const existingIndex = reviews.findIndex(
      r => r.requestId === body.requestId &&
           r.reviewType === body.reviewType &&
           r.reviewerId === body.reviewerId
    );

    const message = {
      from: body.from || body.reviewerId,
      fromName: body.fromName || body.reviewerName || '',
      role: body.role || '',
      remarks: body.remarks || '',
      createdAt: new Date().toISOString(),
    };
    if (attachment) {
      message.attachment = attachment;
    }

    if (existingIndex !== -1) {
      // Update existing review — append to conversation, update decision
      const existing = reviews[existingIndex];
      if (body.decision !== undefined) {
        existing.decision = body.decision;
      }
      if (!existing.conversation) {
        existing.conversation = [];
      }
      existing.conversation.push(message);
      existing.updatedAt = new Date().toISOString();
      reviews[existingIndex] = existing;
      writeJSON(REVIEWS_FILE, reviews);
      res.json(existing);
    } else {
      // Create new review
      const newReview = {
        id: uuidv4(),
        requestId: body.requestId,
        reviewType: body.reviewType, // 'scrub' or 'committee'
        reviewerId: body.reviewerId,
        reviewerName: body.reviewerName || '',
        decision: body.decision || '',
        conversation: [message],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      reviews.push(newReview);
      writeJSON(REVIEWS_FILE, reviews);
      res.status(201).json(newReview);
    }
  } catch (err) {
    console.error('Error creating/updating review:', err);
    res.status(500).json({ error: 'Failed to create/update review' });
  }
});

// GET /api/demand-reviews/attachment/:storedName — download an attachment
router.get('/attachment/:storedName', (req, res) => {
  try {
    const filePath = path.join(UPLOADS_DIR, req.params.storedName);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    res.download(filePath);
  } catch (err) {
    console.error('Error downloading attachment:', err);
    res.status(500).json({ error: 'Failed to download attachment' });
  }
});

module.exports = router;
