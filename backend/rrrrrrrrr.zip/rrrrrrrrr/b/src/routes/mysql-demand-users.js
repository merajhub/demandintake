/**
 * MySQL Demand Users Routes
 *
 * Mirrors demand-users.js but uses MySQL via the Cloud SQL API service
 * instead of local JSON files.
 *
 * Endpoints:
 *   GET /api/mysql-demand-users
 *   GET /api/mysql-demand-users/:id
 */
const express = require('express');
const router = express.Router();
const { PostJSON } = require('../util/apiservice');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME = "pms_rnd_intake";//global.config.SAFETY_DB;

// ─── GET / — return all users ─────────────────────────────────────────────────
router.get('/', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'FETCH_ALL_USERS',
            database: DB_NAME,
            parameters: {}
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            const mappedUsers = records.map(r => ({
                id: r.id,
                name: r.name,
                email: r.email,
                role: r.role,
                domain: r.domain
            }));
            res.json(mappedUsers);
        } else {
            res.json([]);
        }
    } catch (err) {
        console.error('Error reading users:', err);
        res.status(500).json({ error: 'Failed to read users' });
    }
});

// ─── GET /:id — return single user ───────────────────────────────────────────
router.get('/:id', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'FETCH_USER_BY_ID',
            database: DB_NAME,
            parameters: { userId: req.params.id }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            if (records.length === 0) {
                return res.status(404).json({ error: 'User not found' });
            }
            const r = records[0];
            res.json({
                id: r.user_id,
                name: r.user_name,
                email: r.email,
                role: r.role,
                domain: r.domain
            });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (err) {
        console.error('Error reading user:', err);
        res.status(500).json({ error: 'Failed to read user' });
    }
});

module.exports = router;
