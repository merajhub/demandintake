const express = require('express');
const router = express.Router();
const { readJSON } = require('../util/json-store');

// GET /api/demand-users — return all mock users
router.get('/', (req, res) => {
  try {
    const users = readJSON('users.json');
    res.json(users);
  } catch (err) {
    console.error('Error reading users:', err);
    res.status(500).json({ error: 'Failed to read users' });
  }
});

// GET /api/demand-users/:id — return single user
router.get('/:id', (req, res) => {
  try {
    const users = readJSON('users.json');
    const user = users.find(u => u.id === req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    console.error('Error reading user:', err);
    res.status(500).json({ error: 'Failed to read user' });
  }
});

module.exports = router;
