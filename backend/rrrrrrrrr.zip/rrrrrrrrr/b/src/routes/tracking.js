const express = require('express');
const router = express.Router();
const multer = require('multer');
var FormData = require('form-data');
const { v4: uuidv4 } = require('uuid');
const { PostJSON, PostLog, PostMethod } = require("../util/apiservice");
const upload = multer({ storage: multer.memoryStorage() });
const moment = require('moment-timezone');
require(`../config/appconfig`);


const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const StorageService_URI = process.env.StorageServiceURL;
const BUCKET_NAME = process.env.StorageBucketName;
const DB_NAME = global.config.SAFETY_DB;

router.get("/domaincount", async (req, res) => {
    const req_obj = {
        queryName: "FETCH_DOMAIN_RECORD_COUNT",
        database: DB_NAME,
        parameters: {}
    };

    try {
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, req_obj);
        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(500).json({ status: false, message: "Failed to fetch intake forms" });
        }
    } catch (error) {
        console.error("Error fetching intake forms:", error);
        res.status(500).json({ status: false, message: "Failed to fetch intake forms" });
    }
});


router.get("/:id", async (req, res) => {
    const req_obj = {
        queryName: "FETCG_TRACKING_STATUS_BY_ID",
        database: DB_NAME,
        parameters: {
            domain: req.params.id
        }
    };

    try {
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, req_obj);
        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error("Error fetching intake forms:", error);
        res.status(500).json({ status: false, error: response.message });
    }
});

router.get("/getdomainrequests/:domain", async (req, res) => {
    const req_obj = {
        queryName: "FETCH_TRACKING_REQUESTS_BY_DOMAIN",
        database: DB_NAME,
        parameters: {
            domain: req.params.domain
        }
    };

    try {
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, req_obj);
        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error("Error fetching intake forms:", error);
        res.status(500).json({ status: false, error: response.message });
    }
});

router.post("/", async (req, res) => {
    try {
        let correlationID = uuidv4();
        
        let data = req.body;

        const response = await SaveTrackingStatusAsync(data, correlationID);
        debugger;
        if (response.status) {
            const emailObj = {
                requestId: response.res[0].requestId,
                typeOfRequest: data.typeOfRequest,
                userName: data.requestorName,
                projectTitle: data.projectTitle,
                requestorEmail: data.requestorEmail,
                receiverEmail: '', // TODO: Replace with a dynamic recipient list
                cc_EmailList: []
            };

            // SendNotification(emailObj, "INTAKE_FORM_SUBMISSION");
            res.status(200).json({ status: true, message: "Intake form saved successfully" });
        }
        else {
            res.status(500).json({ status: false, message: "Failed to save intake form" });
        }

    } catch (error) {
        console.error("Error saving intake form:", error);
        res.status(500).json({ status: false, message: "Failed to save intake form" });
    }
});


router.post("/update", async function (req, res) {
    let correlationID = uuidv4();
    let response;
    const { requestorEmail, userWWID,  ...reqData } = req.body.rowdata;

    reqData.devEndDate = reqData.devEndDate
                    ? moment(reqData.devEndDate).format('YYYY-MM-DD')
                    : null;
    reqData.qaEndDate = reqData.qaEndDate
                    ? moment(reqData.qaEndDate).format('YYYY-MM-DD')
                    : null;
    reqData.prodEndDate = reqData.prodEndDate
                    ? moment(reqData.prodEndDate).format('YYYY-MM-DD')
                    : null;

     reqData.devActualEndDate = reqData.devActualEndDate
                    ? moment(reqData.devActualEndDate).format('YYYY-MM-DD')
                    : null;
    reqData.qaActualEndDate = reqData.qaActualEndDate
                    ? moment(reqData.qaActualEndDate).format('YYYY-MM-DD')
                    : null;
    reqData.proActualEndDate = reqData.proActualEndDate
                    ? moment(reqData.proActualEndDate).format('YYYY-MM-DD')
                    : null;
    
    try {
        let reqObj = {
            "sp_name": "updateStatus",
            "database": DB_NAME,
            "parameters": {
                "param0": req.body.requestId,
                "param1": JSON.stringify(reqData)
            }
        }
        response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj, correlationID);
        if (response.status) {
           
            SaveTrackingAuditAsync(reqData, req.body.requestId,  userWWID, correlationID);

            res.status(200).json({ status: true, res: response });
        }
        else{
            res.status(500).json({ status: false, res: response });
        }
       
    } catch (error) {
        console.error("Error updating intake form:", error);
        response = { status: false, res: "Failed to update intake form" };
    }

    //res.status(200).send(response);
});

router.get("/audit/:id", async (req, res) => {

     const req_obj = {
        queryName: "FETCH_TRACKING_AUDIT_BY_ID",
        database: DB_NAME,
        parameters: {
            domain: req.params.id
        }
    };

    try {
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, req_obj);
        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error("Error fetching intake forms:", error);
        res.status(500).json({ status: false, error: response.message });
    }

});



async function SaveTrackingStatusAsync(formData, correlationID) {
    const utcTime = moment(new Date()).utc().format('YYYY-MM-DD HH:mm:ss');


    let tbl_obj = {
        requestID: formData.requestId,
        devEndDate: formData.devEndDate
                    ? moment(formData.devEndDate).format('YYYY-MM-DD')
                    : null, 
        qaEndDate:  formData.qaEndDate
                    ? moment(formData.qaEndDate).format('YYYY-MM-DD')
                    : null,
        prodEndDate:  formData.prodEndDate
                    ? moment(formData.prodEndDate).format('YYYY-MM-DD')
                    : null,

        devActualEndDate:  formData.devActualEndDate
                    ? moment(formData.devActualEndDate).format('YYYY-MM-DD')
                    : null,
        qaActualEndDate:  formData.qaActualEndDate
                    ? moment(formData.qaActualEndDate).format('YYYY-MM-DD')
                    : null,
        proActualEndDate:  formData.proActualEndDate
                    ? moment(formData.proActualEndDate).format('YYYY-MM-DD')
                    : null,
        releaseStatus: formData.releaseStatus,
        schedule: formData.schedule,
        resources: formData.resources,
        risks: formData.risks,
        scope: formData.scope,
        comments: formData.comments,
        version: formData.version,


    };

    const req_obj = {
        table: "project_status",
        database: DB_NAME,
        data: [tbl_obj]
    };

    let resp = await PostJSON(CLOUD_SQL_API_URL + "/insert", req_obj, correlationID);
    SaveTrackingAuditAsync(tbl_obj, formData.requestId, formData.requestor_wwid, correlationID)
    return resp;
}


async function SaveTrackingAuditAsync(formData, requestId, wwid, correlationID) {
    const utcTime = moment(new Date()).utc().format('YYYY-MM-DD HH:mm:ss');


    let tbl_obj = {
        requestID: requestId,
        devEndDate: formData.devEndDate
                    ? moment(formData.devEndDate).format('YYYY-MM-DD')
                    : null, 
        qaEndDate:  formData.qaEndDate
                    ? moment(formData.qaEndDate).format('YYYY-MM-DD')
                    : null,
        prodEndDate:  formData.prodEndDate
                    ? moment(formData.prodEndDate).format('YYYY-MM-DD')
                    : null,


        devActualEndDate: formData.devActualEndDate
                    ? moment(formData.devActualEndDate).format('YYYY-MM-DD')
                    : null, 
        qaActualEndDate:  formData.qaActualEndDate
                    ? moment(formData.qaActualEndDate).format('YYYY-MM-DD')
                    : null,
        proActualEndDate:  formData.proActualEndDate
                    ? moment(formData.proActualEndDate).format('YYYY-MM-DD')
                    : null,
        releaseStatus: formData.releaseStatus,
        schedule: formData.schedule,
        resources: formData.resources,
        risks: formData.risks,
        scope: formData.scope,
        comments: formData.comments,
        version: formData.version,
        created_by : wwid,
        created_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),



    };
    const req_obj = {
        table: "request_status_audit",
        database: DB_NAME,
        data: [tbl_obj]
    };

    let resp = await PostJSON(CLOUD_SQL_API_URL + "/insert", req_obj, correlationID);
    console.log("----------------------------------------------", resp)
    //return resp;
}


module.exports = router;