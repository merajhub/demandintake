const express = require('express');
const router = express.Router();
const multer = require('multer');
var FormData = require('form-data');
const { v4: uuidv4 } = require('uuid');
const { PostJSON, PostMethod } = require('../util/apiservice');
const upload = multer({ storage: multer.memoryStorage() });
const moment = require('moment-timezone');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const StorageService_URI = process.env.StorageServiceURL;
const BUCKET_NAME = process.env.StorageBucketName;
const DB_NAME = global.config.SAFETY_DB;

router.get('/all', async (req, res) => {
    const req_obj = {
        queryName: 'FETCH_ALL_INTAKE_REQUEST',
        database: DB_NAME,
        parameters: {}
    };

    let response = await fetchIntakeForms(req_obj);
    if (response.status) {
        res.status(200).json(response.data);
    } else {
        res.status(500).json({ error: response.message });
    }
});

// ─── GET /bydomain/:domain — fetch requests filtered by domain ───────────────
router.get('/bydomain/:domain', async (req, res) => {
    const req_obj = {
        queryName: 'FETCH_MY_INTAKE_REQUEST_BY_DOMAIN',
        database: DB_NAME,
        parameters: {
            domain: req.params.domain
        }
    };

    let response = await fetchIntakeForms(req_obj);
    if (response.status) {
        res.status(200).json(response.data);
    } else {
        res.status(500).json({ error: response.message });
    }
});

// ─── GET /myrequests/:wwid — fetch requests by requestor WWID ────────────────
router.get('/myrequests/:wwid', async (req, res) => {
    const req_obj = {
        queryName: 'FETCH_REQUEST_BY_USER_DOMAIN',
        database: DB_NAME,
        parameters: {
            domain: req.params.wwid
        }
    };

    let response = await fetchIntakeForms(req_obj);
    if (response.status) {
        res.status(200).json(response.data);
    } else {
        res.status(500).json({ error: response.message });
    }
});

// ─── GET /:id — get intake form by ID ────────────────────────────────────────
router.get('/:id', async (req, res) => {
    try {
        const requestId = req.params.id;
        if (!requestId) {
            return res.status(400).json({ message: 'requestId is required' });
        }

        const response = await getIntakeDetailsByID(requestId);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json(records);
        } else {
            res.status(200).json([]);
        }
    } catch (error) {
        console.error('Error fetching intake form by ID:', error);
        res.status(500).json({ message: 'Failed to fetch intake form by ID' });
    }
});

// ─── POST / — save new intake form ──────────────────────────────────────────
router.post('/', upload.array('files'), async (req, res) => {
    try {
        let correlationID = uuidv4();
        let file = req.files && req.files.length > 0 ? req.files[0] : null;
        let data = JSON.parse(req.body.record);

        const response = await SaveIntakeFormAsync(data, correlationID);

        if (response.status) {
            if (file) {
                let filepath = `GCCHYD/IntakeForm/REQ-${response.res[0].requestId}/${file.originalname}`;
                await SyncUploadFile(file, filepath, correlationID);
            }

            res.status(200).json({ status: true, message: 'Intake form saved successfully' });
        } else {
            res.status(500).json({ status: false, message: 'Failed to save intake form' });
        }
    } catch (error) {
        console.error('Error saving intake form:', error);
        res.status(500).json({ status: false, message: 'Failed to save intake form' });
    }
});

// ─── POST /update — update an existing intake form ──────────────────────────
router.post('/update', upload.array('files'), async (req, res) => {
    let response;
    let correlationID = uuidv4();
    const { requestorEmail, domain, ...reqData } = JSON.parse(req.body.rowdata);

    const utcTime = moment(new Date()).utc().format('YYYY-MM-DD HH:mm:ss');

    reqData.dateOfSubmission = reqData.dateOfSubmission
        ? moment(reqData.dateOfSubmission).format('YYYY-MM-DD')
        : utcTime;
    reqData.estimatedCompletionDate = reqData.estimatedCompletionDate
        ? moment(reqData.estimatedCompletionDate).format('YYYY-MM-DD')
        : utcTime;
    reqData.estimatedStartDate = reqData.estimatedStartDate
        ? moment(reqData.estimatedStartDate).format('YYYY-MM-DD')
        : utcTime;

    try {
        let reqObj = {
            sp_name: 'updateRequest',
            database: DB_NAME,
            parameters: {
                param0: req.body.requestId,
                param1: JSON.stringify(reqData)
            }
        };

        response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj, correlationID);

        if (response.status) {
            let file = req.files && req.files.length > 0 ? req.files[0] : null;
            if (file) {
                let filepath = `GCCHYD/IntakeForm/REQ-${req.body.requestId}/${file.originalname}`;
                await SyncUploadFile(file, filepath, correlationID);
            }
        }
        res.status(200).send(response);
    } catch (error) {
        console.error('Error updating intake form:', error);
        res.status(200).send({ status: false, message: 'Failed to update intake form' });
    }
});

// ─── POST /updatestatus — update status only ─────────────────────────────────
router.post('/updatestatus', async (req, res) => {
    const { requestId, status } = req.body;
    const correlationID = uuidv4();

    let reqObj = {
        queryName: 'UPDATE_STATUS',
        database: DB_NAME,
        parameters: {
            status: status,
            requestId: requestId,
        }
    };

    const response = await PostJSON(`${CLOUD_SQL_API_URL}/customUpdate`, reqObj, correlationID);
    res.status(200).send(response);
});

// ─── Helper: fetch intake form by ID ──────────────────────────────────────────
async function getIntakeDetailsByID(requestId) {
    let req_obj = {
        queryName: 'FETCH_INTAKE_BY_ID',
        database: DB_NAME,
        parameters: {
            requestId: requestId
        }
    };

    let response = await PostJSON(CLOUD_SQL_API_URL + '/customRetrieve', req_obj);
    return response;
}

// ─── Helper: save new intake form ─────────────────────────────────────────────
async function SaveIntakeFormAsync(formData, correlationID) {
    const utcTime = moment(new Date()).utc().format('YYYY-MM-DD HH:mm:ss');

    let tbl_obj = {
        project_title: formData.projectTitle,
        requestor_name: formData.requestorName,
        department: formData.department,
        contact_email: formData.contactEmail,
        contact_phone: formData.contactPhone,
        date_of_submission: formData.dateOfSubmission
            ? moment(formData.dateOfSubmission).format('YYYY-MM-DD')
            : utcTime,
        platform: formData.platform,
        compliance_requirements: formData.complianceRequirements,
        type_of_request: formData.typeOfRequest?.value || formData.typeOfRequest,
        project_description: formData.projectDescription,
        project_goals: formData.projectGoals,
        business_problem: formData.businessProblem,
        expected_outcome: formData.expectedOutcome,
        estimated_completion_date: formData.estimatedCompletionDate
            ? moment(formData.estimatedCompletionDate).format('YYYY-MM-DD')
            : null,
        estimated_start_date: formData.estimatedStartDate
            ? moment(formData.estimatedStartDate).format('YYYY-MM-DD')
            : null,
        resource_requirements: formData.resourceRequirements,
        target_users: formData.targetUsers,
        priority_level: formData.priorityLevel?.value || formData.priorityLevel,
        dependencies: formData.dependencies,
        status: formData.status || 'Pending',
        technology_preference: formData.technologyPreference,
        estimated_budget_usd: formData.estimatedBudget,
        stakeholders: formData.stakeholders,
        risks: formData.risks,
        review_notes: formData.reviewNotes,
        additional_notes: formData.additionalNotes,
        approval_signoff: formData.approvalSignoff,
        requestor_wwid: formData.requestor_wwid,
        domain: formData.domain,
        pm_scrum_master: formData.pm_scrum_master,
        requestor_email: formData.requestorEmail,
    };

    const req_obj = {
        table: 'demand_requests',
        database: DB_NAME,
        data: [tbl_obj]
    };

    return await PostJSON(CLOUD_SQL_API_URL + '/insert', req_obj, correlationID);
}

// ─── Helper: upload file to storage service ───────────────────────────────────
async function SyncUploadFile(fileobj, filepath, correlationID) {
    let formData = new FormData();
    formData.append('file', fileobj.buffer, {
        name: 'file',
        filename: fileobj.originalname,
    });
    formData.append('filepath', filepath);
    formData.append('bucketname', BUCKET_NAME);
    try {
        let response = await PostMethod(StorageService_URI + '/uploadfilestream', formData, correlationID);
        return response;
    } catch (exc) {
        console.log('error came at UploadFile', exc.message);
        return { status: false };
    }
}

// ─── Helper: generic fetch intake forms ───────────────────────────────────────
async function fetchIntakeForms(reqObj) {
    try {
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);
        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            return { status: true, data: records };
        } else {
            return { status: true, data: [] };
        }
    } catch (error) {
        console.error('Error fetching intake forms:', error);
        return { status: false, message: 'Failed to fetch intake forms' };
    }
}

module.exports = router;
