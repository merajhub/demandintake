const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { readJSON, writeJSON } = require('../util/json-store');

const COMMENTS_FILE = 'demand-comments.json';

// GET /api/demand-comments?requestId=xxx
router.get('/', (req, res) => {
  try {
    let comments = readJSON(COMMENTS_FILE);
    const { requestId } = req.query;

    if (requestId) {
      comments = comments.filter(c => c.requestId === requestId);
    }

    // Sort by createdAt asc (chronological)
    comments.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    res.json(comments);
  } catch (err) {
    console.error('Error reading comments:', err);
    res.status(500).json({ error: 'Failed to read comments' });
  }
});

// POST /api/demand-comments — add a comment
router.post('/', (req, res) => {
  try {
    const comments = readJSON(COMMENTS_FILE);
    const body = req.body;

    const newComment = {
      id: uuidv4(),
      requestId: body.requestId,
      userId: body.userId,
      userName: body.userName || '',
      userRole: body.userRole || '',
      text: body.text,
      createdAt: new Date().toISOString(),
    };

    comments.push(newComment);
    writeJSON(COMMENTS_FILE, comments);
    res.status(201).json(newComment);
  } catch (err) {
    console.error('Error creating comment:', err);
    res.status(500).json({ error: 'Failed to create comment' });
  }
});

module.exports = router;
