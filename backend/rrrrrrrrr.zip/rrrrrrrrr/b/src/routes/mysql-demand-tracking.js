/**
 * MySQL Demand Tracking Routes
 *
 * Provides tracking functionality for approved demand-intake requests.
 * Uses demand_tracking and demand_tracking_audit tables defined in
 * mysql-demand-tracking-schema.sql.
 *
 * Endpoints:
 *   GET  /api/mysql-demand-tracking                — list all approved requests with tracking data
 *   GET  /api/mysql-demand-tracking/:requestId      — single tracking record by request id
 *   GET  /api/mysql-demand-tracking/audit/:requestId — audit history
 *   POST /api/mysql-demand-tracking                 — create or update tracking record
 */
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { PostJSON } = require('../util/apiservice');
const moment = require('moment-timezone');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME = 'pms_rnd_intake';

// ─── Helper: format date safely ──────────────────────────────────────────────
function fmtDate(val) {
    return val ? moment(val).format('YYYY-MM-DD') : null;
}

// ─── GET / — list all approved requests with tracking data ───────────────────
router.get('/', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'FETCH_APPROVED_DEMAND_REQUESTS',
            database: DB_NAME,
            parameters: {}
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error('Error fetching approved demand requests:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch approved demand requests' });
    }
});

// ─── GET /audit/:requestId — fetch tracking audit history ────────────────────
router.get('/audit/:requestId', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'FETCH_DEMAND_TRACKING_AUDIT',
            database: DB_NAME,
            parameters: { requestId: req.params.requestId }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error('Error fetching demand tracking audit:', error);
        res.status(500).json({ status: false, error: error.message });
    }
});

// ─── GET /:requestId — fetch single tracking record ─────────────────────────
router.get('/:requestId', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'FETCH_DEMAND_TRACKING_BY_REQUEST_ID',
            database: DB_NAME,
            parameters: { requestId: req.params.requestId }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            if (records.length === 0) {
                return res.status(404).json({ status: false, message: 'Not found' });
            }
            res.status(200).json({ status: true, data: records[0] });
        } else {
            res.status(404).json({ status: false, message: 'Not found' });
        }
    } catch (error) {
        console.error('Error fetching demand tracking record:', error);
        res.status(500).json({ status: false, error: error.message });
    }
});

// ─── POST / — create or update tracking record ──────────────────────────────
router.post('/', async (req, res) => {
    try {
        const correlationID = uuidv4();
        const data = req.body;
        const isUpdate = !!data.trackingId;

        const trackingFields = {
            scope: data.scope || null,
            schedule: data.schedule || null,
            resources: data.resources || null,
            risks: data.risks || null,
            scope_comment: data.scopeComment || null,
            schedule_comment: data.scheduleComment || null,
            resources_comment: data.resourcesComment || null,
            risks_comment: data.risksComment || null,
            release_status: data.releaseStatus || 1,
            dev_planned_date: fmtDate(data.devPlannedDate),
            qa_planned_date: fmtDate(data.qaPlannedDate),
            prod_planned_date: fmtDate(data.prodPlannedDate),
            dev_actual_date: fmtDate(data.devActualDate),
            qa_actual_date: fmtDate(data.qaActualDate),
            prod_actual_date: fmtDate(data.prodActualDate),
            comments: data.comments || null,
        };

        let response;

        if (isUpdate) {
            // Update existing tracking record
            const updateObj = {
                ...trackingFields,
                version: (parseInt(data.version) || 0) + 1,
                updated_at: moment().utc().format('YYYY-MM-DD HH:mm:ss'),
            };

            const reqObj1 = {
                table: 'demand_tracking',
                database: DB_NAME,
                data: updateObj,
                where: { request_id: data.requestId }
            };

            let reqObj = {
                "sp_name": "updateTracking",
                "database": DB_NAME,
                "parameters": {
                    "param0": data.requestId,
                    "param1": JSON.stringify(trackingFields)
                }
            }

            response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj, correlationID);
        } else {
            // Insert new tracking record (id is auto-increment)
            const insertObj = {
                request_id: data.requestId,
                project_title: data.projectTitle || null,
                domain: data.domain || null,
                priority_level: data.priorityLevel || null,
                pm_scrum_master: data.pmScrumMaster || null,
                ...trackingFields,
                version: 1,
                created_by: data.createdBy || null,
                created_by_name: data.createdByName || null,
            };

            const reqObj = {
                table: 'demand_tracking',
                database: DB_NAME,
                data: [insertObj]
            };

            response = await PostJSON(`${CLOUD_SQL_API_URL}/insert`, reqObj, correlationID);
        }

        if (response.status) {
            // Save audit record
            await SaveDemandTrackingAudit(data, trackingFields, correlationID);
            res.status(200).json({ status: true, message: 'Tracking saved successfully' });
        } else {
            res.status(500).json({ status: false, message: 'Failed to save tracking' });
        }
    } catch (error) {
        console.error('Error saving demand tracking:', error);
        res.status(500).json({ status: false, message: 'Failed to save tracking' });
    }
});

// ─── Helper: save demand tracking audit record ──────────────────────────────
async function SaveDemandTrackingAudit(data, fields, correlationID) {
    try {
        const auditObj = {
            tracking_id: data.trackingId || null,
            request_id: data.requestId,
            scope: fields.scope,
            schedule: fields.schedule,
            resources: fields.resources,
            risks: fields.risks,
            scope_comment: fields.scope_comment,
            schedule_comment: fields.schedule_comment,
            resources_comment: fields.resources_comment,
            risks_comment: fields.risks_comment,
            release_status: fields.release_status,
            dev_planned_date: fields.dev_planned_date,
            qa_planned_date: fields.qa_planned_date,
            prod_planned_date: fields.prod_planned_date,
            dev_actual_date: fields.dev_actual_date,
            qa_actual_date: fields.qa_actual_date,
            prod_actual_date: fields.prod_actual_date,
            comments: fields.comments,
            version: (parseInt(data.version) || 0) + 1,
            updated_by: data.createdBy || null,
            updated_by_name: data.createdByName || null,
            created_at: moment().utc().format('YYYY-MM-DD HH:mm:ss'),
        };

        const reqObj = {
            table: 'demand_tracking_audit',
            database: DB_NAME,
            data: [auditObj]
        };

        await PostJSON(`${CLOUD_SQL_API_URL}/insert`, reqObj, correlationID);
    } catch (err) {
        console.error('Error saving demand tracking audit:', err);
    }
}

module.exports = router;
