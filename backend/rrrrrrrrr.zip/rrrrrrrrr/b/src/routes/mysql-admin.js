/**
 * MySQL Admin Routes
 *
 * Mirrors admin.js but uses the MySQL demand_requests table schema
 * defined in mysql-schema-and-queries.sql.
 *
 * Endpoints:
 *   GET  /api/mysql-admin/allrequests
 *   GET  /api/mysql-admin/getrequest/:userid
 *   POST /api/mysql-admin/updateRequestStatus
 *   POST /api/mysql-admin/
 *   GET  /api/mysql-admin/review-summary/:requestId
 */
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { PostJSON } = require('../util/apiservice');
const moment = require('moment-timezone');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME = global.config.SAFETY_DB;

// ─── GET /allrequests — fetch all user requests ──────────────────────────────
router.get('/allrequests', async (req, res) => {
    const req_obj = {
        queryName: 'FETCH_ALL_USER_REQUESTS',
        database: DB_NAME,
        parameters: {}
    };

    try {
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, req_obj);
        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: false, data: [] });
        }
    } catch (error) {
        console.error('Error fetching all requests:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch requests' });
    }
});

// ─── GET /getrequest/:userid — fetch requests by user ID ─────────────────────
router.get('/getrequest/:userid', async (req, res) => {
    const req_obj = {
        queryName: 'FETCH_USER_REQUEST_USERID',
        database: DB_NAME,
        parameters: {
            domain: req.params.userid
        }
    };

    try {
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, req_obj);
        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: false, data: [] });
        }
    } catch (error) {
        console.error('Error fetching user requests:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch user requests' });
    }
});

// ─── POST /updateRequestStatus — approve/reject a request via stored procedure
router.post('/updateRequestStatus', async (req, res) => {
    try {
        let correlationID = uuidv4();
        let reqObj = {
            sp_name: 'approveRejectRequest',
            database: DB_NAME,
            parameters: {
                param0: req.body.requestId,
                param1: req.body.status,
                param2: req.body.roleid,
                param3: req.body.requestorId,
                param4: req.body.approverId,
            }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj, correlationID);
        res.status(200).send(response);
    } catch (error) {
        console.error('Error updating request status:', error);
        res.status(500).json({ status: false, message: 'Failed to update request status' });
    }
});

// ─── POST / — save a new user request ────────────────────────────────────────
router.post('/', async (req, res) => {
    try {
        let correlationID = uuidv4();
        let response = await saveUserRequest(req.body, correlationID);

        if (response.status) {
            res.status(200).json({ status: true, message: 'Request saved' });
        } else {
            res.status(400).json({ status: false, message: 'Request save failed' });
        }
    } catch (error) {
        console.error('Error saving request:', error);
        res.status(500).json({ status: false, message: 'Failed to save request' });
    }
});

// ─── GET /review-summary/:requestId — fetch review summary for a request ─────
router.get('/review-summary/:requestId', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'FETCH_REVIEW_SUMMARY_FOR_REQUEST',
            database: DB_NAME,
            parameters: {
                requestId: req.params.requestId
            }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json({ status: true, data: records });
        } else {
            res.status(200).json({ status: true, data: [] });
        }
    } catch (error) {
        console.error('Error fetching review summary:', error);
        res.status(500).json({ status: false, message: 'Failed to fetch review summary' });
    }
});

// ─── Helper: save user request ────────────────────────────────────────────────
async function saveUserRequest(reqBody, correlationID) {
    const utcTime = moment(new Date()).utc().format('YYYY-MM-DD');

    let tbl_obj = {
        requestor_wwid: reqBody.requestor_wwid,
        requestor_name: reqBody.requestorName || reqBody.requestor_name,
        requestor_email: reqBody.requestorEmail || reqBody.requestor_email,
        department: reqBody.department,
        domain: reqBody.domain,
        status: reqBody.status || 'Pending',
        created_date: utcTime,
    };

    const req_obj = {
        table: 'demand_requests',
        database: DB_NAME,
        data: [tbl_obj]
    };

    return await PostJSON(CLOUD_SQL_API_URL + '/insert', req_obj, correlationID);
}

module.exports = router;
