const express = require('express');
const router = express.Router();
const multer = require('multer');
var FormData = require('form-data');
const { v4: uuidv4 } = require('uuid');
const { PostJSON, PostLog, PostMethod } = require("../util/apiservice");
const upload = multer({ storage: multer.memoryStorage() });
const moment = require('moment-timezone');
require(`../config/appconfig`);

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME = global.config.SAFETY_DB;

router.get("/chart", async (req, res) => {
    try {
        let reqObj = {
            "sp_name": "getChartData",
            "database": DB_NAME,
            "parameters": {
                "param0": "fake param",
            }
        }
        response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj);
        res.send(response);

        debugger;
    } catch (error) {
        console.error("Error updating intake form:", error);
        res.send({ status: false, message: "Failed to update intake form" });
    }
});




module.exports = router;