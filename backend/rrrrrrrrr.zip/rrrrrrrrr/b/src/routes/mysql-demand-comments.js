/**
 * MySQL Demand Comments Routes
 *
 * Mirrors demand-comments.js but uses MySQL via the Cloud SQL API service
 * instead of local JSON files.
 *
 * Endpoints:
 *   GET  /api/mysql-demand-comments?requestId=xxx
 *   POST /api/mysql-demand-comments
 */
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid'); // kept only for correlationID
const { PostJSON } = require('../util/apiservice');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME =  "pms_rnd_intake";//global.config.SAFETY_DB;

// ─── GET / — fetch comments (optionally filtered by requestId) ────────────────
router.get('/', async (req, res) => {
    try {
        const { requestId } = req.query;

        let queryName, parameters;

        if (requestId) {
            queryName = 'FETCH_COMMENTS_BY_REQUEST';
            parameters = { requestId };
        } else {
            queryName = 'FETCH_ALL_COMMENTS';
            parameters = {};
        }

        const reqObj = {
            queryName,
            database: DB_NAME,
            parameters
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.json(records);
        } else {
            res.json([]);
        }
    } catch (err) {
        console.error('Error reading comments:', err);
        res.status(500).json({ error: 'Failed to read comments' });
    }
});

// ─── POST / — add a new comment ──────────────────────────────────────────────
router.post('/', async (req, res) => {
    try {
        const correlationID = uuidv4();
        const body = req.body;

        const tbl_obj = {
            request_id: body.requestId,
            user_id: body.userId,
            user_name: body.userName || '',
            user_role: body.userRole || '',
            text: body.text,
        };

        const reqObj = {
            table: 'demand_comments',
            database: DB_NAME,
            data: [tbl_obj]
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/insert`, reqObj, correlationID);

        if (response.status) {
            // The DB auto-generates the id; retrieve it from the insert response if available
            const insertedId = response.res && response.res[0] ? response.res[0].insertId : null;

            // Return the created comment in the same shape as the JSON-based API
            const created = {
                id: insertedId,
                requestId: tbl_obj.request_id,
                userId: tbl_obj.user_id,
                userName: tbl_obj.user_name,
                userRole: tbl_obj.user_role,
                text: tbl_obj.text,
                createdAt: new Date().toISOString(),
            };
            res.status(201).json(created);
        } else {
            res.status(500).json({ error: 'Failed to create comment' });
        }
    } catch (err) {
        console.error('Error creating comment:', err);
        res.status(500).json({ error: 'Failed to create comment' });
    }
});

module.exports = router;
