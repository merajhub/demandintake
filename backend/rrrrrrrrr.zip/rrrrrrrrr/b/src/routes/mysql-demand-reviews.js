/**
 * MySQL Demand Reviews Routes
 *
 * Mirrors demand-reviews.js but uses MySQL via the Cloud SQL API service
 * instead of local JSON files.
 *
 * Endpoints:
 *   GET  /api/mysql-demand-reviews?requestId=xxx&reviewType=xxx
 *   POST /api/mysql-demand-reviews                (upsert review + add conversation message)
 *   GET  /api/mysql-demand-reviews/attachment/:storedName
 */
const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid'); // kept only for correlationID and file naming
const multer = require('multer');
const { PostJSON } = require('../util/apiservice');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME =  "pms_rnd_intake";//global.config.SAFETY_DB;

// ── File upload setup (same as original) ──
const UPLOADS_DIR = path.join(__dirname, '..', 'data', 'review-attachments');
if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
const storage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
    filename: (_req, file, cb) => {
        const unique = `${Date.now()}-${uuidv4().slice(0, 8)}`;
        cb(null, `${unique}-${file.originalname}`);
    },
});
const upload = multer({ storage });

// ─── GET / — fetch reviews with optional filters ──────────────────────────────
router.get('/', async (req, res) => {
    try {
        const { requestId, reviewType } = req.query;

        // Pick the right query based on which filters are provided
        let queryName, parameters;

        if (requestId && reviewType) {
            queryName = 'FETCH_REVIEWS_BY_REQUEST_AND_TYPE';
            parameters = { requestId, reviewType };
        } else if (requestId) {
            queryName = 'FETCH_REVIEWS_BY_REQUEST';
            parameters = { requestId };
        } else if (reviewType) {
            queryName = 'FETCH_REVIEWS_BY_TYPE';
            parameters = { reviewType };
        } else {
            queryName = 'FETCH_ALL_REVIEWS';
            parameters = {};
        }

        // Fetch review headers
        const reqObj = {
            queryName,
            database: DB_NAME,
            parameters
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const reviews = JSON.parse(response.res).data;

            // For each review, fetch its conversation messages
            const reviewsWithConversations = await Promise.all(
                reviews.map(async (review) => {
                    const convObj = {
                        queryName: 'FETCH_REVIEW_CONVERSATIONS',
                        database: DB_NAME,
                        parameters: { reviewId: review.id }
                    };

                    const convResponse = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, convObj);
                    let conversation = [];

                    if (convResponse.status && convResponse.res.length > 0) {
                        const messages = JSON.parse(convResponse.res).data;
                        conversation = messages.map(msg => {
                            const entry = {
                                from: msg.from_user_id,
                                fromName: msg.from_name,
                                role: msg.role,
                                remarks: msg.remarks,
                                createdAt: msg.created_at,
                            };
                            if (msg.attachment_original_name) {
                                entry.attachment = {
                                    originalName: msg.attachment_original_name,
                                    storedName: msg.attachment_stored_name,
                                    size: msg.attachment_size,
                                    mimeType: msg.attachment_mime_type,
                                };
                            }
                            return entry;
                        });
                    }

                    return {
                        id: review.id,
                        requestId: review.request_id,
                        reviewType: review.review_type,
                        reviewerId: review.reviewer_id,
                        reviewerName: review.reviewer_name,
                        decision: review.decision,
                        conversation,
                        createdAt: review.created_at,
                        updatedAt: review.updated_at,
                    };
                })
            );

            res.json(reviewsWithConversations);
        } else {
            res.json([]);
        }
    } catch (err) {
        console.error('Error reading reviews:', err);
        res.status(500).json({ error: 'Failed to read reviews' });
    }
});

// ─── POST / — create or update (upsert) a review ─────────────────────────────
// If a review already exists for the same requestId + reviewType + reviewerId, update it.
// Otherwise create a new one.
// Supports optional file upload via multipart/form-data (field name: "file")
router.post('/', upload.single('file'), async (req, res) => {
    try {
        const correlationID = uuidv4();
        const body = req.body;

        // Build attachment info if a file was uploaded
        let attachment = null;
        if (req.file) {
            attachment = {
                originalName: req.file.originalname,
                storedName: req.file.filename,
                size: req.file.size,
                mimeType: req.file.mimetype,
            };
        }

        // Check if review already exists
        const findObj = {
            queryName: 'FIND_EXISTING_REVIEW',
            database: DB_NAME,
            parameters: {
                requestId: body.requestId,
                reviewType: body.reviewType,
                reviewerId: body.reviewerId
            }
        };

        const findResponse = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, findObj, correlationID);
        let existingReview = null;

        if (findResponse.status && findResponse.res.length > 0) {
            const found = JSON.parse(findResponse.res).data;
            if (found.length > 0) {
                existingReview = found[0];
            }
        }

        // Build the conversation message (id is AUTO_INCREMENT, not supplied)
        const conversationMsg = {
            from_user_id: body.from || body.reviewerId,
            from_name: body.fromName || body.reviewerName || '',
            role: body.role || '',
            remarks: body.remarks || '',
            attachment_original_name: attachment ? attachment.originalName : null,
            attachment_stored_name: attachment ? attachment.storedName : null,
            attachment_size: attachment ? attachment.size : null,
            attachment_mime_type: attachment ? attachment.mimeType : null,
        };

        if (existingReview) {
            // ── Update existing review: update decision + append conversation ──
            const reviewId = existingReview.id;

            // Update decision if provided
            if (body.decision !== undefined) {
                const updateObj = {
                    queryName: 'UPDATE_REVIEW_DECISION',
                    database: DB_NAME,
                    parameters: {
                        decision: body.decision,
                        reviewId: reviewId
                    }
                };
                await PostJSON(`${CLOUD_SQL_API_URL}/customUpdate`, updateObj, correlationID);
            }

            // Insert conversation message
            conversationMsg.review_id = reviewId;
            const convInsertObj = {
                table: 'demand_review_conversations',
                database: DB_NAME,
                data: [conversationMsg]
            };
            await PostJSON(`${CLOUD_SQL_API_URL}/insert`, convInsertObj, correlationID);

            res.json({
                status: true,
                message: 'Review updated successfully',
                reviewId: reviewId,
                decision: body.decision !== undefined ? body.decision : existingReview.decision
            });
        } else {
            // ── Create new review (id is AUTO_INCREMENT) ──
            const reviewObj = {
                request_id: body.requestId,
                review_type: body.reviewType,
                reviewer_id: body.reviewerId,
                reviewer_name: body.reviewerName || '',
                decision: body.decision || '',
            };

            const reviewInsertObj = {
                table: 'demand_reviews',
                database: DB_NAME,
                data: [reviewObj]
            };

            const reviewResponse = await PostJSON(`${CLOUD_SQL_API_URL}/insert`, reviewInsertObj, correlationID);

            if (reviewResponse.status) {
                // Get the auto-generated review id from the insert response
                const newReviewId = reviewResponse.res && reviewResponse.res[0] ? reviewResponse.res[0].id : null;

                // Insert the first conversation message
                conversationMsg.review_id = newReviewId;
                const convInsertObj = {
                    table: 'demand_review_conversations',
                    database: DB_NAME,
                    data: [conversationMsg]
                };
                let drResp = await PostJSON(`${CLOUD_SQL_API_URL}/insert`, convInsertObj, correlationID);

                res.status(201).json({
                    status: true,
                    message: 'Review created successfully',
                    reviewId: newReviewId,
                    decision: body.decision || ''
                });
            } else {
                res.status(500).json({ error: 'Failed to create review' });
            }
        }
    } catch (err) {
        console.error('Error creating/updating review:', err);
        res.status(500).json({ error: 'Failed to create/update review' });
    }
});

// ─── GET /attachment/:storedName — download an attachment ─────────────────────
router.get('/attachment/:storedName', (req, res) => {
    try {
        const filePath = path.join(UPLOADS_DIR, req.params.storedName);
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'File not found' });
        }
        res.download(filePath);
    } catch (err) {
        console.error('Error downloading attachment:', err);
        res.status(500).json({ error: 'Failed to download attachment' });
    }
});

module.exports = router;
