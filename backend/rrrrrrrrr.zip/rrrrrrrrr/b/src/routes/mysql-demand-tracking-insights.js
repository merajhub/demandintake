/**
 * MySQL Demand Tracking Insights Routes
 *
 * Provides insights data for demand tracking charts.
 *
 * Endpoints:
 *   GET  /api/mysql-demand-tracking-insights/all-metrics — all insights aggregations for tracking
 */
const express = require('express');
const router = express.Router();
const { PostJSON } = require('../util/apiservice');
const moment = require('moment-timezone');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME = 'pms_rnd_intake';

// GET /all-metrics — all insights aggregations for tracking
router.get('/all-metrics', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'FETCH_DEMAND_TRACKING_SUMMARY',
            database: DB_NAME,
            parameters: {}
        };
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);
        
        if (response.status && response.res.length > 0) {
            const rawData = JSON.parse(response.res).data || [];
            
            // Calculate Metrics
            const byStatus = {};
            const byDomain = {};
            const byPriority = {};
            const byRisk = {};
            const byTimeline = {};

            rawData.forEach(item => {
                // Tracking Status (release_status)
                const status = item.release_status || 1; // Default to 1 (Not Started)
                byStatus[status] = (byStatus[status] || 0) + 1;

                // Domain
                const domain = item.domain || 'Unspecified';
                byDomain[domain] = (byDomain[domain] || 0) + 1;

                // Priority
                const priority = item.priority_level || 'Unspecified';
                byPriority[priority] = (byPriority[priority] || 0) + 1;

                // Risks
                const risk = item.tracking_risks || item.risks || 1; // Default to 1 (Green / No Risk)
                byRisk[risk] = (byRisk[risk] || 0) + 1;

                // Timeline (Monthly trends based on creation)
                const dateRaw = item.created_at || item.updated_at || new Date();
                if (dateRaw) {
                    const month = moment(dateRaw).format('YYYY-MM');
                    byTimeline[month] = (byTimeline[month] || 0) + 1;
                }
            });

            // Format objects into arrays for frontend
            const formatObj = (obj, keyName) => Object.entries(obj).map(([k, v]) => ({ [keyName]: k, total: v })).sort((a,b) => b.total - a.total);
            const formatTimeline = (obj) => Object.entries(obj).map(([month, total]) => ({ month, total })).sort((a,b) => a.month.localeCompare(b.month));

            res.json({
                status: true,
                data: {
                    byStatus: formatObj(byStatus, 'status'),
                    byDomain: formatObj(byDomain, 'domain'),
                    byPriority: formatObj(byPriority, 'priority'),
                    byRisk: formatObj(byRisk, 'risk'),
                    byTimeline: formatTimeline(byTimeline)
                }
            });
        } else {
            res.json({
                status: true,
                data: { byStatus: [], byDomain: [], byPriority: [], byRisk: [], byTimeline: [] }
            });
        }
    } catch (err) {
        console.error('Insights – all-metrics error:', err);
        res.status(500).json({ status: false, error: err.message });
    }
});

module.exports = router;
