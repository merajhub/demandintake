const express = require('express');
const router = express.Router();
const multer = require('multer');
var FormData = require('form-data');
const { v4: uuidv4 } = require('uuid');
const { PostJSON, PostMethod } = require("../util/apiservice");
const upload = multer({ storage: multer.memoryStorage() });
const moment = require('moment-timezone');
require(`../config/appconfig`);

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const StorageService_URI = process.env.StorageServiceURL;
const BUCKET_NAME = process.env.StorageBucketName;
const DB_NAME = global.config.SAFETY_DB;

router.get("/all", async (req, res) => {
    const req_obj = {
        queryName: "FETCH_ALL_INTAKE_REQUEST",
        database: DB_NAME,
        parameters: {}
    };

    let response = await fetchIntakeForms(req_obj);
    if (response.status) {
        res.status(200).json(response.data);
    } else {
        res.status(500).json({ error: response.message });
    }
});

router.get("/bydomain/:domain", async (req, res) => {
    const req_obj = {
        queryName: "FETCH_MY_INTAKE_REQUEST_BY_DOMAIN",
        database: DB_NAME,
        parameters: {
            domain: req.params.domain
        }
    };

    let response = await fetchIntakeForms(req_obj);
    if (response.status) {
        res.status(200).json(response.data);
    } else {
        res.status(500).json({ error: response.message });
    }
});

router.get("/myrequests/:wwid", async (req, res) => {
    //  let query = req.params.role == "admin" ? "FETCH_REQUEST_BY_USER_DOMAIN" : "FETCH_REQUEST_BY_USER_DOMAIN"

    const req_obj = {
        queryName: "FETCH_REQUEST_BY_USER_DOMAIN", // "FETCH_REQUEST_BY_USER_DOMAIN",
        database: DB_NAME,
        parameters: {
            domain: req.params.wwid
        }
    };

    let response = await fetchIntakeForms(req_obj);
    if (response.status) {
        res.status(200).json(response.data);
    } else {
        res.status(500).json({ error: response.message });
    }
});

// Get intake form by ID
router.get("/:id", async (req, res) => {
    try {
        const requestId = req.params.id;
        if (!requestId) {
            return res.status(400).json({ message: "requestId is required" });
        }

        const response = await getIntakeDetailsByID(requestId);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.status(200).json(records); // returns the full array of records
        } else {
            res.status(200).json([]); // returns empty array if no data
        }
    } catch (error) {
        console.error("Error fetching intake form by ID:", error);
        res.status(500).json({ message: "Failed to fetch intake form by ID" });
    }
});


// Save new intake form
router.post("/", upload.array("files"), async (req, res) => {
    try {
        debugger;
        let correlationID = uuidv4();
        let file = req.files && req.files.length > 0 ? req.files[0] : null;
        let data = JSON.parse(req.body.record);

        const response = await SaveIntakeFormAsync(data, correlationID);
        debugger;
        if (response.status) {
            if (file) {
                let filepath = `GCCHYD/IntakeForm/REQ-${response.res[0].requestId}/${file.originalname}`
                await SyncUploadFile(file, filepath, correlationID);
            }

            const emailObj = {
                requestId: response.res[0].requestId,
                typeOfRequest: data.typeOfRequest,
                userName: data.requestorName,
                projectTitle: data.projectTitle,
                requestorEmail: data.requestorEmail,
                receiverEmail: 'tgoel3@its.jnj.com', // TODO: Replace with a dynamic recipient list
                cc_EmailList: []
            };

            // SendNotification(emailObj, "INTAKE_FORM_SUBMISSION");

            res.status(200).json({ status: true, message: "Failed to save intake form" });
        }
        else {
            res.status(500).json({ status: false, message: "Failed to save intake form" });
        }

    } catch (error) {
        console.error("Error saving intake form:", error);
        res.status(500).json({ status: false, message: "Failed to save intake form" });
    }
});

router.post("/update", upload.array("files"), async function (req, res) {
    let response;
     let correlationID = uuidv4();
    const { requestorEmail, domain, ...reqData } = JSON.parse(req.body.rowdata); //req.body.rowdata;

    const utcTime = moment(new Date()).utc().format('YYYY-MM-DD HH:mm:ss');


    reqData.dateOfSubmission = reqData.dateOfSubmission
        ? moment(reqData.dateOfSubmission).format('YYYY-MM-DD')
        : utcTime;
    reqData.estimatedCompletionDate = reqData.estimatedCompletionDate
        ? moment(reqData.estimatedCompletionDate).format('YYYY-MM-DD')
        : utcTime;
    reqData.estimatedStartDate = reqData.estimatedStartDate
        ? moment(reqData.estimatedStartDate).format('YYYY-MM-DD')
        : utcTime;

    try {
        let reqObj = {
            "sp_name": "updateRequest",
            "database": DB_NAME,
            "parameters": {
                "param0": req.body.requestId,
                "param1": JSON.stringify(reqData)

            }
        }
        response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj, correlationID);
        if (response.status) {
            let file = req.files && req.files.length > 0 ? req.files[0] : null;
            if (file) {
                let filepath = `GCCHYD/IntakeForm/REQ-${req.body.requestId}/${file.originalname}`
                let aaa = await SyncUploadFile(file, filepath, correlationID);
                debugger;
            }
        }
        res.status(200).send(response);

    } catch (error) {
        console.error("Error updating intake form:", error);
        res.status(200).send({ status: false, message: "Failed to update intake form" });
    }


});

router.post("/updatestatus", async function (req, res) {
    const { requestId, status } = req.body;
    const correlationID = uuidv4();

    let reqObj = {
        queryName: "UPDATE_STATUS",
        database: DB_NAME,
        parameters: {
            status: status,
            requestId: requestId,
        }
    };
    const response = await PostJSON(`${CLOUD_SQL_API_URL}/customUpdate`, reqObj, correlationID);
    res.status(200).send(response);
});



async function getIntakeDetailsByID(requestId) {
    let req_obj = {
        queryName: "FETCH_INTAKE_BY_ID",
        database: DB_NAME,
        parameters: {
            requestId: requestId
        }
    };

    let response = await PostJSON(CLOUD_SQL_API_URL + "/customRetrieve", req_obj);
    return response;
}


async function SaveIntakeFormAsync(formData, correlationID) {
    const utcTime = moment(new Date()).utc().format('YYYY-MM-DD HH:mm:ss');


    let tbl_obj = {
        projectTitle: formData.projectTitle,
        requestorName: formData.requestorName,
        department: formData.department,
        contactEmail: formData.contactEmail,
        contactPhone: formData.contactPhone,
        dateOfSubmission: formData.dateOfSubmission
            ? moment(formData.dateOfSubmission).format('YYYY-MM-DD')
            : utcTime,
        platform: formData.platform,
        complianceRequirements: formData.complianceRequirements,
        typeOfRequest: formData.typeOfRequest?.value || formData.typeOfRequest,
        projectDescription: formData.projectDescription,
        projectGoals: formData.projectGoals,
        businessProblem: formData.businessProblem,
        expectedOutcome: formData.expectedOutcome,
        estimatedCompletionDate: formData.estimatedCompletionDate
            ? moment(formData.estimatedCompletionDate).format('YYYY-MM-DD')
            : null,

        estimatedStartDate: formData.estimatedStartDate
            ? moment(formData.estimatedStartDate).format('YYYY-MM-DD')
            : null,
        resourceRequirements: formData.resourceRequirements,
        targetUsers: formData.targetUsers,
        priorityLevel: formData.priorityLevel?.value || formData.priorityLevel,
        dependencies: formData.dependencies,
        status: formData.status || 'Pending',
        technologyPreference: formData.technologyPreference,
        estimatedBudget: formData.estimatedBudget,
        stakeholders: formData.stakeholders,
        risks: formData.risks,
        reviewNotes: formData.reviewNotes,
        additionalNotes: formData.additionalNotes,
        approvalSignoff: formData.approvalSignoff,
        attachments: formData.attachments,
        requestor_wwid: formData.requestor_wwid,
        domain: formData.domain,
        pm_scrum_master: formData.pm_scrum_master,
    };

    const req_obj = {
        table: "intakeformdetails",
        database: DB_NAME,
        data: [tbl_obj]
    };

    return await PostJSON(CLOUD_SQL_API_URL + "/insert", req_obj, correlationID);
}

async function SyncUploadFile(fileobj, filepath, correlationID) {
    let formData = new FormData();
    formData.append('file', fileobj.buffer, {
        name: 'file',
        filename: fileobj.originalname,
    });
    formData.append('filepath', filepath);
    formData.append('bucketname', BUCKET_NAME);
    try {

        let response = await PostMethod(StorageService_URI + "/uploadfilestream", formData, correlationID);
        return response;
    } catch (exc) {
        console.log("error came at UploadFile", exc.message);
        return { status: false }
    }

}

async function fetchIntakeForms(reqObj) {
    try {
        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);
        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            return { status: true, data: records };
        } else {
            return { status: true, data: [] };
        }
    } catch (error) {
        console.error("Error fetching intake forms:", error);
        return { status: false, message: "Failed to fetch intake forms" };
    }
}


module.exports = router;
