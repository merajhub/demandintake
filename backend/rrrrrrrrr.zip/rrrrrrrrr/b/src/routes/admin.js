const express = require('express');
const router = express.Router();
const multer = require('multer');
var FormData = require('form-data');
const { v4: uuidv4 } = require('uuid');
const { PostJSON, PostLog, PostMethod } = require("../util/apiservice");
const upload = multer({ storage: multer.memoryStorage() });
const moment = require('moment-timezone');
require(`../config/appconfig`);


const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const StorageService_URI = process.env.StorageServiceURL;
const BUCKET_NAME = process.env.StorageBucketName;
const DB_NAME = global.config.SAFETY_DB;


router.get("/allrequests", async (req, res) => {
    const req_obj = {
        queryName: "FETCH_ALL_USER_REQUESTS",
        database: DB_NAME
    };

    const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, req_obj);
    if (response.status && response.res.length > 0) {
        const records = JSON.parse(response.res).data;
        res.status(200).json({ status: true, data: records });
    } else {
        res.status(200).json({ status: false, data: [] });
    }
});


router.get("/getrequest/:userid", async (req, res) => {
    const req_obj = {
        queryName: "FETCH_USER_REQUEST_USERID",
        database: DB_NAME,
        parameters: {
            domain: req.params.userid
        }
    };

    const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, req_obj);
    if (response.status && response.res.length > 0) {
        const records = JSON.parse(response.res).data;
        res.status(200).json({ status: true, data: records });
    } else {
        res.status(200).json({ status: false, data: [] });
    }
});

router.post("/updateRequestStatus", async (req, res) => {
    try {
        debugger;
        let correlationID = uuidv4();
        let reqObj = {
            "sp_name": "approveRejectRequest",
            "database": DB_NAME,
            "parameters": {
                "param0": req.body.requestId,
                "param1":  req.body.status,
                "param2":  req.body.roleid,
                "param3": req.body.requestorId,
                "param4":  req.body.approverId,
            }
        }
        response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj, correlationID);
        res.status(200).send(response)

    } catch (error) {
        console.error("Error saving intake form:", error);
        res.status(500).json({ status: false, message: "Failed to save intake form" });
    }
});

router.post("/", async (req, res) => {
    try {
        debugger;
        let correlationID = uuidv4();

        let response = await saveUserRequest(req.body, correlationID);
        debugger;
        if (response.status) {
            res.status(200).json({ status: true, message: "request saved" });
        }
        else {
            res.status(400).json({ status: false, message: "request save failed" });
        }

    } catch (error) {
        console.error("Error saving intake form:", error);
        res.status(500).json({ status: false, message: "Failed to save intake form" });
    }
});




async function saveUserRequest(reqObj, correlationID) {
    const utcTime = moment(new Date()).utc().format('YYYY-MM-DD');
    tbl_obj = []
    reqObj.domains.forEach(element => {
        tbl_obj.push(
            {
                domain: element.name,
                role: element.role,
                role_id: element.roleid,
                reason: reqObj.reason,
                userid: reqObj.userid,
                request_date: utcTime,
                approved_by: "",
                request_status: 1
            }
        );
    });

    const req_obj = {
        table: "user_request",
        database: DB_NAME,
        data: tbl_obj
    };

    let resp = await PostJSON(CLOUD_SQL_API_URL + "/insert", req_obj, correlationID);
    console.log("----------------------------------------------", resp)
    return resp;
}





module.exports = router;