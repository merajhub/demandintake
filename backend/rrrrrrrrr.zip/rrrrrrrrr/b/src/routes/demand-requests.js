const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { readJSON, writeJSON } = require('../util/json-store');

const REQUESTS_FILE = 'demand-requests.json';

// GET /api/demand-requests?userId=xxx&role=xxx
// All submitted requests are visible to all roles.
//   User        → only own requests (all statuses including draft)
//   Scrub_member / Committee_member → all non-draft requests
router.get('/', (req, res) => {
  try {
    const { userId, role } = req.query;
    let requests = readJSON(REQUESTS_FILE);

    if (role === 'User') {
      // Users see only their own requests
      requests = requests.filter(r => r.createdBy === userId);
    } else {
      // Scrub members and Committee members see all non-draft requests
      requests = requests.filter(r => r.status !== 'draft');
    }

    res.json(requests);
  } catch (err) {
    console.error('Error reading requests:', err);
    res.status(500).json({ error: 'Failed to read requests' });
  }
});

// GET /api/demand-requests/:id
router.get('/:id', (req, res) => {
  try {
    const requests = readJSON(REQUESTS_FILE);
    const request = requests.find(r => r.id === req.params.id);
    if (!request) return res.status(404).json({ error: 'Request not found' });
    res.json(request);
  } catch (err) {
    console.error('Error reading request:', err);
    res.status(500).json({ error: 'Failed to read request' });
  }
});

// POST /api/demand-requests — create a new request
router.post('/', (req, res) => {
  try {
    const requests = readJSON(REQUESTS_FILE);
    const body = req.body;

    const newRequest = {
      id: uuidv4(),
      createdBy: body.createdBy,
      createdByName: body.createdByName || '',
      status: body.status || 'draft', // 'draft' or 'submitted'
      projectOverview: body.projectOverview || {},
      requestorInformation: body.requestorInformation || {},
      projectSpecification: body.projectSpecification || {},
      managementNotes: body.managementNotes || {},
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    requests.push(newRequest);
    writeJSON(REQUESTS_FILE, requests);
    res.status(201).json(newRequest);
  } catch (err) {
    console.error('Error creating request:', err);
    res.status(500).json({ error: 'Failed to create request' });
  }
});

// PUT /api/demand-requests/:id — update a request
router.put('/:id', (req, res) => {
  try {
    const requests = readJSON(REQUESTS_FILE);
    const index = requests.findIndex(r => r.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Request not found' });

    const body = req.body;
    const existing = requests[index];

    // Merge updates
    if (body.projectOverview) existing.projectOverview = body.projectOverview;
    if (body.requestorInformation) existing.requestorInformation = body.requestorInformation;
    if (body.projectSpecification) existing.projectSpecification = body.projectSpecification;
    if (body.managementNotes) existing.managementNotes = body.managementNotes;
    if (body.status) existing.status = body.status;
    if (body.submitterRemarks !== undefined) {
      console.log('Saving submitterRemarks:', body.submitterRemarks);
      existing.submitterRemarks = body.submitterRemarks;
    }
    existing.updatedAt = new Date().toISOString();

    requests[index] = existing;
    writeJSON(REQUESTS_FILE, requests);
    res.json(existing);
  } catch (err) {
    console.error('Error updating request:', err);
    res.status(500).json({ error: 'Failed to update request' });
  }
});

// PATCH /api/demand-requests/:id/status — update status only
router.patch('/:id/status', (req, res) => {
  try {
    const requests = readJSON(REQUESTS_FILE);
    const index = requests.findIndex(r => r.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Request not found' });

    requests[index].status = req.body.status;
    requests[index].updatedAt = new Date().toISOString();

    writeJSON(REQUESTS_FILE, requests);
    res.json(requests[index]);
  } catch (err) {
    console.error('Error updating status:', err);
    res.status(500).json({ error: 'Failed to update status' });
  }
});

module.exports = router;
