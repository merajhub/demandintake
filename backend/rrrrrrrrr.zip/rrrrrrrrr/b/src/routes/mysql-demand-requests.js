/**
 * MySQL Demand Requests Routes
 * 
 * Mirrors demand-requests.js but uses MySQL via the Cloud SQL API service
 * instead of local JSON files.
 * 
 * Endpoints:
 *   GET    /api/mysql-demand-requests?userId=xxx&role=xxx
 *   GET    /api/mysql-demand-requests/:id
 *   POST   /api/mysql-demand-requests
 *   PUT    /api/mysql-demand-requests/:id
 *   PATCH  /api/mysql-demand-requests/:id/status
 */
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid'); // kept only for correlationID
const { PostJSON } = require('../util/apiservice');
const moment = require('moment-timezone');
require('../config/appconfig');

const CLOUD_SQL_API_URL = process.env.CLOUD_SQL_API_URL;
const DB_NAME =  "pms_rnd_intake";//global.config.SAFETY_DB;

// ─── Helper: transform flat DB row → nested UI shape ───────────────────────────
function mapRowToUiShape(row) {
    return {
        id: row.id,
        createdBy: row.created_by,
        createdByName: row.created_by_name,
        status: row.status,
        stage: row.stage,
        submitterRemarks: row.submitter_remarks,
        projectOverview: {
            projectTitle: row.project_title,
            domain: row.domain,
            estimatedBudgetUsd: row.estimated_budget_usd,
            typeOfRequest: row.type_of_request,
            priorityLevel: row.priority_level,
            dateOfSubmission: row.date_of_submission,
            estimatedStartDate: row.estimated_start_date,
            estimatedCompletionDate: row.estimated_completion_date,
        },
        requestorInformation: {
            requestorName: row.requestor_name,
            department: row.department,
            contactEmail: row.contact_email,
            contactPhone: row.contact_phone,
            projectManager: row.project_manager,
        },
        projectSpecification: {
            targetUsers: row.target_users,
            platform: row.platform,
            technologyPreference: row.technology_preference,
            projectDescription: row.project_description,
            projectGoals: row.project_goals,
            businessProblem: row.business_problem,
            expectedOutcome: row.expected_outcome,
            resourceRequirements: row.resource_requirements,
            dependencies: row.dependencies,
            complianceRequirements: row.compliance_requirements,
        },
        managementNotes: {
            stakeholders: row.stakeholders,
            risks: row.risks,
            reviewNotes: row.review_notes,
            additionalNotes: row.additional_notes,
        },
        createdAt: row.created_at,
        updatedAt: row.updated_at,
    };
}

// ─── GET /  — list requests by role ────────────────────────────────────────────
// User        → only own requests (all statuses including draft)
// Scrub_member / Committee_member → all non-draft requests
router.get('/', async (req, res) => {
    try {
        const { userId, role, domain } = req.query;
        let queryName, parameters;

        if (role === 'User') {
            queryName = 'FETCH_REQUESTS_BY_USER';
            parameters = { userId };
        } else {
            if (domain) {
                queryName = 'FETCH_NON_DRAFT_REQUESTS_BY_DOMAIN';
                parameters = { domain };
            } else {
                queryName = 'FETCH_ALL_NON_DRAFT_REQUESTS';
                parameters = {};
            }
        }

        const reqObj = {
            queryName,
            database: DB_NAME,
            parameters
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            res.json(records.map(mapRowToUiShape));
        } else {
            res.json([]);
        }
    } catch (err) {
        console.error('Error reading requests:', err);
        res.status(500).json({ error: 'Failed to read requests' });
    }
});

// ─── GET /:id — get single request ────────────────────────────────────────────
router.get('/:id', async (req, res) => {
    try {
        const reqObj = {
            queryName: 'FETCH_REQUEST_BY_ID',
            database: DB_NAME,
            parameters: { requestId: req.params.id }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customRetrieve`, reqObj);

        if (response.status && response.res.length > 0) {
            const records = JSON.parse(response.res).data;
            if (records.length === 0) {
                return res.status(404).json({ error: 'Request not found' });
            }
            res.json(mapRowToUiShape(records[0]));
        } else {
            res.status(404).json({ error: 'Request not found' });
        }
    } catch (err) {
        console.error('Error reading request:', err);
        res.status(500).json({ error: 'Failed to read request' });
    }
});

// ─── POST / — create a new demand request ─────────────────────────────────────
router.post('/', async (req, res) => {
    try {
        const correlationID = uuidv4();
        const body = req.body;
        const now = moment().utc().format('YYYY-MM-DD HH:mm:ss');

        const overview = body.projectOverview || {};
        const requestor = body.requestorInformation || {};
        const spec = body.projectSpecification || {};
        const mgmt = body.managementNotes || {};

        const tbl_obj = {
            created_by: body.createdBy,
            created_by_name: body.createdByName || '',
            status: body.status || 'draft',
            stage : body.status == "draft" ? "draft" : "scrub",
            submitter_remarks: body.submitterRemarks || null,
            // Project Overview
            project_title: overview.projectTitle || null,
            domain: overview.domain || null,
            estimated_budget_usd: overview.estimatedBudgetUsd || null,
            type_of_request: overview.typeOfRequest || null,
            priority_level: overview.priorityLevel || null,
            date_of_submission: overview.dateOfSubmission
                ? moment(overview.dateOfSubmission).format('YYYY-MM-DD HH:mm:ss')
                : null,
            estimated_start_date: overview.estimatedStartDate
                ? moment(overview.estimatedStartDate).format('YYYY-MM-DD')
                : null,
            estimated_completion_date: overview.estimatedCompletionDate
                ? moment(overview.estimatedCompletionDate).format('YYYY-MM-DD')
                : null,
            // Requestor Information
            requestor_name: requestor.requestorName || null,
            department: requestor.department || null,
            contact_email: requestor.contactEmail || null,
            contact_phone: requestor.contactPhone || null,
            project_manager: requestor.projectManager || null,
            // Project Specification
            target_users: spec.targetUsers || null,
            platform: spec.platform || null,
            technology_preference: spec.technologyPreference || null,
            project_description: spec.projectDescription || null,
            project_goals: spec.projectGoals || null,
            business_problem: spec.businessProblem || null,
            expected_outcome: spec.expectedOutcome || null,
            resource_requirements: spec.resourceRequirements || null,
            dependencies: spec.dependencies || null,
            compliance_requirements: spec.complianceRequirements || null,
            // Management Notes
            stakeholders: mgmt.stakeholders || null,
            risks: mgmt.risks || null,
            review_notes: mgmt.reviewNotes || null,
            additional_notes: mgmt.additionalNotes || null,
        };

        const reqObj = {
            table: 'demand_requests',
            database: DB_NAME,
            data: [tbl_obj]
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/insert`, reqObj, correlationID);

        if (response.status) {
            // The DB auto-generates the id; retrieve it from the insert response if available
            const insertedId = response.res && response.res[0] ? response.res[0].id : null;

            // Return the created object in the same shape as the JSON-based API
            const created = {
                id: insertedId,
                createdBy: tbl_obj.created_by,
                createdByName: tbl_obj.created_by_name,
                status: tbl_obj.status,
                projectOverview: overview,
                requestorInformation: requestor,
                projectSpecification: spec,
                managementNotes: mgmt,
                createdAt: now,
                updatedAt: now,
            };
            res.status(201).json(created);
        } else {
            res.status(500).json({ error: 'Failed to create request' });
        }
    } catch (err) {
        console.error('Error creating request:', err);
        res.status(500).json({ error: 'Failed to create request' });
    }
});

// ─── PUT /:id — update a demand request ───────────────────────────────────────
router.put('/:id', async (req, res) => {
    try {
        const correlationID = uuidv4();
        const body = req.body;

        const overview = body.projectOverview || {};
        const requestor = body.requestorInformation || {};
        const spec = body.projectSpecification || {};
        const mgmt = body.managementNotes || {};

        const updateData = {};

        // Project Overview
        if (body.projectOverview) {
            updateData.project_title = overview.projectTitle;
            updateData.domain = overview.domain;
            updateData.estimated_budget_usd = overview.estimatedBudgetUsd;
            updateData.type_of_request = overview.typeOfRequest;
            updateData.priority_level = overview.priorityLevel;
            updateData.date_of_submission = overview.dateOfSubmission
                ? moment(overview.dateOfSubmission).format('YYYY-MM-DD HH:mm:ss')
                : null;
            updateData.estimated_start_date = overview.estimatedStartDate
                ? moment(overview.estimatedStartDate).format('YYYY-MM-DD')
                : null;
            updateData.estimated_completion_date = overview.estimatedCompletionDate
                ? moment(overview.estimatedCompletionDate).format('YYYY-MM-DD')
                : null;
        }

        // Requestor Information
        if (body.requestorInformation) {
            updateData.requestor_name = requestor.requestorName;
            updateData.department = requestor.department;
            updateData.contact_email = requestor.contactEmail;
            updateData.contact_phone = requestor.contactPhone;
            updateData.project_manager = requestor.projectManager;
        }

        // Project Specification
        if (body.projectSpecification) {
            updateData.target_users = spec.targetUsers;
            updateData.platform = spec.platform;
            updateData.technology_preference = spec.technologyPreference;
            updateData.project_description = spec.projectDescription;
            updateData.project_goals = spec.projectGoals;
            updateData.business_problem = spec.businessProblem;
            updateData.expected_outcome = spec.expectedOutcome;
            updateData.resource_requirements = spec.resourceRequirements;
            updateData.dependencies = spec.dependencies;
            updateData.compliance_requirements = spec.complianceRequirements;
        }

        // Management Notes
        if (body.managementNotes) {
            updateData.stakeholders = mgmt.stakeholders;
            updateData.risks = mgmt.risks;
            updateData.review_notes = mgmt.reviewNotes;
            updateData.additional_notes = mgmt.additionalNotes;
        }

        if (body.status) {
            updateData.status = body.status;
            updateData.stage = body.status == 'submitted' ? "scrub" : "draft";
        }

        if (body.submitterRemarks !== undefined) {
            updateData.submitter_remarks = body.submitterRemarks;
        }

        const reqObj = {
            sp_name: 'updateDemandRequest',
            database: DB_NAME,
            parameters: {
                param0: req.params.id,
                param1: JSON.stringify(updateData)
            }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/storedProcedure`, reqObj, correlationID);

        if (response.status) {
            res.json({ status: true, message: 'Request updated successfully', id: req.params.id });
        } else {
            res.status(500).json({ error: 'Failed to update request' });
        }
    } catch (err) {
        console.error('Error updating request:', err);
        res.status(500).json({ error: 'Failed to update request' });
    }
});

// ─── PATCH /:id/status — update status only ──────────────────────────────────
router.patch('/:id/status', async (req, res) => {
    try {
        const correlationID = uuidv4();
        //committee_review
        

        const reqObj = {
            queryName: 'UPDATE_REQUEST_STATUS',
            database: DB_NAME,
            parameters: {
                status: req.body.status,
                stage: req.body.stage || null,
                requestId: req.params.id
            }
        };

        const response = await PostJSON(`${CLOUD_SQL_API_URL}/customUpdate`, reqObj, correlationID);

        if (response.status) {
            res.json({ status: true, message: 'Status updated successfully', id: req.params.id, newStatus: req.body.status });
        } else {
            res.status(500).json({ error: 'Failed to update status' });
        }
    } catch (err) {
        console.error('Error updating status:', err);
        res.status(500).json({ error: 'Failed to update status' });
    }
});

module.exports = router;
