const { PostJSON, PostLog } = require("../util/apiservice");
const Cloud_SQL_URL = process.env.CLOUD_SQL_URL || "http://10.58.12.34:8899/"; //"http://34.86.222.121:8899";

function emailTemplate(email_content) {
    return (
        `<div>
            <table style="background-color: #cccccc;" width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="10%"></td>
                    <td style="height: 50px;"></td>
                    <td width="10%"></td>
                </tr>
                <tr>
                    <td width="50"></td>
                    <td border="0">
                        <table style="background-color: #ffffff;" width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td style="background-color: #e11f1f; padding: 20px; width: 20px;" border="0"></td>
                                <td style="background-color: #e11f1f; padding: 20px 0px; text-align: left;" border="0">
                                    <img src="https://gcc-hyd.jnj.com/assets/images/email_logo.png" width="150px" />
                                </td>
                                <td style="background-color: #e11f1f; padding: 20px; width: 20px;" border="0"></td>
                            </tr>
                            
                            <tr>
                                <td style=" padding: 10px; width: 20px;"></td>
                                <td>
                                    Hi,
                                </td>
                                <td style=" padding: 10px; width: 20px;"></td>
                            </tr>
                            <tr>
                                <td style=" padding: 10px; width: 20px;"></td>
                                <td>
                                    ${email_content.body}
                                </td>
                                <td style=" padding: 10px; width: 20px;"></td>
                            </tr>
                            <tr>
                                <td style=" padding: 5px; width: 20px;"></td>
                                <td style="height: 50px;">
                                    &nbsp;
                                </td>
                                <td style=" padding: 5px; width: 20px;"></td>
                            </tr>
                        </table>
                    </td>
                    <td width="50"></td>
                </tr>
                <tr>
                    <td width="10%"></td>
                    <td style="height: 50px;"></td>
                    <td width="10%"></td>
                </tr>
            </table>
        </div>`
    )
}

async function SendNotification(emailObj, notificationType) {
    let emailBody;
    switch (notificationType) {
       
        case "INTAKE_FORM_SUBMISSION":
            emailBody = getIntakeFormSubmissionBody(emailObj);
            break;
    }

    const messageBody = emailTemplate(emailBody);

    //let senderEmail = process.env.NODE_ENV == "prod" ? "donotreply-safetyverse@its.jnj.com" : "donotreply-safetyverse-test@its.jnj.com";
   // let senderEmail = process.env.NODE_ENV == "prod" ? "donotreply-safetyverse@its.jnj.com" : "donotreply-safetyverse-test@its.jnj.com";

    const reqObj = {
        "senderName": " ",
        "senderEmail": "gcc-hyd@its.jnj.com",
        "receiverEmail": ["msingh65@ITS.JNJ.com", "SPenama1@ITS.JNJ.com"],
        "cc_EmailList": [emailObj.requestorEmail],
        "subject": emailBody.subject,
        "message": messageBody
    }

    url = Cloud_SQL_URL + "/sendEmail"
    var queryResponse = await PostJSON(url, reqObj);
    let abc = queryResponse;

}


function getIntakeFormSubmissionBody(emailObj) {
    const SFV_URL = process.env.SFV_URL;
    const requestLink = `https://gcc-hyd.jnj.com`;

    let body = `<p>A  ${emailObj.typeOfRequest} request has been created by ${emailObj.userName}.</p>
                <p>Click <a href="${requestLink}">here</a> to view the details of the request.</p>
                <p>
                    Thanks and regards,  <br/>
                    ICC Hyderabad
                </p>`;

    let environment = process.env.NODE_ENV == "sit" ? "DEV" : (process.env.NODE_ENV || '').toUpperCase();
    return { 'body': body, 'subject': ` New Intake Request Created: ${emailObj.projectTitle}`, userName: emailObj.userName };
}



module.exports = { SendNotification, emailTemplate };