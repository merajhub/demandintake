-- =============================================================================
-- PM-RND Demand Tracking - MySQL Database Schema & API Queries
-- =============================================================================
-- This file contains:
--   1. Table schemas for demand tracking (project status after approval)
--   2. All SQL queries used by the demand-tracking API routes
-- =============================================================================


-- =============================================================================
-- 1. TABLE SCHEMAS
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1.1 DEMAND TRACKING TABLE
-- Stores project tracking status for approved demand requests.
-- One row per demand_request.id — created when a user first tracks an approved request.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS demand_tracking (
    id                      INT             AUTO_INCREMENT PRIMARY KEY,
    request_id              INT             NOT NULL,     -- FK → demand_requests.id
    project_title           VARCHAR(500)    DEFAULT NULL,
    domain                  VARCHAR(100)    DEFAULT NULL,
    priority_level          VARCHAR(50)     DEFAULT NULL,
    pm_scrum_master         VARCHAR(255)    DEFAULT NULL,

    -- RAG status columns (1=Green, 2=Amber, 3=Red)
    scope                   TINYINT         DEFAULT NULL,
    schedule                TINYINT         DEFAULT NULL,
    resources               TINYINT         DEFAULT NULL,
    risks                   TINYINT         DEFAULT NULL,

    -- Deviation comments (reason for amber/red)
    scope_comment           TEXT            DEFAULT NULL,
    schedule_comment        TEXT            DEFAULT NULL,
    resources_comment       TEXT            DEFAULT NULL,
    risks_comment           TEXT            DEFAULT NULL,

    -- Release status: 1=Not Started, 2=In Progress, 3=Dev Completed, 4=QA Completed, 5=Completed
    release_status          TINYINT         DEFAULT 1,

    -- Planned dates
    dev_planned_date        DATE            DEFAULT NULL,
    qa_planned_date         DATE            DEFAULT NULL,
    prod_planned_date       DATE            DEFAULT NULL,

    -- Actual dates
    dev_actual_date         DATE            DEFAULT NULL,
    qa_actual_date          DATE            DEFAULT NULL,
    prod_actual_date        DATE            DEFAULT NULL,

    -- General comments
    comments                TEXT            DEFAULT NULL,

    -- Version for optimistic concurrency
    version                 INT             DEFAULT 1,

    -- Metadata
    created_by              VARCHAR(50)     DEFAULT NULL,
    created_by_name         VARCHAR(255)    DEFAULT NULL,
    created_at              TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_dtracking_request FOREIGN KEY (request_id) REFERENCES demand_requests(id) ON DELETE CASCADE,
    UNIQUE INDEX idx_dtracking_request_id (request_id),
    INDEX idx_dtracking_domain (domain),
    INDEX idx_dtracking_release_status (release_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- 1.2 DEMAND TRACKING AUDIT TABLE
-- Stores history of every tracking update for audit trail.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS demand_tracking_audit (
    id                      INT             AUTO_INCREMENT PRIMARY KEY,
    tracking_id             INT             NOT NULL,     -- FK → demand_tracking.id
    request_id              INT             NOT NULL,

    -- Snapshot of status at time of audit
    scope                   TINYINT         DEFAULT NULL,
    schedule                TINYINT         DEFAULT NULL,
    resources               TINYINT         DEFAULT NULL,
    risks                   TINYINT         DEFAULT NULL,

    scope_comment           TEXT            DEFAULT NULL,
    schedule_comment        TEXT            DEFAULT NULL,
    resources_comment       TEXT            DEFAULT NULL,
    risks_comment           TEXT            DEFAULT NULL,

    release_status          TINYINT         DEFAULT NULL,

    dev_planned_date        DATE            DEFAULT NULL,
    qa_planned_date         DATE            DEFAULT NULL,
    prod_planned_date       DATE            DEFAULT NULL,

    dev_actual_date         DATE            DEFAULT NULL,
    qa_actual_date          DATE            DEFAULT NULL,
    prod_actual_date        DATE            DEFAULT NULL,

    comments                TEXT            DEFAULT NULL,
    version                 INT             DEFAULT NULL,

    -- Who made the change
    updated_by              VARCHAR(50)     DEFAULT NULL,
    updated_by_name         VARCHAR(255)    DEFAULT NULL,
    created_at              TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_dtracking_audit_tracking FOREIGN KEY (tracking_id) REFERENCES demand_tracking(id) ON DELETE CASCADE,
    INDEX idx_dtracking_audit_tracking_id (tracking_id),
    INDEX idx_dtracking_audit_request_id (request_id),
    INDEX idx_dtracking_audit_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- =============================================================================
-- 2. API QUERIES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 2.1 Fetch all approved demand requests (for the tracking dashboard list)
-- Name: FETCH_APPROVED_DEMAND_REQUESTS
-- Returns approved requests with their tracking data (if any) via LEFT JOIN
-- -----------------------------------------------------------------------------
SELECT
    dr.id                       AS request_id,
    dr.project_title,
    dr.domain,
    dr.priority_level,
    dr.type_of_request,
    dr.requestor_name,
    dr.pm_scrum_master,
    dr.estimated_start_date,
    dr.estimated_completion_date,
    dr.date_of_submission,
    dt.id                       AS tracking_id,
    dt.scope,
    dt.schedule,
    dt.resources,
    dt.risks,
    dt.scope_comment,
    dt.schedule_comment,
    dt.resources_comment,
    dt.risks_comment,
    dt.release_status,
    dt.dev_planned_date,
    dt.qa_planned_date,
    dt.prod_planned_date,
    dt.dev_actual_date,
    dt.qa_actual_date,
    dt.prod_actual_date,
    dt.comments,
    dt.version
FROM demand_requests dr
LEFT JOIN demand_tracking dt ON dt.request_id = dr.id
WHERE dr.status = 'approved'
ORDER BY dr.updated_at DESC;


-- -----------------------------------------------------------------------------
-- 2.2 Fetch single tracking record by request_id
-- Name: FETCH_DEMAND_TRACKING_BY_REQUEST_ID
-- Params: :requestId
-- -----------------------------------------------------------------------------
SELECT
    dr.id                       AS request_id,
    dr.project_title,
    dr.domain,
    dr.priority_level,
    dr.type_of_request,
    dr.requestor_name,
    dr.pm_scrum_master,
    dr.estimated_start_date,
    dr.estimated_completion_date,
    dr.date_of_submission,
    dt.id                       AS tracking_id,
    dt.scope,
    dt.schedule,
    dt.resources,
    dt.risks,
    dt.scope_comment,
    dt.schedule_comment,
    dt.resources_comment,
    dt.risks_comment,
    dt.release_status,
    dt.dev_planned_date,
    dt.qa_planned_date,
    dt.prod_planned_date,
    dt.dev_actual_date,
    dt.qa_actual_date,
    dt.prod_actual_date,
    dt.comments,
    dt.version
FROM demand_requests dr
LEFT JOIN demand_tracking dt ON dt.request_id = dr.id
WHERE dr.id = :requestId AND dr.status = 'approved';


-- -----------------------------------------------------------------------------
-- 2.3 Fetch tracking audit history by request_id
-- Name: FETCH_DEMAND_TRACKING_AUDIT
-- Params: :requestId
-- -----------------------------------------------------------------------------
SELECT
    dta.*,
    dta.updated_by_name AS user_name
FROM demand_tracking_audit dta
WHERE dta.request_id = :requestId
ORDER BY dta.created_at DESC;


-- -----------------------------------------------------------------------------
-- 2.4 Insert new demand_tracking record
-- Name: INSERT_DEMAND_TRACKING
-- (Done via generic /insert API with table = 'demand_tracking')
-- -----------------------------------------------------------------------------
INSERT INTO demand_tracking (
    request_id, project_title, domain, priority_level, pm_scrum_master,
    scope, schedule, resources, risks,
    scope_comment, schedule_comment, resources_comment, risks_comment,
    release_status,
    dev_planned_date, qa_planned_date, prod_planned_date,
    dev_actual_date, qa_actual_date, prod_actual_date,
    comments, version, created_by, created_by_name
) VALUES (
    :requestId, :projectTitle, :domain, :priorityLevel, :pmScrumMaster,
    :scope, :schedule, :resources, :risks,
    :scopeComment, :scheduleComment, :resourcesComment, :risksComment,
    :releaseStatus,
    :devPlannedDate, :qaPlannedDate, :prodPlannedDate,
    :devActualDate, :qaActualDate, :prodActualDate,
    :comments, 1, :createdBy, :createdByName
);


-- -----------------------------------------------------------------------------
-- 2.5 Update demand_tracking record
-- Name: UPDATE_DEMAND_TRACKING
-- Params: all tracking fields + :requestId
-- -----------------------------------------------------------------------------
UPDATE demand_tracking
SET
    scope               = :scope,
    schedule            = :schedule,
    resources           = :resources,
    risks               = :risks,
    scope_comment       = :scopeComment,
    schedule_comment    = :scheduleComment,
    resources_comment   = :resourcesComment,
    risks_comment       = :risksComment,
    release_status      = :releaseStatus,
    dev_planned_date    = :devPlannedDate,
    qa_planned_date     = :qaPlannedDate,
    prod_planned_date   = :prodPlannedDate,
    dev_actual_date     = :devActualDate,
    qa_actual_date      = :qaActualDate,
    prod_actual_date    = :prodActualDate,
    comments            = :comments,
    version             = version + 1,
    updated_at          = NOW()
WHERE request_id = :requestId;
