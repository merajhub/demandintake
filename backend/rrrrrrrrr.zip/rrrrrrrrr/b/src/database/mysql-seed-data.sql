-- =============================================================================
-- PM-RND Demand Intake - MySQL Seed Data
-- =============================================================================
-- Mirrors all existing JSON mock data from:
--   users.json, demand-requests.json, demand-comments.json, demand-reviews.json
--
-- Run AFTER mysql-schema-and-queries.sql
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- Clean existing data (safe re-run)
TRUNCATE TABLE demand_review_conversations;
TRUNCATE TABLE demand_reviews;
TRUNCATE TABLE demand_comments;
TRUNCATE TABLE demand_request_attachments;
TRUNCATE TABLE demand_requests;
TRUNCATE TABLE users;

SET FOREIGN_KEY_CHECKS = 1;


-- =============================================================================
-- 1. USERS (from users.json)
-- =============================================================================
INSERT INTO users (id, wwid, name, email, role, domain) VALUES
(1, 'user_req_01',  'Alice Johnson',  'alice@jnj.com',   'User', NULL),
(2, 'scrub_01',     'Bob Smith',      'bob@jnj.com',     'Scrub_member', 'Safety'),
(3, 'scrub_02',     'Charlie Brown',  'charlie@jnj.com', 'Scrub_member', 'Regulatory'),
(4, 'scrub_03',     'David Lee',      'david@jnj.com',   'Scrub_member', 'Clinical'),
(5, 'committee_01', 'Diana Prince',   'diana@jnj.com',   'Committee_member', 'Safety'),
(6, 'committee_02', 'Edward Norton',  'edward@jnj.com',  'Committee_member', 'Regulatory'),
(7, 'committee_03', 'Fiona Gallagher','fiona@jnj.com',   'Committee_member', 'Clinical'),
(8, '152307668', 'Meraj Ahmad',  'ad@jnj.com',  'User', NULL);


-- =============================================================================
-- 2. DEMAND REQUESTS (from demand-requests.json)
-- =============================================================================

-- Request 1: Safety Signal Detection Upgrade (approved)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-1111-4aaa-bbbb-000000000001', 'user_req_01', 'Alice Johnson', 'approved', NULL,
    'Safety Signal Detection Upgrade', 'Safety', 150000.00, 'Enhancement', 'High',
    '2026-01-15 10:00:00', '2026-03-01', '2026-06-15',
    'Alice Johnson', 'Pharmacovigilance', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Frank Rivera',
    'Safety Scientists, Signal Detection Analysts', 'Web', 'Angular',
    'Upgrade the existing safety signal detection system to incorporate AI/ML-based algorithms for improved accuracy and faster identification of potential adverse drug reactions.',
    'Reduce false-positive signal detection rate by 40%, improve time-to-detection from 14 days to 3 days, and integrate real-time data feeds from global pharmacovigilance databases.',
    'Current signal detection relies on manual disproportionality analysis which is slow and generates excessive false positives, leading to delayed safety actions and resource waste.',
    'Automated AI-powered signal detection with dashboard visualization, reducing manual effort by 60% and improving patient safety outcomes.',
    '3 Full-stack developers, 1 Data Scientist, 1 QA Engineer',
    'Access to FAERS database API, AWS SageMaker for ML models',
    'GxP validated, 21 CFR Part 11 compliant',
    'VP Pharmacovigilance, Global Safety Head, IT Architecture Board',
    'ML model accuracy depends on data quality; regulatory approval for AI-based safety tools may require additional validation.',
    'Approved by both Scrub and Committee teams. Aligns with 2026 safety modernization roadmap.',
    'Phase 1 focuses on US FAERS data; Phase 2 will expand to EudraVigilance and VigiBase.',
    '2026-01-15 10:15:00', '2026-02-28 14:30:00'
);

-- Request 2: Regulatory Submission Portal (submitted)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-2222-4aaa-bbbb-000000000002', 'user_req_01', 'Alice Johnson', 'submitted', NULL,
    'Regulatory Submission Portal', 'Regulatory', 500000.00, 'New Development', 'High',
    '2026-02-20 08:00:00', '2026-04-01', '2026-09-30',
    'Alice Johnson', 'Regulatory Affairs', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Grace Kim',
    'Regulatory Affairs Specialists, Submission Coordinators', 'Web', '.NET',
    'Build a unified regulatory submission portal that streamlines the eCTD compilation, submission tracking, and health authority correspondence across FDA, EMA, and PMDA.',
    'Centralize all regulatory submissions into a single platform, reduce submission preparation time by 50%, and provide real-time submission status tracking across all markets.',
    'Regulatory submissions are currently managed through disconnected tools and spreadsheets, leading to version control issues, missed deadlines, and duplicated effort across regional teams.',
    'A unified web portal reducing submission cycle time by 50% and eliminating manual tracking across 15+ regional regulatory teams.',
    '5 Full-stack developers, 2 BA/Domain experts, 1 DevOps, 2 QA',
    'Integration with existing DMS (Documentum), eCTD publishing tool (GlobalSubmit)',
    '21 CFR Part 11, EU Annex 11, GxP validated',
    'Head of Regulatory Operations, Regional Regulatory Leads (US, EU, APAC), IT Enterprise Architecture',
    'Complex integration with legacy DMS; multi-region deployment requires localization and varied health authority format support.',
    '',
    'This project is part of the Regulatory Modernization Program. Budget approved at portfolio level.',
    '2026-02-20 08:30:00', '2026-02-20 08:30:00'
);

-- Request 3: Clinical Trial Dashboard v2 (in_review)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-3333-4aaa-bbbb-000000000003', 'user_req_01', 'Alice Johnson', 'in_review', NULL,
    'Clinical Trial Dashboard v2', 'Clinical', 275000.00, 'New Development', 'Medium',
    '2026-02-15 12:00:00', '2026-04-15', '2026-08-01',
    'Alice Johnson', 'Clinical Operations', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Henry Patel',
    'Clinical Trial Managers, Site Monitors, Medical Directors', 'Web', 'Angular',
    'Develop version 2 of the Clinical Trial Dashboard with enhanced real-time enrollment tracking, site performance metrics, and protocol deviation analytics.',
    'Provide real-time visibility into trial enrollment across 200+ sites globally, enable predictive analytics for enrollment forecasting, and integrate with EDC and CTMS systems.',
    'Current dashboard is static, updated weekly, and lacks drill-down capability. Trial managers cannot make timely enrollment decisions, leading to timeline overruns and budget waste.',
    'Real-time interactive dashboard reducing enrollment gap analysis time from 1 week to real-time, with predictive enrollment forecasting accuracy of 85%+.',
    '4 Developers, 1 Data Engineer, 1 UX Designer, 1 QA',
    'Medidata Rave EDC API, Veeva CTMS integration, AWS Redshift data warehouse',
    'GxP validated, HIPAA compliant for patient-level data',
    'VP Clinical Operations, Head of Biostatistics, Clinical Data Management Lead',
    'EDC API rate limits may affect real-time data refresh; site-level data quality varies across regions.',
    'Under scrub team review. Initial feedback is positive.',
    'Dashboard v1 had 500+ active users. v2 needs to support 1000+ concurrent users.',
    '2026-02-15 12:10:00', '2026-03-05 14:22:00'
);

-- Request 4: Adverse Event Reporting Automation (clarification_requested)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-4444-4aaa-bbbb-000000000004', 'user_req_01', 'Alice Johnson', 'clarification_requested',
    'Attached updated integration architecture and NLP model validation report.',
    'Adverse Event Reporting Automation', 'Safety', 420000.00, 'New Development', 'High',
    '2026-01-28 09:00:00', '2026-04-01', '2026-07-15',
    'Alice Johnson', 'Drug Safety & Pharmacovigilance', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Isabel Torres',
    'Safety Case Processors, Medical Reviewers, PV Managers', 'Web', 'Java',
    'Automate the end-to-end adverse event reporting workflow from case intake through regulatory submission, including auto-population of MedDRA coding, narrative generation, and E2B(R3) submission.',
    'Reduce case processing time from 5 days to 1 day, achieve 95% auto-coding accuracy for MedDRA terms, and eliminate manual E2B XML generation.',
    'Manual AE processing is error-prone, slow, and cannot scale with increasing global case volumes (30% YoY growth). Regulatory submission deadlines are at risk.',
    'Fully automated AE reporting pipeline processing 80% of cases without manual intervention, ensuring 100% regulatory compliance for submission timelines.',
    '6 Developers, 2 PV Domain Experts, 1 NLP Specialist, 2 QA',
    'Argus Safety database, MedDRA dictionary license, E2B(R3) gateway connectivity',
    'GxP validated, 21 CFR Part 11, ICH E2B(R3) compliant, GDPR for EU cases',
    'Chief Medical Officer, Global PV Head, VP IT Life Sciences',
    'NLP model accuracy for narrative generation; regulatory acceptance of AI-generated narratives; integration complexity with legacy Argus system.',
    'Scrub team requested clarification on the NLP approach and Argus integration plan.',
    'This is a top strategic initiative per the CMO. Expedite review if possible.',
    '2026-01-28 09:20:00', '2026-03-10 16:30:00'
);

-- Request 5: Legacy Regulatory Data Migration (rejected)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-5555-4aaa-bbbb-000000000005', 'user_req_01', 'Alice Johnson', 'rejected', NULL,
    'Legacy Regulatory Data Migration', 'Regulatory', 80000.00, 'Enhancement', 'Low',
    '2026-01-10 14:00:00', '2026-03-01', '2026-04-30',
    'Alice Johnson', 'Regulatory Information Management', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Jack Morrison',
    'Regulatory Data Managers, Archive Specialists', 'Desktop', 'Python',
    'Migrate regulatory submission data from the legacy Oracle-based system to the new cloud-based regulatory information management platform.',
    'Migrate 15 years of historical submission records (50,000+ documents) with full metadata preservation and cross-reference integrity.',
    'The legacy Oracle system is reaching end-of-life with no vendor support after Q2 2026. Historical data access is critical for regulatory queries and audits.',
    'Complete data migration with 100% data integrity validation, zero data loss, and improved search/retrieval performance in the new cloud platform.',
    '2 Data Engineers, 1 DBA, 1 QA',
    'Legacy Oracle DB access, new cloud platform API availability',
    'Data integrity per 21 CFR Part 11',
    'IT Infrastructure Lead, Regulatory Data Governance',
    'Legacy data format inconsistencies; potential downtime during migration cutover.',
    'Rejected by committee - does not align with current year strategic priorities. Recommended to revisit in Q4.',
    '',
    '2026-01-10 14:05:00', '2026-02-28 11:00:00'
);

-- Request 6: Safety Database Performance Tuning (draft)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-6666-4aaa-bbbb-000000000006', 'user_req_01', 'Alice Johnson', 'draft', NULL,
    'Safety Database Performance Tuning', 'Safety', 60000.00, 'Enhancement', 'Medium',
    NULL, '2026-05-01', '2026-05-31',
    'Alice Johnson', 'IT Safety Systems', 'alice.johnson@jnj.com', '+1-732-555-0101', '',
    'Safety Database Administrators, Case Processors', 'Cloud', 'No Preference',
    'Optimize the safety database queries and indexing strategy to improve case retrieval and reporting performance.',
    '',
    'Safety database response times have degraded to 15+ seconds for complex queries, impacting case processing efficiency.',
    '',
    '1 DBA, 1 Performance Engineer',
    '', '',
    '', '', '',
    'Draft in progress - need to finalize scope with DBA team.',
    '2026-03-12 20:00:00', '2026-03-12 20:00:00'
);

-- Request 7: Clinical Data Warehouse Expansion (committee_review)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-7777-4aaa-bbbb-000000000007', 'user_req_01', 'Alice Johnson', 'committee_review', NULL,
    'Clinical Data Warehouse Expansion', 'Clinical', 750000.00, 'New Development', 'Medium',
    '2026-01-05 07:30:00', '2026-06-01', '2026-12-31',
    'Alice Johnson', 'Clinical Data Management', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Karen Wu',
    'Biostatisticians, Clinical Data Scientists, Medical Writers', 'Cloud', 'Python',
    'Expand the clinical data warehouse to incorporate real-world data (RWD) sources, genomics data, and wearable device data alongside traditional clinical trial data.',
    'Create a unified data lake supporting 50TB+ of multi-modal clinical data, enable self-service analytics for biostatisticians, and reduce data preparation time by 70%.',
    'Clinical data is siloed across EDC, lab systems, imaging, and RWD platforms. Cross-study analytics require weeks of manual data harmonization, delaying critical insights.',
    'Integrated clinical data warehouse on AWS with automated ETL pipelines, self-service query tools, and pre-built analytics templates for common study designs.',
    '3 Data Engineers, 2 Cloud Architects, 2 Developers, 1 Data Scientist, 2 QA',
    'AWS Redshift/S3, Snowflake connector, EDC data feeds, RWD vendor APIs (Flatiron, Tempus)',
    'HIPAA, GxP for clinical trial data, GDPR for EU patient data',
    'Chief Data Officer, VP Clinical Development, Head of Real-World Evidence, IT Enterprise Architecture',
    'High budget; complex multi-vendor integration; data governance policies for RWD/genomics need to be established; cloud cost management.',
    'Passed scrub review. Under committee evaluation - budget review pending.',
    'Phased approach recommended: Phase 1 = core warehouse + EDC integration, Phase 2 = RWD, Phase 3 = genomics/wearables.',
    '2026-01-05 07:45:00', '2026-03-06 10:15:00'
);

-- Request 8: Regulatory Compliance Tracker (committee_clarification_requested)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-8888-4aaa-bbbb-000000000008', 'user_req_01', 'Alice Johnson', 'committee_clarification_requested', NULL,
    'Regulatory Compliance Tracker', 'Regulatory', 200000.00, 'New Development', 'High',
    '2026-02-10 11:00:00', '2026-04-15', '2026-08-15',
    'Alice Johnson', 'Regulatory Compliance', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Liam Chen',
    'Compliance Officers, Regulatory Affairs Managers, Quality Assurance', 'Web', 'Angular',
    'Build a comprehensive compliance tracker that monitors regulatory commitments, post-approval obligations, and inspection readiness across all marketed products.',
    'Track 100% of post-approval regulatory commitments with automated alerts for upcoming deadlines, provide audit-ready compliance dashboards, and reduce missed commitment rate to zero.',
    'Regulatory commitments are tracked in spreadsheets across regional teams. Missed commitments can result in warning letters, product holds, or consent decree actions.',
    'Centralized compliance tracking system with automated deadline alerts, risk scoring, and audit-ready reporting for 500+ active regulatory commitments.',
    '3 Full-stack developers, 1 BA, 1 QA, 1 Regulatory domain expert',
    'Regulatory information management system API, email notification service',
    '21 CFR Part 11, SOX compliance for audit trails',
    'Chief Compliance Officer, VP Regulatory Affairs, Internal Audit',
    'Defining a universal commitment taxonomy across therapeutic areas; change management with regional teams currently using their own tracking methods.',
    'Committee requested clarification on how this tracker will integrate with existing regulatory submission systems across regions.',
    'High urgency - recent FDA inspection finding cited lack of centralized commitment tracking.',
    '2026-02-10 11:20:00', '2026-03-11 08:30:00'
);

-- Request 9: Clinical eTMF Integration (submitted)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-9999-4aaa-bbbb-000000000009', 'user_req_01', 'Alice Johnson', 'submitted', NULL,
    'Clinical eTMF Integration', 'Clinical', 180000.00, 'Enhancement', 'Medium',
    '2026-03-12 15:00:00', '2026-05-01', '2026-07-01',
    'Alice Johnson', 'Clinical Document Management', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Maria Santos',
    'Clinical Document Specialists, Trial Master File Managers, Site Monitors', 'Web', 'React',
    'Enhance the electronic Trial Master File (eTMF) system with automated document classification, missing document detection, and real-time TMF completeness metrics integrated with the CTMS.',
    'Achieve 95% automated document classification accuracy, reduce TMF inspection readiness time from 4 weeks to 1 week, and integrate TMF completeness data into clinical trial dashboards.',
    'eTMF filing is largely manual, resulting in misfiled documents, incomplete TMFs, and significant effort required for inspection preparation.',
    'AI-powered document auto-classification reducing manual filing by 80%, automated completeness scoring, and seamless CTMS integration for real-time TMF health monitoring.',
    '3 Developers, 1 ML Engineer, 1 BA, 1 QA',
    'Veeva Vault eTMF API, CTMS data feed, AWS Textract for document processing',
    'GxP validated, ICH E6 TMF Reference Model compliant',
    'Head of Clinical Compliance, TMF Program Lead, Clinical IT Director',
    'ML model training requires large labeled document dataset; Veeva API customization limits.',
    '',
    'This builds on the existing eTMF platform. No new infrastructure required.',
    '2026-03-12 15:10:00', '2026-03-12 15:10:00'
);

-- Request 10: Safety Case Narrative Generator (in_review)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-aaaa-4aaa-bbbb-000000000010', 'user_req_01', 'Alice Johnson', 'in_review', NULL,
    'Safety Case Narrative Generator', 'Safety', 310000.00, 'New Development', 'Low',
    '2026-02-25 09:30:00', '2026-06-01', '2026-10-15',
    'Alice Johnson', 'Medical Safety Writing', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Nathan Brooks',
    'Medical Writers, Safety Case Processors, Medical Reviewers', 'Web', 'Python',
    'Develop an AI-powered case narrative generation tool that automatically creates CIOMS-compliant safety case narratives from structured case data in the safety database.',
    'Auto-generate first-draft narratives for 70% of non-serious cases, reduce medical writer review time by 50%, and ensure CIOMS format compliance for all generated narratives.',
    'Narrative writing is the most time-consuming step in case processing. With 30% annual case volume growth, the current manual approach cannot scale without proportional headcount increase.',
    'LLM-based narrative generator producing CIOMS-compliant drafts that require minimal medical writer editing, enabling the team to handle 30% more cases without additional staff.',
    '2 ML Engineers, 2 Full-stack developers, 1 Medical Writer (domain), 1 QA',
    'Safety database API, LLM infrastructure (Azure OpenAI), MedDRA dictionary',
    'GxP validated, AI/ML validation framework, 21 CFR Part 11',
    'Global PV Head, Medical Writing Lead, AI/ML Center of Excellence',
    'LLM hallucination risk for medical narratives; regulatory acceptance of AI-generated content; prompt engineering complexity for varying case types.',
    'Under scrub review. Technical feasibility assessment ongoing for LLM deployment in GxP environment.',
    'Pilot with non-serious, non-expedited cases first. Serious/expedited cases in Phase 2.',
    '2026-02-25 09:40:00', '2026-03-07 13:50:00'
);

-- Request 11: Regulatory Label Management System (deferred)
INSERT INTO demand_requests (
    id, created_by, created_by_name, status, submitter_remarks,
    project_title, domain, estimated_budget_usd, type_of_request, priority_level,
    date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    created_at, updated_at
) VALUES (
    'a1b2c3d4-bbbb-4aaa-bbbb-000000000011', 'user_req_01', 'Alice Johnson', 'deferred', NULL,
    'Regulatory Label Management System', 'Regulatory', 390000.00, 'Enhancement', 'Medium',
    '2025-12-20 10:00:00', '2026-07-01', '2026-12-31',
    'Alice Johnson', 'Labeling Operations', 'alice.johnson@jnj.com', '+1-732-555-0101', 'Olivia Grant',
    'Labeling Specialists, Regulatory Writers, Artwork Coordinators', 'Web', '.NET',
    'Enhance the label management system to support structured product labeling (SPL), automated label comparison across markets, and multi-language label generation workflows.',
    'Support SPL format for US labeling, enable automated cross-market label comparison for 50+ countries, and reduce label update cycle time from 8 weeks to 3 weeks.',
    'Global label management is fragmented across regional systems. Label updates require manual comparison across markets, leading to inconsistencies and delayed launches.',
    'Unified label management platform with automated comparison, SPL support, and multi-language workflows, reducing label inconsistencies by 90%.',
    '4 Developers, 1 Labeling Domain Expert, 1 UX Designer, 2 QA',
    'SPL authoring tool, translation management system, artwork management integration',
    'FDA SPL format compliance, GxP validated',
    'VP Global Labeling, Regional Labeling Leads, Artwork Operations Manager',
    'SPL format complexity; vendor dependency for translation management; change management across 50+ country affiliates.',
    'Deferred by committee to Q3 due to budget constraints and higher-priority safety projects in H1.',
    'Revisit in Q3 2026. Pre-work on SPL requirements can proceed in parallel.',
    '2025-12-20 10:15:00', '2026-02-14 17:00:00'
);


-- =============================================================================
-- 3. DEMAND REVIEWS (from demand-reviews.json)
-- =============================================================================

-- ── Request 1 reviews (approved) ──

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub01-0001', 'a1b2c3d4-1111-4aaa-bbbb-000000000001', 'scrub', 'scrub_01', 'Bob Smith', 'No Questions', '2026-01-20 09:00:00', '2026-01-20 09:00:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub02-0001', 'a1b2c3d4-1111-4aaa-bbbb-000000000001', 'scrub', 'scrub_02', 'Charlie Brown', 'No Questions', '2026-01-21 11:30:00', '2026-01-21 11:30:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-comm01-0001', 'a1b2c3d4-1111-4aaa-bbbb-000000000001', 'committee', 'committee_01', 'Diana Prince', 'Approved', '2026-02-15 10:00:00', '2026-02-15 10:00:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-comm02-0001', 'a1b2c3d4-1111-4aaa-bbbb-000000000001', 'committee', 'committee_02', 'Edward Norton', 'Approved', '2026-02-16 14:15:00', '2026-02-16 14:15:00');

-- ── Request 3 reviews (in_review) ──

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub01-0003', 'a1b2c3d4-3333-4aaa-bbbb-000000000003', 'scrub', 'scrub_01', 'Bob Smith', '', '2026-02-18 10:30:00', '2026-02-18 10:30:00');

-- ── Request 4 reviews (clarification_requested) ──

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub01-0004', 'a1b2c3d4-4444-4aaa-bbbb-000000000004', 'scrub', 'scrub_01', 'Bob Smith', 'Needs Clarification', '2026-02-05 09:00:00', '2026-02-08 14:30:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub02-0004', 'a1b2c3d4-4444-4aaa-bbbb-000000000004', 'scrub', 'scrub_02', 'Charlie Brown', 'Needs Clarification', '2026-02-06 11:15:00', '2026-02-06 11:15:00');

-- ── Request 5 reviews (rejected) ──

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub01-0005', 'a1b2c3d4-5555-4aaa-bbbb-000000000005', 'scrub', 'scrub_01', 'Bob Smith', 'No Questions', '2026-01-15 08:30:00', '2026-01-15 08:30:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub02-0005', 'a1b2c3d4-5555-4aaa-bbbb-000000000005', 'scrub', 'scrub_02', 'Charlie Brown', 'No Questions', '2026-01-16 14:00:00', '2026-01-16 14:00:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-comm01-0005', 'a1b2c3d4-5555-4aaa-bbbb-000000000005', 'committee', 'committee_01', 'Diana Prince', 'Rejected', '2026-02-20 09:00:00', '2026-02-20 09:00:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-comm02-0005', 'a1b2c3d4-5555-4aaa-bbbb-000000000005', 'committee', 'committee_02', 'Edward Norton', 'Rejected', '2026-02-21 10:30:00', '2026-02-21 10:30:00');

-- ── Request 7 reviews (committee_review) ──

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub01-0007', 'a1b2c3d4-7777-4aaa-bbbb-000000000007', 'scrub', 'scrub_01', 'Bob Smith', 'No Questions', '2026-01-12 09:00:00', '2026-01-12 09:00:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub02-0007', 'a1b2c3d4-7777-4aaa-bbbb-000000000007', 'scrub', 'scrub_02', 'Charlie Brown', 'No Questions', '2026-01-13 14:45:00', '2026-01-13 14:45:00');

-- ── Request 8 reviews (committee_clarification_requested) ──

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub01-0008', 'a1b2c3d4-8888-4aaa-bbbb-000000000008', 'scrub', 'scrub_01', 'Bob Smith', 'No Questions', '2026-02-15 10:00:00', '2026-02-15 10:00:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub02-0008', 'a1b2c3d4-8888-4aaa-bbbb-000000000008', 'scrub', 'scrub_02', 'Charlie Brown', 'No Questions', '2026-02-16 15:30:00', '2026-02-16 15:30:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-comm01-0008', 'a1b2c3d4-8888-4aaa-bbbb-000000000008', 'committee', 'committee_01', 'Diana Prince', 'Needs Clarification', '2026-03-05 09:20:00', '2026-03-05 09:20:00');

-- ── Request 11 reviews (deferred) ──

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub01-0011', 'a1b2c3d4-bbbb-4aaa-bbbb-000000000011', 'scrub', 'scrub_01', 'Bob Smith', 'No Questions', '2025-12-28 09:00:00', '2025-12-28 09:00:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-scrub02-0011', 'a1b2c3d4-bbbb-4aaa-bbbb-000000000011', 'scrub', 'scrub_02', 'Charlie Brown', 'No Questions', '2025-12-29 11:30:00', '2025-12-29 11:30:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-comm01-0011', 'a1b2c3d4-bbbb-4aaa-bbbb-000000000011', 'committee', 'committee_01', 'Diana Prince', 'Deferred', '2026-01-20 10:00:00', '2026-01-20 10:00:00');

INSERT INTO demand_reviews (id, request_id, review_type, reviewer_id, reviewer_name, decision, created_at, updated_at)
VALUES ('rev-comm02-0011', 'a1b2c3d4-bbbb-4aaa-bbbb-000000000011', 'committee', 'committee_02', 'Edward Norton', 'Deferred', '2026-01-21 14:15:00', '2026-01-21 14:15:00');


-- =============================================================================
-- 4. DEMAND REVIEW CONVERSATIONS (from demand-reviews.json → conversation[])
-- =============================================================================

-- ── Request 1 conversations ──

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0001-01', 'rev-scrub01-0001', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'AI/ML approach for signal detection is well-justified. The FAERS integration plan is solid. No questions from my side.',
    '2026-01-20 09:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0001-02', 'rev-scrub02-0001', 'scrub_02', 'Charlie Brown', 'Scrub_member',
    'Budget and timeline are reasonable for this scope. ML model validation plan is adequate. Approved for committee review.',
    '2026-01-21 11:30:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0001-03', 'rev-comm01-0001', 'committee_01', 'Diana Prince', 'Committee_member',
    'This aligns with the 2026 safety modernization roadmap. Approved.',
    '2026-02-15 10:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0001-04', 'rev-comm02-0001', 'committee_02', 'Edward Norton', 'Committee_member',
    'Good project. Budget is reasonable. Approved.',
    '2026-02-16 14:15:00');

-- ── Request 3 conversations ──

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0003-01', 'rev-scrub01-0003', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'The EDC integration approach looks good. Can you confirm the expected data volume for real-time processing?',
    '2026-02-18 10:30:00');

-- ── Request 4 conversations (multi-message thread) ──

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0004-01', 'rev-scrub01-0004', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'The NLP approach for narrative generation needs more detail. Which LLM are you planning to use?',
    '2026-02-05 09:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0004-02', 'rev-scrub01-0004', 'user_req_01', 'Alice Johnson', 'User',
    'We plan to use Azure OpenAI GPT-4 with fine-tuning on historical narratives.',
    '2026-02-08 14:30:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0004-03', 'rev-scrub02-0004', 'scrub_02', 'Charlie Brown', 'Scrub_member',
    'What is the Argus integration plan? Will this require changes to the existing Argus configuration?',
    '2026-02-06 11:15:00');

-- ── Request 5 conversations ──

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0005-01', 'rev-scrub01-0005', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'Straightforward migration request. No concerns from my side.',
    '2026-01-15 08:30:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0005-02', 'rev-scrub02-0005', 'scrub_02', 'Charlie Brown', 'Scrub_member',
    'Looks fine. Legacy migration is well scoped.',
    '2026-01-16 14:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0005-03', 'rev-comm01-0005', 'committee_01', 'Diana Prince', 'Committee_member',
    'The legacy system migration does not align with current year strategic priorities. Rejecting for now.',
    '2026-02-20 09:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0005-04', 'rev-comm02-0005', 'committee_02', 'Edward Norton', 'Committee_member',
    'Agree with Diana. The ROI for this low-priority migration does not justify the effort right now.',
    '2026-02-21 10:30:00');

-- ── Request 7 conversations ──

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0007-01', 'rev-scrub01-0007', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'Large scope but well documented. The phased approach makes sense.',
    '2026-01-12 09:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0007-02', 'rev-scrub02-0007', 'scrub_02', 'Charlie Brown', 'Scrub_member',
    'Technical feasibility is confirmed. Ready for committee review.',
    '2026-01-13 14:45:00');

-- ── Request 8 conversations ──

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0008-01', 'rev-scrub01-0008', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'The compliance tracking requirements are clearly defined. No questions.',
    '2026-02-15 10:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0008-02', 'rev-scrub02-0008', 'scrub_02', 'Charlie Brown', 'Scrub_member',
    'Approved from scrub side. Regulatory compliance is a high priority area.',
    '2026-02-16 15:30:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0008-03', 'rev-comm01-0008', 'committee_01', 'Diana Prince', 'Committee_member',
    'Please provide details on how this tracker will integrate with existing regulatory submission systems across regions.',
    '2026-03-05 09:20:00');

-- ── Request 11 conversations ──

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0011-01', 'rev-scrub01-0011', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'Label management enhancement is well scoped. Approved.',
    '2025-12-28 09:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0011-02', 'rev-scrub02-0011', 'scrub_02', 'Charlie Brown', 'Scrub_member',
    'No issues. The enhancement request is clear and achievable within the timeline.',
    '2025-12-29 11:30:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0011-03', 'rev-comm01-0011', 'committee_01', 'Diana Prince', 'Committee_member',
    'The budget is too high for H1. Deferring to Q3 when additional funding becomes available.',
    '2026-01-20 10:00:00');

INSERT INTO demand_review_conversations (id, review_id, from_user_id, from_name, role, remarks, created_at)
VALUES ('conv-0011-04', 'rev-comm02-0011', 'committee_02', 'Edward Norton', 'Committee_member',
    'Agree. Good project but timing is not right. Revisit in Q3.',
    '2026-01-21 14:15:00');


-- =============================================================================
-- 5. DEMAND COMMENTS (demand-comments.json is empty, adding sample data)
-- =============================================================================

INSERT INTO demand_comments (id, request_id, user_id, user_name, user_role, text, created_at)
VALUES ('cmt-0001-01', 'a1b2c3d4-1111-4aaa-bbbb-000000000001', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'Great proposal. The AI/ML approach is well thought out.',
    '2026-01-20 09:15:00');

INSERT INTO demand_comments (id, request_id, user_id, user_name, user_role, text, created_at)
VALUES ('cmt-0001-02', 'a1b2c3d4-1111-4aaa-bbbb-000000000001', 'user_req_01', 'Alice Johnson', 'User',
    'Thank you Bob. We have also completed the initial POC with promising results.',
    '2026-01-20 10:30:00');

INSERT INTO demand_comments (id, request_id, user_id, user_name, user_role, text, created_at)
VALUES ('cmt-0001-03', 'a1b2c3d4-1111-4aaa-bbbb-000000000001', 'committee_01', 'Diana Prince', 'Committee_member',
    'Approved at committee level. Please proceed with resource allocation.',
    '2026-02-15 10:30:00');

INSERT INTO demand_comments (id, request_id, user_id, user_name, user_role, text, created_at)
VALUES ('cmt-0004-01', 'a1b2c3d4-4444-4aaa-bbbb-000000000004', 'scrub_01', 'Bob Smith', 'Scrub_member',
    'We need more details on the NLP model validation strategy before we can proceed.',
    '2026-02-05 09:30:00');

INSERT INTO demand_comments (id, request_id, user_id, user_name, user_role, text, created_at)
VALUES ('cmt-0004-02', 'a1b2c3d4-4444-4aaa-bbbb-000000000004', 'user_req_01', 'Alice Johnson', 'User',
    'Uploading the updated architecture document and validation report now.',
    '2026-02-08 15:00:00');

INSERT INTO demand_comments (id, request_id, user_id, user_name, user_role, text, created_at)
VALUES ('cmt-0007-01', 'a1b2c3d4-7777-4aaa-bbbb-000000000007', 'scrub_02', 'Charlie Brown', 'Scrub_member',
    'The phased approach is sensible given the scope. Recommend committee fast-track.',
    '2026-01-13 15:00:00');

INSERT INTO demand_comments (id, request_id, user_id, user_name, user_role, text, created_at)
VALUES ('cmt-0008-01', 'a1b2c3d4-8888-4aaa-bbbb-000000000008', 'committee_01', 'Diana Prince', 'Committee_member',
    'Need clarification on multi-region integration before final approval.',
    '2026-03-05 09:30:00');

INSERT INTO demand_comments (id, request_id, user_id, user_name, user_role, text, created_at)
VALUES ('cmt-0008-02', 'a1b2c3d4-8888-4aaa-bbbb-000000000008', 'user_req_01', 'Alice Johnson', 'User',
    'Working on the integration plan document. Will share by end of this week.',
    '2026-03-06 14:00:00');


-- =============================================================================
-- Seed data load complete.
-- Total records:
--   users:                         5
--   demand_requests:              11
--   demand_reviews:               20
--   demand_review_conversations:  22
--   demand_comments:               8
--   demand_request_attachments:    0 (no attachments in mock data)
-- =============================================================================
