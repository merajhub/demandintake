-- =============================================================================
-- PM-RND Demand Intake - MySQL Database Schema & API Queries
-- =============================================================================
-- This file contains:
--   1. Table schemas for all demand intake entities
--   2. Indexes for performance
--   3. All SQL queries used by the API routes
-- =============================================================================


-- =============================================================================
-- 1. TABLE SCHEMAS
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1.1 USERS TABLE
-- Stores all application users (Requestors, Scrub members, Committee members)
-- Used by: demand-users.js
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id              VARCHAR(50)     PRIMARY KEY,
    wwid            VARCHAR(50)     NOT NULL,
    name            VARCHAR(255)    NOT NULL,
    email           VARCHAR(255)    NOT NULL,
    role            ENUM('User', 'Scrub_member', 'Committee_member') NOT NULL,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_users_role (role),
    INDEX idx_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- 1.2 DEMAND REQUESTS TABLE
-- Stores the main demand intake request with all sections as columns
-- Used by: demand-requests.js
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS demand_requests (
    id                          VARCHAR(36)     PRIMARY KEY,  -- UUID
    created_by                  VARCHAR(50)     NOT NULL,
    created_by_name             VARCHAR(255)    DEFAULT '',
    status                      VARCHAR(50)     NOT NULL DEFAULT 'draft',
    -- Status values: draft, submitted, in_review, clarification_requested,
    --   committee_review, committee_clarification_requested,
    --   approved, rejected, deferred
    submitter_remarks           TEXT            DEFAULT NULL,

    -- Project Overview
    project_title               VARCHAR(500)    DEFAULT NULL,
    domain                      VARCHAR(100)    DEFAULT NULL,  -- Safety, Regulatory, Clinical
    estimated_budget_usd        DECIMAL(15,2)   DEFAULT NULL,
    type_of_request             VARCHAR(100)    DEFAULT NULL,  -- Enhancement, New Development
    priority_level              VARCHAR(50)     DEFAULT NULL,  -- High, Medium, Low
    date_of_submission          DATETIME        DEFAULT NULL,
    estimated_start_date        DATE            DEFAULT NULL,
    estimated_completion_date   DATE            DEFAULT NULL,

    -- Requestor Information
    requestor_name              VARCHAR(255)    DEFAULT NULL,
    department                  VARCHAR(255)    DEFAULT NULL,
    contact_email               VARCHAR(255)    DEFAULT NULL,
    contact_phone               VARCHAR(50)     DEFAULT NULL,
    project_manager             VARCHAR(255)    DEFAULT NULL,

    -- Project Specification
    target_users                TEXT            DEFAULT NULL,
    platform                    VARCHAR(100)    DEFAULT NULL,  -- Web, Desktop, Cloud
    technology_preference       VARCHAR(255)    DEFAULT NULL,
    project_description         TEXT            DEFAULT NULL,
    project_goals               TEXT            DEFAULT NULL,
    business_problem            TEXT            DEFAULT NULL,
    expected_outcome            TEXT            DEFAULT NULL,
    resource_requirements       TEXT            DEFAULT NULL,
    dependencies                TEXT            DEFAULT NULL,
    compliance_requirements     TEXT            DEFAULT NULL,

    -- Management Notes
    stakeholders                TEXT            DEFAULT NULL,
    risks                       TEXT            DEFAULT NULL,
    review_notes                TEXT            DEFAULT NULL,
    additional_notes            TEXT            DEFAULT NULL,
    approval_signoff            VARCHAR(255)    DEFAULT NULL,

    -- Requestor metadata (for intake.js route)
    requestor_wwid              VARCHAR(100)    DEFAULT NULL,
    requestor_email             VARCHAR(255)    DEFAULT NULL,
    pm_scrum_master             VARCHAR(255)    DEFAULT NULL,

    -- Timestamps
    created_at                  TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Foreign Key
    CONSTRAINT fk_requests_created_by FOREIGN KEY (created_by) REFERENCES users(id),

    -- Indexes
    INDEX idx_requests_status (status),
    INDEX idx_requests_created_by (created_by),
    INDEX idx_requests_domain (domain),
    INDEX idx_requests_priority (priority_level),
    INDEX idx_requests_submission_date (date_of_submission),
    INDEX idx_requests_requestor_wwid (requestor_wwid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- 1.3 DEMAND REQUEST ATTACHMENTS TABLE
-- Stores file attachments for demand requests
-- Used by: demand-requests.js (attachments array in projectSpecification)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS demand_request_attachments (
    id              VARCHAR(36)     PRIMARY KEY,  -- UUID
    request_id      VARCHAR(36)     NOT NULL,
    original_name   VARCHAR(500)    NOT NULL,
    stored_name     VARCHAR(500)    NOT NULL,
    file_path       VARCHAR(1000)   DEFAULT NULL,
    file_size       BIGINT          DEFAULT NULL,
    mime_type       VARCHAR(255)    DEFAULT NULL,
    uploaded_at     TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_req_attachments_request FOREIGN KEY (request_id) REFERENCES demand_requests(id) ON DELETE CASCADE,
    INDEX idx_req_attachments_request_id (request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- 1.4 DEMAND COMMENTS TABLE
-- Stores comments/discussion on demand requests
-- Used by: demand-comments.js
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS demand_comments (
    id              VARCHAR(36)     PRIMARY KEY,  -- UUID
    request_id      VARCHAR(36)     NOT NULL,
    user_id         VARCHAR(50)     NOT NULL,
    user_name       VARCHAR(255)    DEFAULT '',
    user_role       VARCHAR(50)     DEFAULT '',
    text            TEXT            NOT NULL,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_comments_request FOREIGN KEY (request_id) REFERENCES demand_requests(id) ON DELETE CASCADE,
    CONSTRAINT fk_comments_user FOREIGN KEY (user_id) REFERENCES users(id),

    INDEX idx_comments_request_id (request_id),
    INDEX idx_comments_user_id (user_id),
    INDEX idx_comments_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- 1.5 DEMAND REVIEWS TABLE
-- Stores review records (scrub / committee) for demand requests
-- Used by: demand-reviews.js
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS demand_reviews (
    id              VARCHAR(36)     PRIMARY KEY,  -- UUID
    request_id      VARCHAR(36)     NOT NULL,
    review_type     ENUM('scrub', 'committee') NOT NULL,
    reviewer_id     VARCHAR(50)     NOT NULL,
    reviewer_name   VARCHAR(255)    DEFAULT '',
    decision        VARCHAR(100)    DEFAULT '',
    -- Decision values: '', 'No Questions', 'Needs Clarification', 'Approved', 'Rejected'
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_reviews_request FOREIGN KEY (request_id) REFERENCES demand_requests(id) ON DELETE CASCADE,
    CONSTRAINT fk_reviews_reviewer FOREIGN KEY (reviewer_id) REFERENCES users(id),

    -- Unique constraint: one review per reviewer per request per type
    UNIQUE INDEX idx_reviews_unique (request_id, review_type, reviewer_id),
    INDEX idx_reviews_request_id (request_id),
    INDEX idx_reviews_review_type (review_type),
    INDEX idx_reviews_reviewer_id (reviewer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- 1.6 DEMAND REVIEW CONVERSATIONS TABLE
-- Stores the conversation thread within each review (messages/remarks)
-- Used by: demand-reviews.js (conversation array)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS demand_review_conversations (
    id              VARCHAR(36)     PRIMARY KEY,  -- UUID
    review_id       VARCHAR(36)     NOT NULL,
    from_user_id    VARCHAR(50)     NOT NULL,
    from_name       VARCHAR(255)    DEFAULT '',
    role            VARCHAR(50)     DEFAULT '',
    remarks         TEXT            DEFAULT NULL,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,

    -- Attachment fields (optional, for file uploads within review conversations)
    attachment_original_name    VARCHAR(500)    DEFAULT NULL,
    attachment_stored_name      VARCHAR(500)    DEFAULT NULL,
    attachment_size             BIGINT          DEFAULT NULL,
    attachment_mime_type        VARCHAR(255)    DEFAULT NULL,

    CONSTRAINT fk_conversation_review FOREIGN KEY (review_id) REFERENCES demand_reviews(id) ON DELETE CASCADE,

    INDEX idx_conversation_review_id (review_id),
    INDEX idx_conversation_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- =============================================================================
-- 2. API QUERIES
-- =============================================================================


-- =============================================================================
-- 2.1 DEMAND USERS QUERIES (demand-users.js)
-- =============================================================================

-- GET /api/demand-users — Fetch all users
-- Name: FETCH_ALL_USERS
SELECT id, name, email, role, created_at, updated_at
FROM users
ORDER BY name ASC;

-- GET /api/demand-users/:id — Fetch single user by ID
-- Name: FETCH_USER_BY_ID
-- Params: :userId
SELECT id, name, email, role, created_at, updated_at
FROM users
WHERE id = :userId;


-- =============================================================================
-- 2.2 DEMAND REQUESTS QUERIES (demand-requests.js)
-- =============================================================================

-- GET /api/demand-requests?userId=xxx&role=User
-- Name: FETCH_REQUESTS_BY_USER (User role — sees only own requests, all statuses)
-- Params: :userId
SELECT *
FROM demand_requests
WHERE created_by = :userId
ORDER BY updated_at DESC;

-- GET /api/demand-requests?role=Scrub_member (or Committee_member)
-- Name: FETCH_ALL_NON_DRAFT_REQUESTS (Scrub/Committee — sees all non-draft requests)
SELECT *
FROM demand_requests
WHERE status != 'draft'
ORDER BY updated_at DESC;

-- GET /api/demand-requests/:id
-- Name: FETCH_REQUEST_BY_ID
-- Params: :requestId
SELECT *
FROM demand_requests
WHERE id = :requestId;

-- POST /api/demand-requests — Create a new demand request
-- Name: INSERT_DEMAND_REQUEST
-- Params: all fields from request body
INSERT INTO demand_requests (
    id, created_by, created_by_name, status,
    project_title, domain, estimated_budget_usd, type_of_request,
    priority_level, date_of_submission, estimated_start_date, estimated_completion_date,
    requestor_name, department, contact_email, contact_phone, project_manager,
    target_users, platform, technology_preference, project_description,
    project_goals, business_problem, expected_outcome,
    resource_requirements, dependencies, compliance_requirements,
    stakeholders, risks, review_notes, additional_notes,
    requestor_wwid, requestor_email, pm_scrum_master,
    created_at, updated_at
) VALUES (
    :id, :createdBy, :createdByName, :status,
    :projectTitle, :domain, :estimatedBudgetUsd, :typeOfRequest,
    :priorityLevel, :dateOfSubmission, :estimatedStartDate, :estimatedCompletionDate,
    :requestorName, :department, :contactEmail, :contactPhone, :projectManager,
    :targetUsers, :platform, :technologyPreference, :projectDescription,
    :projectGoals, :businessProblem, :expectedOutcome,
    :resourceRequirements, :dependencies, :complianceRequirements,
    :stakeholders, :risks, :reviewNotes, :additionalNotes,
    :requestorWwid, :requestorEmail, :pmScrumMaster,
    NOW(), NOW()
);

-- PUT /api/demand-requests/:id — Update a demand request (full update)
-- Name: UPDATE_DEMAND_REQUEST
-- Params: all fields from request body + :requestId
UPDATE demand_requests
SET
    project_title               = :projectTitle,
    domain                      = :domain,
    estimated_budget_usd        = :estimatedBudgetUsd,
    type_of_request             = :typeOfRequest,
    priority_level              = :priorityLevel,
    date_of_submission          = :dateOfSubmission,
    estimated_start_date        = :estimatedStartDate,
    estimated_completion_date   = :estimatedCompletionDate,
    requestor_name              = :requestorName,
    department                  = :department,
    contact_email               = :contactEmail,
    contact_phone               = :contactPhone,
    project_manager             = :projectManager,
    target_users                = :targetUsers,
    platform                    = :platform,
    technology_preference       = :technologyPreference,
    project_description         = :projectDescription,
    project_goals               = :projectGoals,
    business_problem            = :businessProblem,
    expected_outcome            = :expectedOutcome,
    resource_requirements       = :resourceRequirements,
    dependencies                = :dependencies,
    compliance_requirements     = :complianceRequirements,
    stakeholders                = :stakeholders,
    risks                       = :risks,
    review_notes                = :reviewNotes,
    additional_notes            = :additionalNotes,
    status                      = COALESCE(:status, status),
    submitter_remarks           = :submitterRemarks,
    requestor_wwid              = :requestorWwid,
    requestor_email             = :requestorEmail,
    pm_scrum_master             = :pmScrumMaster,
    updated_at                  = NOW()
WHERE id = :requestId;

-- PATCH /api/demand-requests/:id/status — Update status only
-- Name: UPDATE_REQUEST_STATUS
-- Params: :status, :requestId
UPDATE demand_requests
SET
    status     = :status,
    updated_at = NOW()
WHERE id = :requestId;


-- =============================================================================
-- 2.3 DEMAND COMMENTS QUERIES (demand-comments.js)
-- =============================================================================

-- GET /api/demand-comments?requestId=xxx — Fetch comments for a request
-- Name: FETCH_COMMENTS_BY_REQUEST
-- Params: :requestId
SELECT id, request_id, user_id, user_name, user_role, text, created_at
FROM demand_comments
WHERE request_id = :requestId
ORDER BY created_at ASC;

-- GET /api/demand-comments (no filter) — Fetch all comments
-- Name: FETCH_ALL_COMMENTS
SELECT id, request_id, user_id, user_name, user_role, text, created_at
FROM demand_comments
ORDER BY created_at ASC;

-- POST /api/demand-comments — Insert a new comment
-- Name: INSERT_COMMENT
-- Params: :id, :requestId, :userId, :userName, :userRole, :text
INSERT INTO demand_comments (
    id, request_id, user_id, user_name, user_role, text, created_at
) VALUES (
    :id, :requestId, :userId, :userName, :userRole, :text, NOW()
);


-- =============================================================================
-- 2.4 DEMAND REVIEWS QUERIES (demand-reviews.js)
-- =============================================================================

-- GET /api/demand-reviews — Fetch ALL reviews (no filters)
-- Name: FETCH_ALL_REVIEWS
SELECT
    r.id,
    r.request_id,
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.created_at,
    r.updated_at
FROM demand_reviews r
ORDER BY r.created_at ASC;

-- GET /api/demand-reviews?requestId=xxx — Fetch reviews by requestId only
-- Name: FETCH_REVIEWS_BY_REQUEST
-- Params: :requestId
SELECT
    r.id,
    r.request_id,
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.created_at,
    r.updated_at
FROM demand_reviews r
WHERE r.request_id = :requestId
ORDER BY r.created_at ASC;

-- GET /api/demand-reviews?reviewType=xxx — Fetch reviews by reviewType only
-- Name: FETCH_REVIEWS_BY_TYPE
-- Params: :reviewType
SELECT
    r.id,
    r.request_id,
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.created_at,
    r.updated_at
FROM demand_reviews r
WHERE r.review_type = :reviewType
ORDER BY r.created_at ASC;

-- GET /api/demand-reviews?requestId=xxx&reviewType=xxx — Fetch reviews by both filters
-- Name: FETCH_REVIEWS_BY_REQUEST_AND_TYPE
-- Params: :requestId, :reviewType
SELECT
    r.id,
    r.request_id,
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.created_at,
    r.updated_at
FROM demand_reviews r
WHERE r.request_id = :requestId
  AND r.review_type = :reviewType
ORDER BY r.created_at ASC;

-- Fetch review conversations for a given review
-- Name: FETCH_REVIEW_CONVERSATIONS
-- Params: :reviewId
SELECT
    c.id,
    c.review_id,
    c.from_user_id,
    c.from_name,
    c.role,
    c.remarks,
    c.created_at,
    c.attachment_original_name,
    c.attachment_stored_name,
    c.attachment_size,
    c.attachment_mime_type
FROM demand_review_conversations c
WHERE c.review_id = :reviewId
ORDER BY c.created_at ASC;

-- Fetch ALL reviews WITH conversations (no filters)
-- Name: FETCH_ALL_REVIEWS_WITH_CONVERSATIONS
SELECT
    r.id            AS review_id,
    r.request_id,
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.created_at    AS review_created_at,
    r.updated_at    AS review_updated_at,
    c.id            AS conversation_id,
    c.from_user_id,
    c.from_name,
    c.role          AS conversation_role,
    c.remarks,
    c.created_at    AS message_created_at,
    c.attachment_original_name,
    c.attachment_stored_name,
    c.attachment_size,
    c.attachment_mime_type
FROM demand_reviews r
LEFT JOIN demand_review_conversations c ON c.review_id = r.id
ORDER BY r.created_at ASC, c.created_at ASC;

-- Fetch reviews WITH conversations by requestId only
-- Name: FETCH_REVIEWS_WITH_CONVERSATIONS_BY_REQUEST
-- Params: :requestId
SELECT
    r.id            AS review_id,
    r.request_id,
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.created_at    AS review_created_at,
    r.updated_at    AS review_updated_at,
    c.id            AS conversation_id,
    c.from_user_id,
    c.from_name,
    c.role          AS conversation_role,
    c.remarks,
    c.created_at    AS message_created_at,
    c.attachment_original_name,
    c.attachment_stored_name,
    c.attachment_size,
    c.attachment_mime_type
FROM demand_reviews r
LEFT JOIN demand_review_conversations c ON c.review_id = r.id
WHERE r.request_id = :requestId
ORDER BY r.created_at ASC, c.created_at ASC;

-- Fetch reviews WITH conversations by reviewType only
-- Name: FETCH_REVIEWS_WITH_CONVERSATIONS_BY_TYPE
-- Params: :reviewType
SELECT
    r.id            AS review_id,
    r.request_id,
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.created_at    AS review_created_at,
    r.updated_at    AS review_updated_at,
    c.id            AS conversation_id,
    c.from_user_id,
    c.from_name,
    c.role          AS conversation_role,
    c.remarks,
    c.created_at    AS message_created_at,
    c.attachment_original_name,
    c.attachment_stored_name,
    c.attachment_size,
    c.attachment_mime_type
FROM demand_reviews r
LEFT JOIN demand_review_conversations c ON c.review_id = r.id
WHERE r.review_type = :reviewType
ORDER BY r.created_at ASC, c.created_at ASC;

-- Fetch reviews WITH conversations by both requestId and reviewType
-- Name: FETCH_REVIEWS_WITH_CONVERSATIONS_BY_REQUEST_AND_TYPE
-- Params: :requestId, :reviewType
SELECT
    r.id            AS review_id,
    r.request_id,
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.created_at    AS review_created_at,
    r.updated_at    AS review_updated_at,
    c.id            AS conversation_id,
    c.from_user_id,
    c.from_name,
    c.role          AS conversation_role,
    c.remarks,
    c.created_at    AS message_created_at,
    c.attachment_original_name,
    c.attachment_stored_name,
    c.attachment_size,
    c.attachment_mime_type
FROM demand_reviews r
LEFT JOIN demand_review_conversations c ON c.review_id = r.id
WHERE r.request_id = :requestId
  AND r.review_type = :reviewType
ORDER BY r.created_at ASC, c.created_at ASC;

-- Check if a review already exists (for upsert logic)
-- Name: FIND_EXISTING_REVIEW
-- Params: :requestId, :reviewType, :reviewerId
SELECT id, decision
FROM demand_reviews
WHERE request_id = :requestId
  AND review_type = :reviewType
  AND reviewer_id = :reviewerId;

-- POST /api/demand-reviews — Insert a new review
-- Name: INSERT_REVIEW
-- Params: :id, :requestId, :reviewType, :reviewerId, :reviewerName, :decision
INSERT INTO demand_reviews (
    id, request_id, review_type, reviewer_id, reviewer_name, decision,
    created_at, updated_at
) VALUES (
    :id, :requestId, :reviewType, :reviewerId, :reviewerName, :decision,
    NOW(), NOW()
);

-- Update an existing review's decision (for upsert)
-- Name: UPDATE_REVIEW_DECISION
-- Params: :decision, :reviewId
UPDATE demand_reviews
SET
    decision   = :decision,
    updated_at = NOW()
WHERE id = :reviewId;

-- Insert a conversation message into a review
-- Name: INSERT_REVIEW_CONVERSATION
-- Params: :id, :reviewId, :fromUserId, :fromName, :role, :remarks,
--         :attachmentOriginalName, :attachmentStoredName, :attachmentSize, :attachmentMimeType
INSERT INTO demand_review_conversations (
    id, review_id, from_user_id, from_name, role, remarks, created_at,
    attachment_original_name, attachment_stored_name, attachment_size, attachment_mime_type
) VALUES (
    :id, :reviewId, :fromUserId, :fromName, :role, :remarks, NOW(),
    :attachmentOriginalName, :attachmentStoredName, :attachmentSize, :attachmentMimeType
);


-- =============================================================================
-- 2.5 INTAKE ROUTE QUERIES (intake.js)
-- These map to the named queries used with the Cloud SQL API
-- =============================================================================

-- Name: FETCH_ALL_INTAKE_REQUEST
-- Used by: GET /api/intake/all
SELECT *
FROM demand_requests
ORDER BY created_at DESC;

-- Name: FETCH_MY_INTAKE_REQUEST_BY_DOMAIN
-- Used by: GET /api/intake/bydomain/:domain
-- Params: :domain
SELECT *
FROM demand_requests
WHERE domain = :domain
ORDER BY created_at DESC;

-- Name: FETCH_REQUEST_BY_USER_DOMAIN
-- Used by: GET /api/intake/myrequests/:wwid
-- Params: :wwid
SELECT *
FROM demand_requests
WHERE requestor_wwid = :wwid
ORDER BY created_at DESC;

-- Name: FETCH_INTAKE_BY_ID
-- Used by: GET /api/intake/:id
-- Params: :requestId
SELECT *
FROM demand_requests
WHERE id = :requestId;

-- Name: INSERT_INTAKE_FORM (SaveIntakeFormAsync)
-- Used by: POST /api/intake/
-- Params: all form fields
INSERT INTO demand_requests (
    id,
    project_title, requestor_name, department, contact_email, contact_phone,
    date_of_submission, platform, compliance_requirements, type_of_request,
    project_description, project_goals, business_problem, expected_outcome,
    estimated_completion_date, estimated_start_date, resource_requirements,
    target_users, priority_level, dependencies, status, technology_preference,
    estimated_budget_usd, stakeholders, risks, review_notes, additional_notes,
    approval_signoff, requestor_wwid, domain, pm_scrum_master, requestor_email,
    created_at, updated_at
) VALUES (
    UUID(),
    :projectTitle, :requestorName, :department, :contactEmail, :contactPhone,
    :dateOfSubmission, :platform, :complianceRequirements, :typeOfRequest,
    :projectDescription, :projectGoals, :businessProblem, :expectedOutcome,
    :estimatedCompletionDate, :estimatedStartDate, :resourceRequirements,
    :targetUsers, :priorityLevel, :dependencies, :status, :technologyPreference,
    :estimatedBudget, :stakeholders, :risks, :reviewNotes, :additionalNotes,
    :approvalSignoff, :requestorWwid, :domain, :pmScrumMaster, :requestorEmail,
    NOW(), NOW()
);

-- Name: updateRequest (Stored Procedure)
-- Used by: POST /api/intake/update
-- Params: :requestId, form data fields
DELIMITER $$
CREATE PROCEDURE updateRequest(
    IN p_request_id VARCHAR(36),
    IN p_project_title VARCHAR(500),
    IN p_requestor_name VARCHAR(255),
    IN p_department VARCHAR(255),
    IN p_contact_email VARCHAR(255),
    IN p_contact_phone VARCHAR(50),
    IN p_date_of_submission DATETIME,
    IN p_platform VARCHAR(100),
    IN p_compliance_requirements TEXT,
    IN p_type_of_request VARCHAR(100),
    IN p_project_description TEXT,
    IN p_project_goals TEXT,
    IN p_business_problem TEXT,
    IN p_expected_outcome TEXT,
    IN p_estimated_completion_date DATE,
    IN p_estimated_start_date DATE,
    IN p_resource_requirements TEXT,
    IN p_target_users TEXT,
    IN p_priority_level VARCHAR(50),
    IN p_dependencies TEXT,
    IN p_status VARCHAR(50),
    IN p_technology_preference VARCHAR(255),
    IN p_estimated_budget DECIMAL(15,2),
    IN p_stakeholders TEXT,
    IN p_risks TEXT,
    IN p_review_notes TEXT,
    IN p_additional_notes TEXT,
    IN p_approval_signoff VARCHAR(255),
    IN p_requestor_wwid VARCHAR(100),
    IN p_domain VARCHAR(100),
    IN p_pm_scrum_master VARCHAR(255)
)
BEGIN
    UPDATE demand_requests
    SET
        project_title             = p_project_title,
        requestor_name            = p_requestor_name,
        department                = p_department,
        contact_email             = p_contact_email,
        contact_phone             = p_contact_phone,
        date_of_submission        = p_date_of_submission,
        platform                  = p_platform,
        compliance_requirements   = p_compliance_requirements,
        type_of_request           = p_type_of_request,
        project_description       = p_project_description,
        project_goals             = p_project_goals,
        business_problem          = p_business_problem,
        expected_outcome          = p_expected_outcome,
        estimated_completion_date = p_estimated_completion_date,
        estimated_start_date      = p_estimated_start_date,
        resource_requirements     = p_resource_requirements,
        target_users              = p_target_users,
        priority_level            = p_priority_level,
        dependencies              = p_dependencies,
        status                    = p_status,
        technology_preference     = p_technology_preference,
        estimated_budget_usd      = p_estimated_budget,
        stakeholders              = p_stakeholders,
        risks                     = p_risks,
        review_notes              = p_review_notes,
        additional_notes          = p_additional_notes,
        approval_signoff          = p_approval_signoff,
        requestor_wwid            = p_requestor_wwid,
        domain                    = p_domain,
        pm_scrum_master           = p_pm_scrum_master,
        updated_at                = NOW()
    WHERE id = p_request_id;
END$$
DELIMITER ;

-- Name: updateDemandRequest (Stored Procedure)
-- Used by: PUT /api/mysql-demand-requests/:id
-- Accepts a request ID and a JSON payload of column-value pairs to update.
-- Params: p_request_id (VARCHAR), p_json_data (JSON string)
DELIMITER $$
CREATE PROCEDURE updateDemandRequest(
    IN p_request_id VARCHAR(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_json_data JSON
)
BEGIN
    -- Declare local variables with explicit collation to avoid
    -- "Illegal mix of collations" between JSON functions (utf8mb4_0900_ai_ci)
    -- and table columns (utf8mb4_unicode_ci).
    DECLARE v_project_title             VARCHAR(500)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_domain                    VARCHAR(100)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_estimated_budget_usd      DECIMAL(15,2) DEFAULT NULL;
    DECLARE v_type_of_request           VARCHAR(100)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_priority_level            VARCHAR(50)   CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_date_of_submission        VARCHAR(50)   CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_estimated_start_date      VARCHAR(50)   CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_estimated_completion_date VARCHAR(50)   CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_requestor_name            VARCHAR(255)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_department                VARCHAR(255)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_contact_email             VARCHAR(255)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_contact_phone             VARCHAR(50)   CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_project_manager           VARCHAR(255)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_target_users              TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_platform                  VARCHAR(100)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_technology_preference     VARCHAR(255)  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_project_description       TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_project_goals             TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_business_problem          TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_expected_outcome          TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_resource_requirements     TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_dependencies              TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_compliance_requirements   TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_stakeholders              TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_risks                     TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_review_notes              TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_additional_notes          TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_status                    VARCHAR(50)   CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_submitter_remarks         TEXT           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL;
    DECLARE v_has_submitter_remarks     TINYINT       DEFAULT 0;

    -- Extract JSON values into local variables (collation is now fixed)
    SET v_project_title             = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.project_title'));
    SET v_domain                    = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.domain'));
    SET v_estimated_budget_usd      = JSON_EXTRACT(p_json_data, '$.estimated_budget_usd');
    SET v_type_of_request           = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.type_of_request'));
    SET v_priority_level            = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.priority_level'));
    SET v_date_of_submission        = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.date_of_submission'));
    SET v_estimated_start_date      = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.estimated_start_date'));
    SET v_estimated_completion_date = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.estimated_completion_date'));
    SET v_requestor_name            = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.requestor_name'));
    SET v_department                = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.department'));
    SET v_contact_email             = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.contact_email'));
    SET v_contact_phone             = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.contact_phone'));
    SET v_project_manager           = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.project_manager'));
    SET v_target_users              = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.target_users'));
    SET v_platform                  = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.platform'));
    SET v_technology_preference     = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.technology_preference'));
    SET v_project_description       = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.project_description'));
    SET v_project_goals             = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.project_goals'));
    SET v_business_problem          = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.business_problem'));
    SET v_expected_outcome          = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.expected_outcome'));
    SET v_resource_requirements     = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.resource_requirements'));
    SET v_dependencies              = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.dependencies'));
    SET v_compliance_requirements   = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.compliance_requirements'));
    SET v_stakeholders              = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.stakeholders'));
    SET v_risks                     = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.risks'));
    SET v_review_notes              = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.review_notes'));
    SET v_additional_notes          = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.additional_notes'));
    SET v_status                    = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.status'));
    SET v_has_submitter_remarks     = JSON_CONTAINS_PATH(p_json_data, 'one', '$.submitter_remarks');
    IF v_has_submitter_remarks THEN
        SET v_submitter_remarks     = JSON_UNQUOTE(JSON_EXTRACT(p_json_data, '$.submitter_remarks'));
    END IF;

    UPDATE demand_requests
    SET
        project_title             = IFNULL(v_project_title, project_title),
        domain                    = IFNULL(v_domain, domain),
        estimated_budget_usd      = IFNULL(v_estimated_budget_usd, estimated_budget_usd),
        type_of_request           = IFNULL(v_type_of_request, type_of_request),
        priority_level            = IFNULL(v_priority_level, priority_level),
        date_of_submission        = IFNULL(v_date_of_submission, date_of_submission),
        estimated_start_date      = IFNULL(v_estimated_start_date, estimated_start_date),
        estimated_completion_date = IFNULL(v_estimated_completion_date, estimated_completion_date),
        requestor_name            = IFNULL(v_requestor_name, requestor_name),
        department                = IFNULL(v_department, department),
        contact_email             = IFNULL(v_contact_email, contact_email),
        contact_phone             = IFNULL(v_contact_phone, contact_phone),
        project_manager           = IFNULL(v_project_manager, project_manager),
        target_users              = IFNULL(v_target_users, target_users),
        platform                  = IFNULL(v_platform, platform),
        technology_preference     = IFNULL(v_technology_preference, technology_preference),
        project_description       = IFNULL(v_project_description, project_description),
        project_goals             = IFNULL(v_project_goals, project_goals),
        business_problem          = IFNULL(v_business_problem, business_problem),
        expected_outcome          = IFNULL(v_expected_outcome, expected_outcome),
        resource_requirements     = IFNULL(v_resource_requirements, resource_requirements),
        dependencies              = IFNULL(v_dependencies, dependencies),
        compliance_requirements   = IFNULL(v_compliance_requirements, compliance_requirements),
        stakeholders              = IFNULL(v_stakeholders, stakeholders),
        risks                     = IFNULL(v_risks, risks),
        review_notes              = IFNULL(v_review_notes, review_notes),
        additional_notes          = IFNULL(v_additional_notes, additional_notes),
        status                    = IFNULL(v_status, status),
        submitter_remarks         = IF(v_has_submitter_remarks, v_submitter_remarks, submitter_remarks),
        updated_at                = NOW()
    WHERE id = p_request_id;
END$$
DELIMITER ;


-- Name: UPDATE_STATUS
-- Used by: POST /api/intake/updatestatus
-- Params: :status, :requestId
UPDATE demand_requests
SET
    status     = :status,
    updated_at = NOW()
WHERE id = :requestId;


-- =============================================================================
-- 2.6 DEMAND REQUEST ATTACHMENTS QUERIES
-- =============================================================================

-- Insert an attachment record
-- Name: INSERT_REQUEST_ATTACHMENT
-- Params: :id, :requestId, :originalName, :storedName, :filePath, :fileSize, :mimeType
INSERT INTO demand_request_attachments (
    id, request_id, original_name, stored_name, file_path, file_size, mime_type, uploaded_at
) VALUES (
    :id, :requestId, :originalName, :storedName, :filePath, :fileSize, :mimeType, NOW()
);

-- Fetch attachments for a request
-- Name: FETCH_ATTACHMENTS_BY_REQUEST
-- Params: :requestId
SELECT id, request_id, original_name, stored_name, file_path, file_size, mime_type, uploaded_at
FROM demand_request_attachments
WHERE request_id = :requestId
ORDER BY uploaded_at ASC;

-- Delete an attachment
-- Name: DELETE_ATTACHMENT
-- Params: :attachmentId
DELETE FROM demand_request_attachments
WHERE id = :attachmentId;


-- =============================================================================
-- 3. USEFUL AGGREGATE / REPORTING QUERIES
-- =============================================================================

-- Count requests by status (for dashboard)
-- Name: COUNT_REQUESTS_BY_STATUS
SELECT status, COUNT(*) AS total
FROM demand_requests
GROUP BY status
ORDER BY total DESC;

-- Count requests by domain
-- Name: COUNT_REQUESTS_BY_DOMAIN
SELECT domain, COUNT(*) AS total
FROM demand_requests
WHERE status != 'draft'
GROUP BY domain
ORDER BY total DESC;

-- Count requests by priority
-- Name: COUNT_REQUESTS_BY_PRIORITY
SELECT priority_level, COUNT(*) AS total
FROM demand_requests
WHERE status != 'draft'
GROUP BY priority_level;

-- Fetch all reviews summary for a request (decision status per reviewer)
-- Name: FETCH_REVIEW_SUMMARY_FOR_REQUEST
-- Params: :requestId
SELECT
    r.review_type,
    r.reviewer_id,
    r.reviewer_name,
    r.decision,
    r.updated_at,
    (SELECT COUNT(*) FROM demand_review_conversations c WHERE c.review_id = r.id) AS message_count
FROM demand_reviews r
WHERE r.request_id = :requestId
ORDER BY r.review_type, r.reviewer_name;


-- =============================================================================
-- 4. SEED DATA (matches existing JSON mock data)
-- =============================================================================

-- Seed Users
INSERT INTO users (id, name, email, role) VALUES
('user_req_01',   'Alice Johnson',  'alice@jnj.com',   'User'),
('scrub_01',      'Bob Smith',      'bob@jnj.com',     'Scrub_member'),
('scrub_02',      'Charlie Brown',  'charlie@jnj.com', 'Scrub_member'),
('committee_01',  'Diana Prince',   'diana@jnj.com',   'Committee_member'),
('committee_02',  'Edward Norton',  'edward@jnj.com',  'Committee_member');
