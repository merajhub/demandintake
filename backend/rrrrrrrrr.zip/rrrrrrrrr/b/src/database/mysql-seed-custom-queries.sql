-- =============================================================================
-- Seed data for custom_queries table
-- Inserts all SELECT queries with db prefix "pms_rnd_intake.<table_name>"
-- Type: fetch
-- =============================================================================

-- Create the custom_queries table if it doesn't exist
CREATE TABLE IF NOT EXISTS custom_queries (
  `id`         INT           NOT NULL AUTO_INCREMENT,
  `query_name` VARCHAR(150)  NOT NULL,
  `query`      TEXT          NOT NULL,
  `type`       VARCHAR(150)  NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- =============================================================================
-- 2.1 DEMAND USERS QUERIES
-- =============================================================================

-- FETCH_ALL_USERS
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_ALL_USERS',
  'SELECT id, name, email, role, created_at, updated_at FROM pms_rnd_intake.users ORDER BY name ASC',
  'fetch'
);

-- FETCH_USER_BY_ID
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_USER_BY_ID',
  'SELECT id, name, email, role, created_at, updated_at FROM pms_rnd_intake.users WHERE id = %s',
  'fetch'
);


-- =============================================================================
-- 2.2 DEMAND REQUESTS QUERIES
-- =============================================================================

-- FETCH_REQUESTS_BY_USER
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REQUESTS_BY_USER',
  'SELECT * FROM pms_rnd_intake.demand_requests WHERE created_by = %s ORDER BY updated_at DESC',
  'fetch'
);

-- FETCH_ALL_NON_DRAFT_REQUESTS
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_ALL_NON_DRAFT_REQUESTS',
  'SELECT * FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' ORDER BY updated_at DESC',
  'fetch'
);

-- FETCH_REQUEST_BY_ID
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REQUEST_BY_ID',
  'SELECT * FROM pms_rnd_intake.demand_requests WHERE id = %s',
  'fetch'
);


-- =============================================================================
-- 2.3 DEMAND COMMENTS QUERIES
-- =============================================================================

-- FETCH_COMMENTS_BY_REQUEST
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_COMMENTS_BY_REQUEST',
  'SELECT id, request_id, user_id, user_name, user_role, text, created_at FROM pms_rnd_intake.demand_comments WHERE request_id = %s ORDER BY created_at ASC',
  'fetch'
);

-- FETCH_ALL_COMMENTS
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_ALL_COMMENTS',
  'SELECT id, request_id, user_id, user_name, user_role, text, created_at FROM pms_rnd_intake.demand_comments ORDER BY created_at ASC',
  'fetch'
);


-- =============================================================================
-- 2.4 DEMAND REVIEWS QUERIES
-- =============================================================================

-- FETCH_ALL_REVIEWS
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_ALL_REVIEWS',
  'SELECT r.id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at, r.updated_at FROM pms_rnd_intake.demand_reviews r ORDER BY r.created_at ASC',
  'fetch'
);

-- FETCH_REVIEWS_BY_REQUEST
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REVIEWS_BY_REQUEST',
  'SELECT r.id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at, r.updated_at FROM pms_rnd_intake.demand_reviews r WHERE r.request_id = %s ORDER BY r.created_at ASC',
  'fetch'
);

-- FETCH_REVIEWS_BY_TYPE
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REVIEWS_BY_TYPE',
  'SELECT r.id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at, r.updated_at FROM pms_rnd_intake.demand_reviews r WHERE r.review_type = %s ORDER BY r.created_at ASC',
  'fetch'
);

-- FETCH_REVIEWS_BY_REQUEST_AND_TYPE
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REVIEWS_BY_REQUEST_AND_TYPE',
  'SELECT r.id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at, r.updated_at FROM pms_rnd_intake.demand_reviews r WHERE r.request_id = %s AND r.review_type = %s ORDER BY r.created_at ASC',
  'fetch'
);

-- FETCH_REVIEW_CONVERSATIONS
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REVIEW_CONVERSATIONS',
  'SELECT c.id, c.review_id, c.from_user_id, c.from_name, c.role, c.remarks, c.created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_review_conversations c WHERE c.review_id = %s ORDER BY c.created_at ASC',
  'fetch'
);

-- FETCH_ALL_REVIEWS_WITH_CONVERSATIONS
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_ALL_REVIEWS_WITH_CONVERSATIONS',
  'SELECT r.id AS review_id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at AS review_created_at, r.updated_at AS review_updated_at, c.id AS conversation_id, c.from_user_id, c.from_name, c.role AS conversation_role, c.remarks, c.created_at AS message_created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_reviews r LEFT JOIN pms_rnd_intake.demand_review_conversations c ON c.review_id = r.id ORDER BY r.created_at ASC, c.created_at ASC',
  'fetch'
);

-- FETCH_REVIEWS_WITH_CONVERSATIONS_BY_REQUEST
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REVIEWS_WITH_CONVERSATIONS_BY_REQUEST',
  'SELECT r.id AS review_id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at AS review_created_at, r.updated_at AS review_updated_at, c.id AS conversation_id, c.from_user_id, c.from_name, c.role AS conversation_role, c.remarks, c.created_at AS message_created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_reviews r LEFT JOIN pms_rnd_intake.demand_review_conversations c ON c.review_id = r.id WHERE r.request_id = %s ORDER BY r.created_at ASC, c.created_at ASC',
  'fetch'
);

-- FETCH_REVIEWS_WITH_CONVERSATIONS_BY_TYPE
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REVIEWS_WITH_CONVERSATIONS_BY_TYPE',
  'SELECT r.id AS review_id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at AS review_created_at, r.updated_at AS review_updated_at, c.id AS conversation_id, c.from_user_id, c.from_name, c.role AS conversation_role, c.remarks, c.created_at AS message_created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_reviews r LEFT JOIN pms_rnd_intake.demand_review_conversations c ON c.review_id = r.id WHERE r.review_type = %s ORDER BY r.created_at ASC, c.created_at ASC',
  'fetch'
);

-- FETCH_REVIEWS_WITH_CONVERSATIONS_BY_REQUEST_AND_TYPE
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REVIEWS_WITH_CONVERSATIONS_BY_REQUEST_AND_TYPE',
  'SELECT r.id AS review_id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at AS review_created_at, r.updated_at AS review_updated_at, c.id AS conversation_id, c.from_user_id, c.from_name, c.role AS conversation_role, c.remarks, c.created_at AS message_created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_reviews r LEFT JOIN pms_rnd_intake.demand_review_conversations c ON c.review_id = r.id WHERE r.request_id = %s AND r.review_type = %s ORDER BY r.created_at ASC, c.created_at ASC',
  'fetch'
);

-- FIND_EXISTING_REVIEW
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FIND_EXISTING_REVIEW',
  'SELECT id, decision FROM pms_rnd_intake.demand_reviews WHERE request_id = %s AND review_type = %s AND reviewer_id = %s',
  'fetch'
);


-- =============================================================================
-- 2.5 INTAKE ROUTE QUERIES
-- =============================================================================

-- FETCH_ALL_INTAKE_REQUEST
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_ALL_INTAKE_REQUEST',
  'SELECT * FROM pms_rnd_intake.demand_requests ORDER BY created_at DESC',
  'fetch'
);

-- FETCH_MY_INTAKE_REQUEST_BY_DOMAIN
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_MY_INTAKE_REQUEST_BY_DOMAIN',
  'SELECT * FROM pms_rnd_intake.demand_requests WHERE domain = %s ORDER BY created_at DESC',
  'fetch'
);

-- FETCH_REQUEST_BY_USER_DOMAIN
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REQUEST_BY_USER_DOMAIN',
  'SELECT * FROM pms_rnd_intake.demand_requests WHERE requestor_wwid = %s ORDER BY created_at DESC',
  'fetch'
);

-- FETCH_INTAKE_BY_ID
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_INTAKE_BY_ID',
  'SELECT * FROM pms_rnd_intake.demand_requests WHERE id = %s',
  'fetch'
);


-- =============================================================================
-- 2.6 DEMAND REQUEST ATTACHMENTS QUERIES
-- =============================================================================

-- FETCH_ATTACHMENTS_BY_REQUEST
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_ATTACHMENTS_BY_REQUEST',
  'SELECT id, request_id, original_name, stored_name, file_path, file_size, mime_type, uploaded_at FROM pms_rnd_intake.demand_request_attachments WHERE request_id = %s ORDER BY uploaded_at ASC',
  'fetch'
);


-- =============================================================================
-- 3. REPORTING / AGGREGATE QUERIES
-- =============================================================================

-- COUNT_REQUESTS_BY_STATUS
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'COUNT_REQUESTS_BY_STATUS',
  'SELECT status, COUNT(*) AS total FROM pms_rnd_intake.demand_requests GROUP BY status ORDER BY total DESC',
  'fetch'
);

-- COUNT_REQUESTS_BY_DOMAIN
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'COUNT_REQUESTS_BY_DOMAIN',
  'SELECT domain, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' GROUP BY domain ORDER BY total DESC',
  'fetch'
);

-- COUNT_REQUESTS_BY_PRIORITY
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'COUNT_REQUESTS_BY_PRIORITY',
  'SELECT priority_level, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' GROUP BY priority_level',
  'fetch'
);

-- FETCH_REVIEW_SUMMARY_FOR_REQUEST
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'FETCH_REVIEW_SUMMARY_FOR_REQUEST',
  'SELECT r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.updated_at, (SELECT COUNT(*) FROM pms_rnd_intake.demand_review_conversations c WHERE c.review_id = r.id) AS message_count FROM pms_rnd_intake.demand_reviews r WHERE r.request_id = %s ORDER BY r.review_type, r.reviewer_name',
  'fetch'
);
