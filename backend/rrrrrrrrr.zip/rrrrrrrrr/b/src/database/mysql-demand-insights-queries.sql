-- =============================================================================
-- PM-RND Demand Insights - Aggregate Queries for Charts / Analytics
-- =============================================================================
-- These queries power the Demand Insights dashboard.
-- They are registered as custom_queries and consumed via customRetrieve.
-- =============================================================================


-- COUNT_REQUESTS_BY_TYPE
-- Groups all non-draft requests by type_of_request
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'COUNT_REQUESTS_BY_TYPE',
  'SELECT COALESCE(type_of_request, ''Unspecified'') AS type_of_request, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' GROUP BY type_of_request ORDER BY total DESC',
  'fetch'
);

-- COUNT_REQUESTS_BY_DOMAIN_AND_STATUS
-- Cross-tab: domain vs status for stacked / grouped bar chart
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'COUNT_REQUESTS_BY_DOMAIN_AND_STATUS',
  'SELECT COALESCE(domain, ''Unspecified'') AS domain, status, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' GROUP BY domain, status ORDER BY domain, status',
  'fetch'
);

-- COUNT_REQUESTS_BY_MONTH
-- Requests grouped by calendar month (last 12 months window)
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'COUNT_REQUESTS_BY_MONTH',
  'SELECT DATE_FORMAT(created_at, ''%Y-%m'') AS month, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) GROUP BY month ORDER BY month ASC',
  'fetch'
);

-- BUDGET_BY_DOMAIN
-- Total estimated budget grouped by domain
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'BUDGET_BY_DOMAIN',
  'SELECT COALESCE(domain, ''Unspecified'') AS domain, SUM(COALESCE(estimated_budget_usd, 0)) AS total_budget FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' GROUP BY domain ORDER BY total_budget DESC',
  'fetch'
);

-- COUNT_REQUESTS_BY_PRIORITY_AND_DOMAIN
-- Cross-tab: priority vs domain for grouped bar chart
INSERT INTO custom_queries (query_name, query, type) VALUES (
  'COUNT_REQUESTS_BY_PRIORITY_AND_DOMAIN',
  'SELECT COALESCE(priority_level, ''Unspecified'') AS priority_level, COALESCE(domain, ''Unspecified'') AS domain, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != ''draft'' GROUP BY priority_level, domain ORDER BY priority_level, domain',
  'fetch'
);
