const fetch = require('node-fetch');
const LOGGING_URL = process.env.LOG_SERVICE_URL || "http://34.86.222.121:8480/log";
const esc = encodeURIComponent;
const componenet_name = "Safety Topics-UI";

//async method to call api using GET methods and return the response
async function GetMethod(url, params, correlationID = "", userid = "", username = "") {
    console.log("Get Method URL==>  ", url, "  Params", params);
    if (params) {
        const query = Object.keys(params).map(k => `${esc(k)}=${esc(params[k])}`).join('&');
        url += "?" + query;
    }

    const headers = {
        'x-user-name': username,
        'x-user-id': userid,
        'x-correlation-id': correlationID
    };
    return await fetch(url, { method: 'GET', headers: headers })
        .then(data => {
            return data.json()
        }).then(data => {
            PostLog(
                "info",
                JSON.stringify({
                    correlationID: correlationID, userid: userid,
                    url: url, message: data
                }));
            return data;
        }).catch(function (error) {
            return { 'request failed': error };
        });

}

//async method to call api using POST methods and return the response
async function PostMethod(url, params, correlationID, headers) {


    let response_object = await fetch(url, {
        method: 'post',
        body: params,
        headers: headers
    }).catch((err) => {
        if (err.code == "ETIMEDOUT") {
            return { ok: false, message: err.message }
        }
    });

    if (!response_object) {
        return { status: false, "message": "Upload failed try again!" }
    }
    else {
        if (response_object.ok) {
            let data = await response_object.json();
            PostLog(
                "info", JSON.stringify({

                    "CorrelationID": correlationID,
                    "requestObject": params,
                    "URL": url,
                    "message": data
                }), componenet_name);
            return data;
        } else {
            let jsonError;
            let internalerror = null;
            if (response_object.status != undefined && (response_object.status == 400 || response_object.status == 500)) {
                let contentType = response_object.headers.get("content-type");
                if (contentType && contentType.indexOf("application/json") !== -1) {
                    let data = await response_object.json();
                    jsonError = { status: false, "message": data.message, statuscode: response_object.status }
                } else {
                    let data = await response_object.text();
                    jsonError = { status: false, "message": "API Failed to execute" }
                    internalerror = { status: false, "message": data }
                }

            } else if (response_object.status == 404) {
                jsonError = { status: false, "message": "API Failed to execute" }
                internalerror = { status: false, "message": `404 error came for URL ${url}` }
            }
            else {
                jsonError = { status: false, "message": "API Failed to execute" }
                internalerror = { status: false, "message": response_object.message }
            }

            PostLog("error", JSON.stringify({

                "CorrelationID": correlationID,
                "requestObject": params,
                "URL": url,
                "message": internalerror ? internalerror : jsonError
            }), componenet_name);


            return jsonError;

        }
    }

}


async function PostJSON(url, params, correlationID, methodtype = 'post', userid = "", username = "") {
    let response_object = await fetch(url, {
        method: methodtype,
        body: JSON.stringify(params),
        headers: {
            'Content-Type': 'application/json',
            "x-correlation-id": correlationID,
            'x-user-name': username,
            'x-user-id': userid,
            'uuid': correlationID
        }
    }).catch((err) => {
        if (err.code == "ETIMEDOUT") {
            return { ok: false, message: err.message }
        }
    });

    if (!response_object) {
        return { status: false, "message": "Something wrong, try again!" }
    }
    else {
        if (response_object.ok) {
            let data = await response_object.json();
            PostLog(
                "info", JSON.stringify({
                    "CorrelationID": correlationID,
                    "requestObject": params,
                    "URL": url,
                    "message": data
                }), componenet_name);
            return data;
        } else {
            let jsonError;
            let internalerror = null;
            if (response_object.status != undefined && (response_object.status == 400 || response_object.status == 500)) {
                let contentType = response_object.headers.get("content-type");
                if (contentType && contentType.indexOf("application/json") !== -1) {
                    let data = await response_object.json();
                    jsonError = { status: false, "message": JSON.stringify(response_object) };// data.message, statuscode: response_object.status }
                } else {
                    let data = await response_object.text();
                    jsonError = { status: false, "message": "API Failed to execute" }
                    internalerror = { status: false, "message": JSON.stringify(response_object) };// data }
                }

            } else if (response_object.status == 404) {
                jsonError = { status: false, "message": "API Failed to execute" }
                internalerror = { status: false, "message": `404 error came for URL ${url}` }
            }
            else {
                jsonError = { status: false, "message": "API Failed to execute" }
                internalerror = { status: false, "message": JSON.stringify(response_object) };// response_object.message }
            }
            PostLog("error", JSON.stringify({

                "CorrelationID": correlationID,
                "requestObject": params,
                "URL": url,
                "message": internalerror ? internalerror : jsonError
            }), componenet_name);

            return jsonError;
        }
    }
}

async function PostLog(type, message, componenet_name = "") {
    componenet_name = componenet_name.length == 0 ? "FRONEND_API" : componenet_name;
    const req_obj = {
        app_name: "Safety Topics",
        component: componenet_name,
        log_type: type,
        error_log: message
    }

    fetch(LOGGING_URL, {
        method: 'post',
        body: JSON.stringify(req_obj),
        headers: { 'Content-Type': 'application/json' }
    }).then(res => {
        if (res.ok) return res.json();
        return Promise.reject(res);
    }).catch(error => {
        let message = "";
        if (error.code == "ETIMEDOUT") {
            console.log(error.message);
        }
        else {
            console.log(error.message)
            console.log(`error came from ${error.url}`);
        }
    });;
}


async function GetAccessToke(url, coookiedata) {
    return await fetch(url, {
        method: 'post',
        headers: { Cookie: `refreshtoken=${coookiedata.refreshtoken};token=${coookiedata.token}` }
    }).then(res => {
        if (res.ok) return res.json();
        return Promise.reject(res);
    }).then(tokendata => {
        return tokendata;
    }).catch(error => {
        console.log(`error came for ${error.url} with Status ${error.status} and StatusText as ${error.statusText}`);
        return {
            auth: false,
            message: "Failed to Authentication!"
        }
    });;

}

module.exports = { PostJSON, GetAccessToke, PostMethod, PostLog, GetMethod }