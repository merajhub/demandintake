
require(`../config/appconfig`);
const { ConfidentialClientApplication } = require('@azure/msal-node');
require('dotenv').config();

console.log("-----------------------------------------------",global.config);
if (!global.config.CLIENT_ID || !global.config.CLIENT_SECRET || !global.config.TENANT_ID) {
    throw new Error("Missing required environment variables for Entra SSO configuration.");
}
  
const msalConfig = {
  auth: {
    clientId: global.config.CLIENT_ID,
    authority: `https://login.microsoftonline.com/${global.config.TENANT_ID}`,
    clientSecret: global.config.CLIENT_SECRET,
  }
};
const cca = new ConfidentialClientApplication(msalConfig);

module.exports = { cca };