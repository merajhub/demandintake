
require(`../config/appconfig`);

async function ssologin(req, res) {
  const { cca } = require("./authconfig");
  // try {
  //   const authCodeUrlParams = {
  //     scopes: ["user.read"],
  //     redirectUri: global.config.REDIRECT_URI
  //     // prompt: "login" 
  //   };
  //   cca.getAuthCodeUrl(authCodeUrlParams).then(loginUrl => {

  //     res.redirect(loginUrl);
  //   });
  // } catch (error) {
  //   res.status(500).send(error);

  // }

  try {

    const params = new URLSearchParams({
      client_id: global.config.CLIENT_ID,
      response_type: 'id_token',
      response_mode: 'form_post',      // or 'fragment' or 'query'
      scope: 'openid profile email',         // 'profile' helps with name-related claims
      redirect_uri: global.config.REDIRECT_URI,
      nonce: crypto.randomUUID(),      // store+verify it to prevent replay
      state: crypto.randomUUID(),      // store+verify it to prevent CSRF
    });
    res.redirect(`https://login.microsoftonline.com/${global.config.TENANT_ID}/oauth2/v2.0/authorize?${params}`);
  } catch (error) {
    res.status(500).send(error);
  }


}

async function ssologinRelay(req, res) {
  const { cca } = require("./authconfig");
  try {
    const relayState = req.query.RelayState || '/';
    const authCodeUrlParams = {
      scopes: ["user.read"],
      redirectUri: global.config.REDIRECT_URI,
      state: relayState

    };
    cca.getAuthCodeUrl(authCodeUrlParams).then(loginUrl => {
      res.redirect(loginUrl);
    });
  } catch (error) {
    res.status(500).send(error);
  }
}

async function getSSOUser(accessToken) {
  let userDetails = null;
  try {
    const response = await fetch("https://graph.microsoft.com/v1.0/me?$select=displayName,givenName,surname,mail,employeeId,onPremisesImmutableId", {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Accept": "application/json"
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    userDetails = await response.json(); // Store user details in variable
  } catch (error) {
    console.error("Error fetching user details:", error);
  }

  if (userDetails) {

    let user = userDetails

    let userObj = {
      user_wwid: user.employeeId,
      firstname: user.givenName ? user.givenName : '',
      lastname: user.surname ? user.surname : '',
      emailid: user.mail ? user.mail : '',
      businessunit: user.jnjBusinessUnitDesc && user.jnjBusinessUnitDesc.length ? user.jnjBusinessUnitDesc[0] : '',
    }
    return userObj;
  }
}
module.exports = { ssologin, getSSOUser, ssologinRelay }