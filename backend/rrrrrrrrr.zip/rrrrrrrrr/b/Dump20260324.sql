-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: pms_rnd_intake
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `custom_queries`
--

DROP TABLE IF EXISTS `custom_queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_queries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `query_name` varchar(150) NOT NULL,
  `query` text NOT NULL,
  `type` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_queries`
--

LOCK TABLES `custom_queries` WRITE;
/*!40000 ALTER TABLE `custom_queries` DISABLE KEYS */;
INSERT INTO `custom_queries` VALUES (1,'FETCH_ALL_USERS','SELECT id, name, email, role,domain, created_at, updated_at FROM pms_rnd_intake.users ORDER BY name ASC','fetch'),(2,'FETCH_USER_BY_ID','SELECT id, name, email, role, domain, created_at, updated_at FROM pms_rnd_intake.users WHERE id = %s','fetch'),(3,'FETCH_REQUESTS_BY_USER','SELECT * FROM pms_rnd_intake.demand_requests WHERE created_by = %s ORDER BY updated_at DESC','fetch'),(4,'FETCH_ALL_NON_DRAFT_REQUESTS','SELECT * FROM pms_rnd_intake.demand_requests WHERE status != \'draft\' ORDER BY updated_at DESC','fetch'),(5,'FETCH_REQUEST_BY_ID','SELECT * FROM pms_rnd_intake.demand_requests WHERE id = %s','fetch'),(6,'FETCH_COMMENTS_BY_REQUEST','SELECT id, request_id, user_id, user_name, user_role, text, created_at FROM pms_rnd_intake.demand_comments WHERE request_id = %s ORDER BY created_at ASC','fetch'),(7,'FETCH_ALL_COMMENTS','SELECT id, request_id, user_id, user_name, user_role, text, created_at FROM pms_rnd_intake.demand_comments ORDER BY created_at ASC','fetch'),(8,'FETCH_ALL_REVIEWS','SELECT r.id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at, r.updated_at FROM pms_rnd_intake.demand_reviews r ORDER BY r.created_at ASC','fetch'),(9,'FETCH_REVIEWS_BY_REQUEST','SELECT r.id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at, r.updated_at FROM pms_rnd_intake.demand_reviews r WHERE r.request_id = %s ORDER BY r.created_at ASC','fetch'),(10,'FETCH_REVIEWS_BY_TYPE','SELECT r.id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at, r.updated_at FROM pms_rnd_intake.demand_reviews r WHERE r.review_type = %s ORDER BY r.created_at ASC','fetch'),(11,'FETCH_REVIEWS_BY_REQUEST_AND_TYPE','SELECT r.id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at, r.updated_at FROM pms_rnd_intake.demand_reviews r WHERE r.request_id = %s AND r.review_type = %s ORDER BY r.created_at ASC','fetch'),(12,'FETCH_REVIEW_CONVERSATIONS','SELECT c.id, c.review_id, c.from_user_id, c.from_name, c.role, c.remarks, c.created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_review_conversations c WHERE c.review_id = %s ORDER BY c.created_at ASC','fetch'),(13,'FETCH_ALL_REVIEWS_WITH_CONVERSATIONS','SELECT r.id AS review_id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at AS review_created_at, r.updated_at AS review_updated_at, c.id AS conversation_id, c.from_user_id, c.from_name, c.role AS conversation_role, c.remarks, c.created_at AS message_created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_reviews r LEFT JOIN pms_rnd_intake.demand_review_conversations c ON c.review_id = r.id ORDER BY r.created_at ASC, c.created_at ASC','fetch'),(14,'FETCH_REVIEWS_WITH_CONVERSATIONS_BY_REQUEST','SELECT r.id AS review_id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at AS review_created_at, r.updated_at AS review_updated_at, c.id AS conversation_id, c.from_user_id, c.from_name, c.role AS conversation_role, c.remarks, c.created_at AS message_created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_reviews r LEFT JOIN pms_rnd_intake.demand_review_conversations c ON c.review_id = r.id WHERE r.request_id = %s ORDER BY r.created_at ASC, c.created_at ASC','fetch'),(15,'FETCH_REVIEWS_WITH_CONVERSATIONS_BY_TYPE','SELECT r.id AS review_id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at AS review_created_at, r.updated_at AS review_updated_at, c.id AS conversation_id, c.from_user_id, c.from_name, c.role AS conversation_role, c.remarks, c.created_at AS message_created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_reviews r LEFT JOIN pms_rnd_intake.demand_review_conversations c ON c.review_id = r.id WHERE r.review_type = %s ORDER BY r.created_at ASC, c.created_at ASC','fetch'),(16,'FETCH_REVIEWS_WITH_CONVERSATIONS_BY_REQUEST_AND_TYPE','SELECT r.id AS review_id, r.request_id, r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.created_at AS review_created_at, r.updated_at AS review_updated_at, c.id AS conversation_id, c.from_user_id, c.from_name, c.role AS conversation_role, c.remarks, c.created_at AS message_created_at, c.attachment_original_name, c.attachment_stored_name, c.attachment_size, c.attachment_mime_type FROM pms_rnd_intake.demand_reviews r LEFT JOIN pms_rnd_intake.demand_review_conversations c ON c.review_id = r.id WHERE r.request_id = %s AND r.review_type = %s ORDER BY r.created_at ASC, c.created_at ASC','fetch'),(17,'FIND_EXISTING_REVIEW','SELECT id, decision FROM pms_rnd_intake.demand_reviews WHERE request_id = %s AND review_type = %s AND reviewer_id = %s','fetch'),(18,'FETCH_ALL_INTAKE_REQUEST','SELECT * FROM pms_rnd_intake.demand_requests ORDER BY created_at DESC','fetch'),(19,'FETCH_MY_INTAKE_REQUEST_BY_DOMAIN','SELECT * FROM pms_rnd_intake.demand_requests WHERE domain = %s ORDER BY created_at DESC','fetch'),(20,'FETCH_REQUEST_BY_USER_DOMAIN','SELECT * FROM pms_rnd_intake.demand_requests WHERE requestor_wwid = %s ORDER BY created_at DESC','fetch'),(21,'FETCH_INTAKE_BY_ID','SELECT * FROM pms_rnd_intake.demand_requests WHERE id = %s','fetch'),(22,'FETCH_ATTACHMENTS_BY_REQUEST','SELECT id, request_id, original_name, stored_name, file_path, file_size, mime_type, uploaded_at FROM pms_rnd_intake.demand_request_attachments WHERE request_id = %s ORDER BY uploaded_at ASC','fetch'),(23,'COUNT_REQUESTS_BY_STATUS','SELECT status, COUNT(*) AS total FROM pms_rnd_intake.demand_requests GROUP BY status ORDER BY total DESC','fetch'),(24,'COUNT_REQUESTS_BY_DOMAIN','SELECT domain, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != \'draft\' GROUP BY domain ORDER BY total DESC','fetch'),(25,'COUNT_REQUESTS_BY_PRIORITY','SELECT priority_level, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != \'draft\' GROUP BY priority_level','fetch'),(26,'FETCH_REVIEW_SUMMARY_FOR_REQUEST','SELECT r.review_type, r.reviewer_id, r.reviewer_name, r.decision, r.updated_at, (SELECT COUNT(*) FROM pms_rnd_intake.demand_review_conversations c WHERE c.review_id = r.id) AS message_count FROM pms_rnd_intake.demand_reviews r WHERE r.request_id = %s ORDER BY r.review_type, r.reviewer_name','fetch'),(27,'UPDATE_REQUEST_STATUS','UPDATE pms_rnd_intake.demand_requests  SET status     = %s, stage =%s ,  updated_at = NOW()  WHERE id = %s','update'),(28,'UPDATE_REVIEW_DECISION','UPDATE pms_rnd_intake.demand_reviews\nSET\n    decision   = %s,\n    updated_at = NOW()\nWHERE id = %s;','update'),(29,'COUNT_REQUESTS_BY_TYPE','SELECT COALESCE(type_of_request, \'Unspecified\') AS type_of_request, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != \'draft\' GROUP BY type_of_request ORDER BY total DESC','fetch'),(30,'COUNT_REQUESTS_BY_DOMAIN_AND_STATUS','SELECT COALESCE(domain, \'Unspecified\') AS domain, status, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != \'draft\' GROUP BY domain, status ORDER BY domain, status','fetch'),(31,'COUNT_REQUESTS_BY_MONTH','SELECT DATE_FORMAT(created_at, \'%Y-%m\') AS month, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != \'draft\' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) GROUP BY month ORDER BY month ASC','fetch'),(32,'BUDGET_BY_DOMAIN','SELECT COALESCE(domain, \'Unspecified\') AS domain, SUM(COALESCE(estimated_budget_usd, 0)) AS total_budget FROM pms_rnd_intake.demand_requests WHERE status != \'draft\' GROUP BY domain ORDER BY total_budget DESC','fetch'),(33,'COUNT_REQUESTS_BY_PRIORITY_AND_DOMAIN','SELECT COALESCE(priority_level, \'Unspecified\') AS priority_level, COALESCE(domain, \'Unspecified\') AS domain, COUNT(*) AS total FROM pms_rnd_intake.demand_requests WHERE status != \'draft\' GROUP BY priority_level, domain ORDER BY priority_level, domain','fetch'),(34,'GET_CHART_DRILL_DOWN_DATA','SELECT id, project_title, domain, status, priority_level, type_of_request, estimated_budget_usd, requestor_name, department, created_at \nFROM pms_rnd_intake.demand_requests WHERE {where_clause} ORDER BY created_at DESC','fetch'),(35,'FETCH_APPROVED_DEMAND_REQUESTS','SELECT\n    dr.id                       AS request_id,\n    dr.project_title,\n    dr.domain,\n    dr.priority_level,\n    dr.type_of_request,\n    dr.requestor_name,\n    dr.pm_scrum_master,\n    dr.estimated_start_date,\n    dr.estimated_completion_date,\n    dr.date_of_submission,\n    dt.id                       AS tracking_id,\n    dt.scope,\n    dt.schedule,\n    dt.resources,\n    dt.risks,\n    dt.scope_comment,\n    dt.schedule_comment,\n    dt.resources_comment,\n    dt.risks_comment,\n    dt.release_status,\n    dt.dev_planned_date,\n    dt.qa_planned_date,\n    dt.prod_planned_date,\n    dt.dev_actual_date,\n    dt.qa_actual_date,\n    dt.prod_actual_date,\n    dt.comments,\n    dt.version\nFROM pms_rnd_intake.demand_requests dr\nLEFT JOIN pms_rnd_intake.demand_tracking dt ON dt.request_id = dr.id\nWHERE dr.status = \'approved\'\nORDER BY dr.updated_at DESC;','fetch'),(36,'FETCH_DEMAND_TRACKING_BY_REQUEST_ID','SELECT\n     dr.id                       AS request_id,\n     dr.project_title,\n     dr.domain,\n     dr.priority_level,\n     dr.type_of_request,\n     dr.requestor_name,\n     dr.pm_scrum_master,\n     dr.estimated_start_date,\n     dr.estimated_completion_date,\n     dr.date_of_submission,\n     dt.id                       AS tracking_id,\n     dt.scope,\n     dt.schedule,\n     dt.resources,\n     dt.risks,\n     dt.scope_comment,\n     dt.schedule_comment,\n     dt.resources_comment,\n     dt.risks_comment,\n     dt.release_status,\n     dt.dev_planned_date,\n     dt.qa_planned_date,\n     dt.prod_planned_date,\n     dt.dev_actual_date,\n     dt.qa_actual_date,\n     dt.prod_actual_date,\n     dt.comments,\n     dt.version\n FROM pms_rnd_intake.demand_requests dr\n LEFT JOIN pms_rnd_intake.demand_tracking dt ON dt.request_id = dr.id\n WHERE dr.id = %s AND dr.status = \'approved\';','fetch'),(37,'FETCH_DEMAND_TRACKING_AUDIT','SELECT\n     dta.*,\n     dta.updated_by_name AS user_name\n FROM pms_rnd_intake.demand_tracking_audit dta\n WHERE dta.request_id = %s\n ORDER BY dta.created_at DESC;','fetch'),(38,'FETCH_DEMAND_TRACKING_SUMMARY_STATUS','SELECT dt.release_status, COUNT(*) AS total\nFROM pms_rnd_intake.demand_tracking dt\nGROUP BY dt.release_status;','fetch'),(39,'FETCH_DEMAND_TRACKING_SUMMARY_DOMAIN','SELECT dt.domain, COUNT(*) AS total\nFROM pms_rnd_intake.demand_tracking dt\nGROUP BY dt.domain;','fetch'),(40,'FETCH_DEMAND_TRACKING_SUMMARY_TIMELINE','SELECT DATE_FORMAT(dt.dev_planned_date, \'%Y-%m\') AS month, COUNT(*) AS total\nFROM pms_rnd_intake.demand_tracking dt\nWHERE dt.dev_planned_date IS NOT NULL\nGROUP BY month\nORDER BY month;','fetch'),(42,'FETCH_NON_DRAFT_REQUESTS_BY_DOMAIN','SELECT * FROM demand_requests WHERE status != \'draft\' AND domain = %s ORDER BY created_at DESC','fetch'),(43,'FETCH_DEMAND_TRACKING_SUMMARY','SELECT dt.*, dr.project_title, dr.domain, dr.priority_level, dr.status as request_status FROM demand_tracking dt JOIN demand_requests dr ON dt.request_id = dr.id ORDER BY dt.updated_at DESC','fetch');
/*!40000 ALTER TABLE `custom_queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demand_comments`
--

DROP TABLE IF EXISTS `demand_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demand_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` int NOT NULL,
  `user_id` int NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `user_role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_comments_request_id` (`request_id`),
  KEY `idx_comments_user_id` (`user_id`),
  KEY `idx_comments_created_at` (`created_at`),
  CONSTRAINT `fk_comments_request` FOREIGN KEY (`request_id`) REFERENCES `demand_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demand_comments`
--

LOCK TABLES `demand_comments` WRITE;
/*!40000 ALTER TABLE `demand_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `demand_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demand_request_attachments`
--

DROP TABLE IF EXISTS `demand_request_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demand_request_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` int NOT NULL,
  `original_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `stored_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint DEFAULT NULL,
  `mime_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_req_attachments_request_id` (`request_id`),
  CONSTRAINT `fk_req_attachments_request` FOREIGN KEY (`request_id`) REFERENCES `demand_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demand_request_attachments`
--

LOCK TABLES `demand_request_attachments` WRITE;
/*!40000 ALTER TABLE `demand_request_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `demand_request_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demand_requests`
--

DROP TABLE IF EXISTS `demand_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demand_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `created_by_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `stage` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitter_remarks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_title` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimated_budget_usd` decimal(15,2) DEFAULT NULL,
  `type_of_request` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority_level` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_submission` datetime DEFAULT NULL,
  `estimated_start_date` date DEFAULT NULL,
  `estimated_completion_date` date DEFAULT NULL,
  `requestor_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_manager` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_users` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `platform` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `technology_preference` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `project_goals` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `business_problem` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `expected_outcome` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `resource_requirements` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dependencies` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `compliance_requirements` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `stakeholders` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `risks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `review_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `additional_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `approval_signoff` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestor_wwid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestor_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pm_scrum_master` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_requests_status` (`status`),
  KEY `idx_requests_created_by` (`created_by`),
  KEY `idx_requests_domain` (`domain`),
  KEY `idx_requests_priority` (`priority_level`),
  KEY `idx_requests_submission_date` (`date_of_submission`),
  KEY `idx_requests_requestor_wwid` (`requestor_wwid`),
  CONSTRAINT `fk_requests_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demand_requests`
--

LOCK TABLES `demand_requests` WRITE;
/*!40000 ALTER TABLE `demand_requests` DISABLE KEYS */;
INSERT INTO `demand_requests` VALUES (1,1,'Alice Johnson','approved','completed',NULL,'dsadsa','Safety',43543.00,'New Development','Low','2026-03-24 00:00:00','2026-03-30','2026-03-31','dada','dsa','dsa@aa.com','4324','432','432','Web','Angular','fsdff','fds','fsd','fds','fds','fsd','fds','fsd','ds','fds','sd',NULL,NULL,NULL,NULL,'2026-03-24 01:09:46','2026-03-24 01:21:29'),(2,8,'Meraj Ahmad','committee_review','committee',NULL,'Regulatory','Regulatory',332.00,'New Development','High','2026-03-24 00:00:00','2026-03-31','2026-04-29','Meraj ','Clinical','ahmadmeraj@gmail.com','32213','fffdfss','3213','Mobile','Angular','dsdsf','fdsf','fds','fds','4','fsd','fsdf','fdsf','fsd','fsd','fds',NULL,NULL,NULL,NULL,'2026-03-24 06:46:26','2026-03-24 07:26:10'),(3,8,'Meraj Ahmad','submitted','scrub',NULL,'Safety','Safety',100000.00,'New Development','High','2026-03-24 00:00:00','2026-03-31','2026-04-15','Meraj','Safety','a@a.com','6876876','Meraj','sadasad','Web','Angular','dsadad','das','dsa','dsa','dsa','dsa','dsa','dsa','ada','das','da',NULL,NULL,NULL,NULL,'2026-03-24 06:53:49','2026-03-24 06:53:49'),(4,8,'Meraj Ahmad','clarification_requested',NULL,NULL,'Clinical','Clinical',35353.00,'New Development','Low','2026-03-24 00:00:00','2026-03-31','2026-04-15','a','a','ahmadmeraj@gmail.com','22','dsa','dsa','Web','Angular','dsad','dsa','dsa','dsa','dsa','d','dsa','dsa','dsa','dsa','dsa',NULL,NULL,NULL,NULL,'2026-03-24 07:17:42','2026-03-24 07:18:13');
/*!40000 ALTER TABLE `demand_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demand_review_conversations`
--

DROP TABLE IF EXISTS `demand_review_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demand_review_conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `review_id` int NOT NULL,
  `from_user_id` int NOT NULL,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `attachment_original_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_stored_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_size` bigint DEFAULT NULL,
  `attachment_mime_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_conversation_review_id` (`review_id`),
  KEY `idx_conversation_created_at` (`created_at`),
  CONSTRAINT `fk_conversation_review` FOREIGN KEY (`review_id`) REFERENCES `demand_reviews` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demand_review_conversations`
--

LOCK TABLES `demand_review_conversations` WRITE;
/*!40000 ALTER TABLE `demand_review_conversations` DISABLE KEYS */;
INSERT INTO `demand_review_conversations` VALUES (1,1,2,'Bob Smith','Scrub_member','approved','2026-03-24 01:21:13',NULL,NULL,NULL,NULL),(2,2,5,'Diana Prince','Committee_member','approved','2026-03-24 01:21:29',NULL,NULL,NULL,NULL),(3,3,4,'David Lee','Scrub_member','sadsad','2026-03-24 07:18:13',NULL,NULL,NULL,NULL),(4,4,3,'Charlie Brown','Scrub_member','approved','2026-03-24 07:26:10',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `demand_review_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demand_reviews`
--

DROP TABLE IF EXISTS `demand_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demand_reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` int NOT NULL,
  `review_type` enum('scrub','committee') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewer_id` int NOT NULL,
  `reviewer_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `decision` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_reviews_unique` (`request_id`,`review_type`,`reviewer_id`),
  KEY `idx_reviews_request_id` (`request_id`),
  KEY `idx_reviews_review_type` (`review_type`),
  KEY `idx_reviews_reviewer_id` (`reviewer_id`),
  CONSTRAINT `fk_reviews_request` FOREIGN KEY (`request_id`) REFERENCES `demand_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reviews_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demand_reviews`
--

LOCK TABLES `demand_reviews` WRITE;
/*!40000 ALTER TABLE `demand_reviews` DISABLE KEYS */;
INSERT INTO `demand_reviews` VALUES (1,1,'scrub',2,'Bob Smith','No Questions','2026-03-24 01:21:13','2026-03-24 01:21:13'),(2,1,'committee',5,'Diana Prince','Approved','2026-03-24 01:21:29','2026-03-24 01:21:29'),(3,4,'scrub',4,'David Lee','Needs Clarification','2026-03-24 07:18:13','2026-03-24 07:18:13'),(4,2,'scrub',3,'Charlie Brown','Approved','2026-03-24 07:26:10','2026-03-24 07:26:10');
/*!40000 ALTER TABLE `demand_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demand_tracking`
--

DROP TABLE IF EXISTS `demand_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demand_tracking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` int NOT NULL,
  `project_title` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority_level` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pm_scrum_master` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scope` tinyint DEFAULT NULL,
  `schedule` tinyint DEFAULT NULL,
  `resources` tinyint DEFAULT NULL,
  `risks` tinyint DEFAULT NULL,
  `scope_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `schedule_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `resources_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `risks_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `release_status` tinyint DEFAULT '1',
  `dev_planned_date` date DEFAULT NULL,
  `qa_planned_date` date DEFAULT NULL,
  `prod_planned_date` date DEFAULT NULL,
  `dev_actual_date` date DEFAULT NULL,
  `qa_actual_date` date DEFAULT NULL,
  `prod_actual_date` date DEFAULT NULL,
  `comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `version` int DEFAULT '1',
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dtracking_request_id` (`request_id`),
  KEY `idx_dtracking_domain` (`domain`),
  KEY `idx_dtracking_release_status` (`release_status`),
  CONSTRAINT `fk_dtracking_request` FOREIGN KEY (`request_id`) REFERENCES `demand_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demand_tracking`
--

LOCK TABLES `demand_tracking` WRITE;
/*!40000 ALTER TABLE `demand_tracking` DISABLE KEYS */;
INSERT INTO `demand_tracking` VALUES (1,1,'dsadsa','Safety','Low',NULL,1,2,3,3,'aaaaa','bbbbb','ddddddddddddddddddd','sdfdssssssssssssssssssssssss',3,'2026-03-24','2026-04-04','2026-04-15','2026-03-24','2026-03-31',NULL,NULL,1,'5','Diana Prince','2026-03-24 01:22:43','2026-03-24 07:19:20');
/*!40000 ALTER TABLE `demand_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demand_tracking_audit`
--

DROP TABLE IF EXISTS `demand_tracking_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demand_tracking_audit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tracking_id` int NOT NULL,
  `request_id` int NOT NULL,
  `scope` tinyint DEFAULT NULL,
  `schedule` tinyint DEFAULT NULL,
  `resources` tinyint DEFAULT NULL,
  `risks` tinyint DEFAULT NULL,
  `scope_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `schedule_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `resources_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `risks_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `release_status` tinyint DEFAULT NULL,
  `dev_planned_date` date DEFAULT NULL,
  `qa_planned_date` date DEFAULT NULL,
  `prod_planned_date` date DEFAULT NULL,
  `dev_actual_date` date DEFAULT NULL,
  `qa_actual_date` date DEFAULT NULL,
  `prod_actual_date` date DEFAULT NULL,
  `comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `version` int DEFAULT NULL,
  `updated_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dtracking_audit_tracking_id` (`tracking_id`),
  KEY `idx_dtracking_audit_request_id` (`request_id`),
  KEY `idx_dtracking_audit_created_at` (`created_at`),
  CONSTRAINT `fk_dtracking_audit_tracking` FOREIGN KEY (`tracking_id`) REFERENCES `demand_tracking` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demand_tracking_audit`
--

LOCK TABLES `demand_tracking_audit` WRITE;
/*!40000 ALTER TABLE `demand_tracking_audit` DISABLE KEYS */;
INSERT INTO `demand_tracking_audit` VALUES (1,1,1,1,2,3,3,'aaaaa','bbbbb','ddddddddddddddddddd','sdfdssssssssssssssssssssssss',2,'2026-03-24','2026-04-04','2026-04-15','2026-03-24',NULL,NULL,NULL,2,NULL,NULL,'2026-03-24 01:09:05'),(2,1,1,1,2,3,3,'aaaaa','bbbbb','ddddddddddddddddddd','sdfdssssssssssssssssssssssss',3,'2026-03-24','2026-04-04','2026-04-15','2026-03-24',NULL,NULL,NULL,2,NULL,NULL,'2026-03-24 01:09:18'),(3,1,1,1,2,3,3,'aaaaa','bbbbb','ddddddddddddddddddd','sdfdssssssssssssssssssssssss',3,'2026-03-24','2026-04-04','2026-04-15','2026-03-24','2026-03-31',NULL,NULL,2,'8','Meraj Ahmad','2026-03-24 01:49:20');
/*!40000 ALTER TABLE `demand_tracking_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wwid` varchar(100) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` enum('User','Scrub_member','Committee_member') NOT NULL,
  `domain` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_wwid` (`wwid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'user_req_01','Alice Johnson','alice@jnj.com','User',NULL,'2026-03-24 01:08:25','2026-03-24 01:08:25'),(2,'scrub_01','Bob Smith','bob@jnj.com','Scrub_member','Safety','2026-03-24 01:08:25','2026-03-24 01:08:25'),(3,'scrub_02','Charlie Brown','charlie@jnj.com','Scrub_member','Regulatory','2026-03-24 01:08:25','2026-03-24 01:08:25'),(4,'scrub_03','David Lee','david@jnj.com','Scrub_member','Clinical','2026-03-24 01:08:25','2026-03-24 01:08:25'),(5,'committee_01','Diana Prince','diana@jnj.com','Committee_member','Safety','2026-03-24 01:08:25','2026-03-24 01:08:25'),(6,'committee_02','Edward Norton','edward@jnj.com','Committee_member','Regulatory','2026-03-24 01:08:25','2026-03-24 01:08:25'),(7,'committee_03','Fiona Gallagher','fiona@jnj.com','Committee_member','Clinical','2026-03-24 01:08:25','2026-03-24 01:08:25'),(8,'152307668','Meraj Ahmad','ad@jnj.com','User',NULL,'2026-03-24 01:08:25','2026-03-24 01:08:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-24 14:45:31
