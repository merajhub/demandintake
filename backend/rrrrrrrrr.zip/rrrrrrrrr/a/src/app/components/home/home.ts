import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  selectedFeature: string = 'intake';

  selectFeature(feature: string): void {
    this.selectedFeature = feature;
  }
}
