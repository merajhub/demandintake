import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTracking } from './edit-tracking';

describe('EditTracking', () => {
  let component: EditTracking;
  let fixture: ComponentFixture<EditTracking>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EditTracking]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditTracking);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
