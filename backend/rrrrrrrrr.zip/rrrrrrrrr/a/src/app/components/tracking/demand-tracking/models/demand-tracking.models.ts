/** Tracking record as returned by the API (flat row from JOIN) */
export interface DemandTrackingRecord {
  request_id: number;
  project_title: string;
  domain: string;
  priority_level: string;
  type_of_request: string;
  requestor_name: string;
  pm_scrum_master: string;
  estimated_start_date: string | null;
  estimated_completion_date: string | null;
  date_of_submission: string | null;

  // Tracking fields (may be null if not yet tracked)
  tracking_id: number | null;
  scope: number | null;
  schedule: number | null;
  resources: number | null;
  risks: number | null;
  scope_comment: string | null;
  schedule_comment: string | null;
  resources_comment: string | null;
  risks_comment: string | null;
  release_status: number | null;
  dev_planned_date: string | null;
  qa_planned_date: string | null;
  prod_planned_date: string | null;
  dev_actual_date: string | null;
  qa_actual_date: string | null;
  prod_actual_date: string | null;
  comments: string | null;
  version: number | null;
}

/** Payload to save/update tracking */
export interface DemandTrackingSavePayload {
  requestId: number;
  trackingId?: number | null;
  projectTitle?: string;
  domain?: string;
  priorityLevel?: string;
  pmScrumMaster?: string;
  scope: number | null;
  schedule: number | null;
  resources: number | null;
  risks: number | null;
  scopeComment: string | null;
  scheduleComment: string | null;
  resourcesComment: string | null;
  risksComment: string | null;
  releaseStatus: number;
  devPlannedDate: string | null;
  qaPlannedDate: string | null;
  prodPlannedDate: string | null;
  devActualDate: string | null;
  qaActualDate: string | null;
  prodActualDate: string | null;
  comments: string | null;
  version: number;
  createdBy?: string;
  createdByName?: string;
}

/** Audit record */
export interface DemandTrackingAuditRecord {
  id: number;
  tracking_id: number;
  request_id: number;
  scope: number | null;
  schedule: number | null;
  resources: number | null;
  risks: number | null;
  scope_comment: string | null;
  schedule_comment: string | null;
  resources_comment: string | null;
  risks_comment: string | null;
  release_status: number | null;
  dev_planned_date: string | null;
  qa_planned_date: string | null;
  prod_planned_date: string | null;
  dev_actual_date: string | null;
  qa_actual_date: string | null;
  prod_actual_date: string | null;
  comments: string | null;
  version: number | null;
  user_name: string;
  created_at: string;
}

export const RELEASE_STATUS_OPTIONS = [
  { label: 'Not Started', value: 1 },
  { label: 'In Progress', value: 2 },
  { label: 'Dev Completed', value: 3 },
  { label: 'QA Completed', value: 4 },
  { label: 'Completed', value: 5 },
];

export const RAG_STATUS_OPTIONS = [
  { label: 'Green', value: 1 },
  { label: 'Amber', value: 2 },
  { label: 'Red', value: 3 },
];

export const RELEASE_STATUS_LABELS: Record<number, string> = {
  1: 'Not Started',
  2: 'In Progress',
  3: 'Dev Completed',
  4: 'QA Completed',
  5: 'Completed',
};

export const RAG_STATUS_LABELS: Record<number, string> = {
  1: 'green',
  2: 'amber',
  3: 'red',
};
