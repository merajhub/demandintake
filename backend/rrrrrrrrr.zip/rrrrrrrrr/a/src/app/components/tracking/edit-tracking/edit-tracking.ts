import { ChangeDetectorRef, Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../../services/data-service';
import { ReleaseStatus, StatusColor } from '../../../models/constants';
import Swal from 'sweetalert2';
import { AdminService } from '../../../services/admin-service';

@Component({
  selector: 'app-edit-tracking',
  standalone: false,
  templateUrl: './edit-tracking.html',
  styleUrl: './edit-tracking.css',
})
export class EditTracking {
  requestData: any = {
    requestId: '',
    projectTitle: '',
    dateOfSubmission: null,
    typeOfRequest: "",
    projectDescription: '',
    estimatedCompletionDate: null,
    priorityLevel: '',
    estimatedBudget: '',
    pm_scrum_master: '',
    devEndDate: "",
    qaEndDate: "",
    prodEndDate: "",
    devActualEndDate: "",
    qaActualEndDate: "",
    proActualEndDate: "",
    releaseStatus: "",
    domain: "",
    schedule: "",
    resources: "",
    scope: "",
    risks: "",
    comments: ""

  };


  mandatoryProps: any[] = [
    { name: "devEndDate", datatype: "date" },
    { name: "qaEndDate", datatype: "date" },
    { name: "prodEndDate", datatype: "date" },
    { name: "releaseStatus", datatype: "string" },
    { name: "schedule", datatype: "string" },
    { name: "resources", datatype: "string" },
    { name: "risks", datatype: "string" },
    { name: "scope", datatype: "string" },
  ]



  releaseStatusOptions = [
    { label: 'Not Started', value: '1' },
    { label: 'In Progress', value: '2' },
    { label: 'Dev Completed', value: '3' },
    { label: 'QA Completed', value: '4' },
    { label: 'Completed', value: '5' }
  ];

  statusOptions = [
    { label: 'Green', value: '1' },
    { label: 'Amber', value: '2' },
    { label: 'Red', value: '3' }
  ];

  requestId: string = "";

  missingproperties: any[] = [];
  isLoading: boolean = false;
  isEditMode: boolean = false

  constructor(private router: Router, private route: ActivatedRoute, private dataService: DataService, private service: AdminService, private cdRef: ChangeDetectorRef) {
    const _domain = this.route.snapshot.paramMap.get('id');
    console.log("----------------------------------", _domain);
    if (_domain != null)
      this.requestData.requestId = _domain

  }

  ngOnInit(): void {
    this.initPage();
    this.missingproperties = [];
  }


  async initPage() {
    if (!this.service.loggedUser.WWID) {
      await this.dataService.getUserDetails();
    }


    this.requestData.requestorName = this.service.loggedUser.UserName;
    this.requestData.dateOfSubmission = this.formatDate(new Date());
    this.requestData.estimatedCompletionDate
    this.requestId = this.route.snapshot.paramMap.get('id')!;

    if (this.requestId) {

      this.isEditMode = true;
      this.loadRecordForEdit(this.requestId);


    }
  }


  loadRecordForEdit(id: string): void {
    this.isLoading = true;
    let _this = this;
    this.dataService.getTrackingStatusById(id).subscribe((response: any) => {
      let data = response.data;
      if (response.status && data && data.length > 0) {
        this.requestData = data[0];
        this.requestData.dateOfSubmission = this.formatDate(new Date(this.requestData.dateOfSubmission));
        this.requestData.estimatedCompletionDate = this.formatDate(new Date(this.requestData.estimatedCompletionDate));
        this.requestData.devEndDate = this.requestData.devEndDate ? this.formatDate(new Date(this.requestData.devEndDate)) : null;
        this.requestData.qaEndDate = this.requestData.qaEndDate ? this.formatDate(new Date(this.requestData.qaEndDate)) : null;
        this.requestData.prodEndDate = this.requestData.prodEndDate ? this.formatDate(new Date(this.requestData.prodEndDate)) : null;
        this.requestData.devActualEndDate = this.requestData.devActualEndDate ? this.formatDate(new Date(this.requestData.devActualEndDate)) : null;
        this.requestData.qaActualEndDate = this.requestData.qaActualEndDate ? this.formatDate(new Date(this.requestData.qaActualEndDate)) : null;
        this.requestData.proActualEndDate = this.requestData.proActualEndDate ? this.formatDate(new Date(this.requestData.proActualEndDate)) : null;
        this.isEditMode = this.requestData.statusid ? true : false;
      }
      _this.isLoading = false;
      _this.cdRef.detectChanges();
    });
  }



  saveRecord() {
    this.missingproperties = [];
    let payload = { ...this.requestData };
    if (!this.areAllPropertiesPopulated(payload)) {
      Swal.fire({
        icon: 'warning',
        title: 'Missing Fields',
        text: 'Please fill all the required fields.',
        confirmButtonText: 'OK',
        customClass: {
          popup: 'custom-swal-popup',
          confirmButton: 'custom-confirm-btn'
        },
        buttonsStyling: false
      });
      return;
    }

    let devEndDate = new Date(this.requestData.devEndDate);


    if (this.isEditMode) {
      // Logic for updating an existing record

      let tbl_obj = {
        devEndDate: this.requestData.devEndDate,
        qaEndDate: this.requestData.qaEndDate,
        prodEndDate: this.requestData.prodEndDate,
        proActualEndDate: this.requestData.proActualEndDate,
        qaActualEndDate: this.requestData.qaActualEndDate,
        devActualEndDate: this.requestData.devActualEndDate,
        releaseStatus: this.requestData.releaseStatus,
        schedule: this.requestData.schedule,
        resources: this.requestData.resources,
        risks: this.requestData.risks,
        scope: this.requestData.scope,
        comments: this.requestData.comments,
        version: parseInt(this.requestData.version) + 1,
      }



      this.isLoading = true;
      this.dataService.updateTracking(payload.requestId, tbl_obj).subscribe((response: any) => {
        this.isLoading = false;
        if (response.status) {
          Swal.fire({
            icon: 'success',
            title: 'Saved!',
            text: 'Status updated successfully.',
            confirmButtonText: 'OK',
            customClass: {
              popup: 'custom-swal-popup',
              confirmButton: 'custom-confirm-btn'
            },
            buttonsStyling: false
          }).then(() => {
            this.missingproperties = [];
            this.router.navigate(['/tracking/tracking-form', this.requestData.domain], { skipLocationChange: true });
          });
        }
        else {
          Swal.fire({
            icon: 'error',
            title: 'Save Failed',
            text: 'There was a problem saving the record. Please try again.',
            confirmButtonText: 'OK',
            customClass: {
              popup: 'custom-swal-popup',
              confirmButton: 'custom-confirm-btn'
            },
            buttonsStyling: false
          });
        }

      });

    }
    else {
      let newRecord: any = { ...payload };
      newRecord.version = 1;
      this.dataService.saveIntakeStatus(newRecord).subscribe((response: any) => {
        if (response.status) {
          Swal.fire({
            icon: 'success',
            title: 'Saved!',
            text: 'Status updated successfully.',
            confirmButtonText: 'OK',
            customClass: {
              popup: 'custom-swal-popup',
              confirmButton: 'custom-confirm-btn'
            },
            buttonsStyling: false
          }).then(() => {
            this.missingproperties = [];
            this.router.navigate(['/tracking/tracking-form', this.requestData.domain], { skipLocationChange: true });
          });
        }
        else {
          Swal.fire({
            icon: 'error',
            title: 'Save Failed',
            text: 'There was a problem saving the record. Please try again.',
            confirmButtonText: 'OK',
            customClass: {
              popup: 'custom-swal-popup',
              confirmButton: 'custom-confirm-btn'
            },
            buttonsStyling: false
          });
        }
      });

    }
  }


  areAllPropertiesPopulated(obj: any) {
    /// debugger;
    this.mandatoryProps.forEach(item => {
      if (item.datatype === "string") {
        if (!obj[item.name] || obj[item.name].trim() === "") {
          this.missingproperties.push(item.name);
        }
      }
      else if (item.datatype === "date") {
        if (!obj[item.name] || obj[item.name] === null) {
          this.missingproperties.push(item.name);
        }
      }
      // else if (item.datatype === "email") {
      //   if (!obj[item.name] || !this.validateEmail(obj[item.name])) {
      //     this.missingproperties.push(item.name);
      //   }
      // }
    });

   
    if (this.missingproperties.length > 0)
      return false;
    return true;
  }

  getReleaseStatus(val: number) {
    return ReleaseStatus[val];
  }

  cancel() {
    this.router.navigate(['/tracking/tracking-form', this.requestData.domain], { skipLocationChange: true });
  }



  formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }

}
