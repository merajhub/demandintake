import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { DemandTrackingApiService } from '../services/demand-tracking-api.service';
import { RAG_STATUS_LABELS, RELEASE_STATUS_LABELS } from '../models/demand-tracking.models';

@Component({
    selector: 'app-demand-tracking-insights',
    standalone: false,
    templateUrl: './demand-tracking-insights.component.html',
    styleUrls: ['./demand-tracking-insights.component.css']
})
export class DemandTrackingInsightsComponent implements OnInit {
    isLoading = true;

    // Chart data objects
    statusChartData: any;
    domainChartData: any;
    priorityChartData: any;
    riskChartData: any;
    monthlyChartData: any;

    // Chart options
    pieOptions: any;
    doughnutOptions: any;
    barOptions: any;
    lineBarOptions: any;

    // Color palettes
    private domainColors: string[] = ['#EB1700', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899'];
    private priorityColors: Record<string, string> = {
        High: '#EF4444',
        Medium: '#F59E0B',
        Low: '#10B981',
        Unspecified: '#94A3B8',
    };
    private ragColors: Record<string, string> = {
        green: '#10B981',
        amber: '#F59E0B',
        red: '#EF4444',
        unspecified: '#94A3B8'
    };

    // Tracking release status colors
    private statusColors: Record<string, string> = {
        'Not Started': '#94A3B8',
        'In Progress': '#3B82F6',
        'Dev Completed': '#8B5CF6',
        'QA Completed': '#F59E0B',
        'Completed': '#10B981'
    };

    constructor(private apiService: DemandTrackingApiService, private cdRef: ChangeDetectorRef) { }

    ngOnInit(): void {
        this.initChartOptions();
        this.loadInsights();
    }

    private loadInsights(): void {
        this.isLoading = true;

        this.apiService.getAllTrackingInsights().subscribe({
            next: (response) => {
                const metrics = response.data || {};
                
                this.buildStatusChart(metrics.byStatus || []);
                this.buildDomainChart(metrics.byDomain || []);
                this.buildPriorityChart(metrics.byPriority || []);
                this.buildRiskChart(metrics.byRisk || []);
                this.buildMonthlyChart(metrics.byTimeline || []);
                
                this.isLoading = false;
                this.cdRef.detectChanges();
            },
            error: (err) => {
                console.error('Failed to load tracking insights:', err);
                this.isLoading = false;
                this.cdRef.detectChanges();
            },
        });
    }

    private formatReleaseStatus(statusId: any): string {
        const id = parseInt(statusId, 10);
        return RELEASE_STATUS_LABELS[id] || 'Not Started';
    }

    private formatRagStatus(ragId: any): string {
        const id = parseInt(ragId, 10);
        const label = RAG_STATUS_LABELS[id];
        if (!label) return 'Unspecified';
        return label.charAt(0).toUpperCase() + label.slice(1);
    }

    private buildStatusChart(data: any[]): void {
        const labels = data.map((d: any) => this.formatReleaseStatus(d.status));
        const values = data.map((d: any) => d.total);
        const bgColors = labels.map((label: string) => this.statusColors[label] || '#94A3B8');

        this.statusChartData = {
            labels,
            datasets: [{ data: values, backgroundColor: bgColors, hoverBackgroundColor: bgColors }],
        };
    }

    private buildDomainChart(data: any[]): void {
        const labels = data.map((d: any) => d.domain || 'Unspecified');
        const values = data.map((d: any) => d.total);
        const bgColors = labels.map((_: any, i: number) => this.domainColors[i % this.domainColors.length]);

        this.domainChartData = {
            labels,
            datasets: [{ data: values, backgroundColor: bgColors, hoverBackgroundColor: bgColors }],
        };
    }

    private buildPriorityChart(data: any[]): void {
        const labels = data.map((d: any) => d.priority || 'Unspecified');
        const values = data.map((d: any) => d.total);
        const bgColors = labels.map((label: string) => this.priorityColors[label] || '#94A3B8');

        this.priorityChartData = {
            labels,
            datasets: [{ data: values, backgroundColor: bgColors, hoverBackgroundColor: bgColors }],
        };
    }

    private buildRiskChart(data: any[]): void {
        const labels = data.map((d: any) => this.formatRagStatus(d.risk));
        const values = data.map((d: any) => d.total);
        const bgColors = labels.map((label: string) => this.ragColors[label.toLowerCase()] || '#94A3B8');

        this.riskChartData = {
            labels,
            datasets: [{ 
                label: 'Tracked Items by Risk',
                data: values, 
                backgroundColor: bgColors, 
                borderColor: bgColors,
                borderWidth: 1
            }],
        };
    }

    private buildMonthlyChart(data: any[]): void {
        const labels = data.map((d: any) => d.month);
        const values = data.map((d: any) => d.total);

        this.monthlyChartData = {
            labels,
            datasets: [
                {
                    label: 'Tracked Items',
                    data: values,
                    backgroundColor: '#3B82F680',
                    borderColor: '#3B82F6',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3,
                },
            ],
        };
    }

    private initChartOptions(): void {
        const documentStyle = getComputedStyle(document.documentElement);
        const textColor = '#495057';
        const surfaceBorder = '#dee2e6';

        this.pieOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'right', labels: { color: textColor, usePointStyle: true, padding: 16 } },
                tooltip: {
                    callbacks: {
                        label: (ctx: any) => {
                            const total = ctx.dataset.data.reduce((a: number, b: number) => a + b, 0);
                            const pct = total ? ((ctx.raw / total) * 100).toFixed(1) : 0;
                            return `${ctx.label}: ${ctx.raw} (${pct}%)`;
                        },
                    },
                },
            },
        };

        this.doughnutOptions = {
            ...this.pieOptions,
            cutout: '55%',
        };

        this.barOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
            },
            scales: {
                x: { ticks: { color: textColor }, grid: { color: surfaceBorder } },
                y: { ticks: { color: textColor, precision: 0 }, grid: { color: surfaceBorder }, beginAtZero: true },
            },
        };

        this.lineBarOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: textColor, usePointStyle: true } },
            },
            scales: {
                x: { ticks: { color: textColor }, grid: { color: surfaceBorder } },
                y: { ticks: { color: textColor, precision: 0 }, grid: { color: surfaceBorder }, beginAtZero: true },
            },
        };
    }
}
