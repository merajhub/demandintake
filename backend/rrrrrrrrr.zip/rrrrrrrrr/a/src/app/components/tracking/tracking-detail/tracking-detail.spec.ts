import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackingDetail } from './tracking-detail';

describe('TrackingDetail', () => {
  let component: TrackingDetail;
  let fixture: ComponentFixture<TrackingDetail>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TrackingDetail]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrackingDetail);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
