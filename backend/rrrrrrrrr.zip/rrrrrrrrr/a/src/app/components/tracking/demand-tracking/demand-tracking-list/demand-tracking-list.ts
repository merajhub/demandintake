import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { DemandTrackingApiService } from '../services/demand-tracking-api.service';
import { DemandTrackingRecord, DemandTrackingAuditRecord, RAG_STATUS_LABELS, RELEASE_STATUS_LABELS } from '../models/demand-tracking.models';
import { DemandRoleService } from '../../../intake/demand-intake/services/demand-role.service';
import { DemandApiService } from '../../../intake/demand-intake/services/demand-api.service';
import { DemandUser } from '../../../intake/demand-intake/models/demand-user.model';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-demand-tracking-list',
  standalone: false,
  templateUrl: './demand-tracking-list.html',
  styleUrl: './demand-tracking-list.css',
})
export class DemandTrackingList implements OnInit {
  records: DemandTrackingRecord[] = [];
  filteredRecords: DemandTrackingRecord[] = [];
  selectedRecord: DemandTrackingRecord | null = null;
  allUsers: DemandUser[] = [];
  isLoading = false;

  // Audit dialog
  showAuditDialog = false;
  isAuditLoading = false;
  auditRecords: DemandTrackingAuditRecord[] = [];

  // Filters
  filterDomain = '';
  filterReleaseStatus = '';
  domainOptions: { label: string; value: string }[] = [];
  releaseStatusOptions: { label: string; value: string }[] = [
    { label: 'All Statuses', value: '' },
    { label: 'Not Started', value: '1' },
    { label: 'In Progress', value: '2' },
    { label: 'Dev Completed', value: '3' },
    { label: 'QA Completed', value: '4' },
    { label: 'Completed', value: '5' },
  ];

  constructor(
    private trackingApi: DemandTrackingApiService,
    private demandApi: DemandApiService,
    public roleService: DemandRoleService,
    private router: Router,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
   // this.loadUsers();
    // this.roleService.currentUser$.subscribe((user) => {
    //   if (user) {
    //     this.loadRecords();
    //   }
    // });

     this.loadRecords();
  }

  loadUsers(): void {
    this.demandApi.getUsers().subscribe({
      next: (users) => {
        this.allUsers = users;
        this.cdRef.detectChanges();
        if (!this.roleService.currentUser && users.length > 0) {
          this.roleService.switchUser(users[0]);
        }
      },
      error: (err) => console.error('Failed to load users:', err),
    });
  }

  loadRecords(): void {
    this.isLoading = true;
    this.trackingApi.getApprovedRequests().subscribe({
      next: (response) => {
        if (response.status) {
          this.records = response.data || [];
          this.buildFilterOptions();
          this.applyFilters();
        }
        this.isLoading = false;
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Failed to load tracking records:', err);
        this.isLoading = false;
        this.cdRef.detectChanges();
      },
    });
  }

  switchUser(user: DemandUser): void {
    this.roleService.switchUser(user);
  }

  openTrackingForm(record: DemandTrackingRecord): void {
    this.router.navigate(
      ['/tracking/demand-tracking', record.request_id],
      { skipLocationChange: true }
    );
  }

  buildFilterOptions(): void {
    const domains = new Set<string>();
    this.records.forEach((r) => {
      if (r.domain) domains.add(r.domain);
    });
    this.domainOptions = [
      { label: 'All Domains', value: '' },
      ...[...domains].sort().map((d) => ({ label: d, value: d })),
    ];
  }

  applyFilters(): void {
    let result = [...this.records];

    if (this.filterDomain) {
      result = result.filter((r) => r.domain === this.filterDomain);
    }
    if (this.filterReleaseStatus) {
      const statusVal = parseInt(this.filterReleaseStatus);
      result = result.filter(
        (r) => (r.release_status || 1) === statusVal
      );
    }

    this.filteredRecords = result;
  }

  onFilterChange(): void {
    this.applyFilters();
  }

  clearFilters(): void {
    this.filterDomain = '';
    this.filterReleaseStatus = '';
    this.applyFilters();
  }

  get hasActiveFilters(): boolean {
    return !!(this.filterDomain || this.filterReleaseStatus);
  }

  // ── Display helpers ──────────────────────────────────────────────────────────

  getRagClass(value: number | null): string {
    if (!value) return '';
    return RAG_STATUS_LABELS[value] || '';
  }

  getRagLabel(value: number | null): string {
    if (!value) return '—';
    return (RAG_STATUS_LABELS[value] || '—').charAt(0).toUpperCase() + (RAG_STATUS_LABELS[value] || '').slice(1);
  }

  getReleaseStatusLabel(value: number | null): string {
    if (!value) return 'Not Started';
    return RELEASE_STATUS_LABELS[value] || 'Not Started';
  }

  getReleaseStatusClass(value: number | null): string {
    const v = value || 1;
    switch (v) {
      case 1: return 'release-not-started';
      case 2: return 'release-in-progress';
      case 3: return 'release-dev-completed';
      case 4: return 'release-qa-completed';
      case 5: return 'release-completed';
      default: return 'release-not-started';
    }
  }

  getDateStatusClass(planned: string | null, actual: string | null, releaseStatus: number | null, stage: string): string {
    if (!planned) return '';
    const rs = releaseStatus || 1;

    // Custom blank logic for each stage
    if (stage === 'dev' && rs === 1) return '';
    if (stage === 'qa' && rs < 3) return '';
    if (stage === 'prod' && rs < 4) return '';

    const today = new Date();
    today.setHours(0,0,0,0);
    
    const plannedDate = new Date(planned);
    plannedDate.setHours(0,0,0,0);
    
    const plannedMinus7 = new Date(plannedDate);
    plannedMinus7.setDate(plannedMinus7.getDate() - 7);
    
    if (!actual) {
        // Blank Actual Date
        if (today < plannedMinus7) {
            return 'green';
        } else if (today >= plannedMinus7 && today < plannedDate) {
            return 'amber';
        } else if (today >= plannedDate) {
            return 'red';
        }
    } else {
        // Non-blank Actual Date
        const actualDate = new Date(actual);
        actualDate.setHours(0,0,0,0);
        
        if (actualDate <= plannedMinus7 || actualDate.getTime() === plannedDate.getTime()) {
           return 'green';
        } else if (actualDate > plannedMinus7 && actualDate < plannedDate) {
           return 'amber';
        } else if (actualDate > plannedDate) {
           return 'red';
        }
    }

    return 'green';
  }

  formatDate(dateStr: string | null): string {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  // ── Export & Audit ────────────────────────────────────────────────────────────

  exportAsPdf(): void {
    if (this.filteredRecords.length === 0) return;

    const doc = new jsPDF({ orientation: 'landscape' });
    doc.text('Demand Tracking Dashboard', 14, 15);

    const headers = [
      'Project Title', 'Domain', 'Scope', 'Schedule', 'Resources', 'Risks',
      'Dev', 'QA', 'PROD', 'Release Status', 'Comments'
    ];

    const body = this.filteredRecords.map(rec => [
      rec.project_title || '—',
      rec.domain || '—',
      this.getRagLabel(rec.scope),
      this.getRagLabel(rec.schedule),
      this.getRagLabel(rec.resources),
      this.getRagLabel(rec.risks),
      this.formatDate(rec.dev_planned_date),
      this.formatDate(rec.qa_planned_date),
      this.formatDate(rec.prod_planned_date),
      this.getReleaseStatusLabel(rec.release_status),
      rec.comments || '—',
    ]);

    (doc as any).autoTable({
      head: [headers],
      body,
      startY: 20,
      theme: 'grid',
      styles: { fontSize: 7, cellPadding: 2 },
      headStyles: { fillColor: [200, 200, 200], textColor: [0, 0, 0], fontStyle: 'bold' },
    });

    doc.save('demand-tracking-dashboard.pdf');
  }

  exportAsExcel(): void {
    if (this.filteredRecords.length === 0) return;

    const excelData = this.filteredRecords.map(rec => ({
      'Project Title': rec.project_title || '—',
      'Domain': rec.domain || '—',
      'Scope': this.getRagLabel(rec.scope),
      'Schedule': this.getRagLabel(rec.schedule),
      'Resources': this.getRagLabel(rec.resources),
      'Risks': this.getRagLabel(rec.risks),
      'Dev Planned': this.formatDate(rec.dev_planned_date),
      'QA Planned': this.formatDate(rec.qa_planned_date),
      'PROD Planned': this.formatDate(rec.prod_planned_date),
      'Dev Actual': this.formatDate(rec.dev_actual_date),
      'QA Actual': this.formatDate(rec.qa_actual_date),
      'PROD Actual': this.formatDate(rec.prod_actual_date),
      'Release Status': this.getReleaseStatusLabel(rec.release_status),
      'Comments': rec.comments || '—',
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(excelData);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Demand Tracking');
    XLSX.writeFile(wb, 'demand-tracking-dashboard.xlsx');
  }

  openAuditDialog(): void {
    if (!this.selectedRecord) return;
    this.auditRecords = [];
    this.showAuditDialog = true;
    this.isAuditLoading = true;
    this.cdRef.detectChanges();
    this.trackingApi.getTrackingAudit(String(this.selectedRecord.request_id)).subscribe({
      next: (response) => {
        this.isAuditLoading = false;
        this.auditRecords = response.data || [];
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Failed to load audit:', err);
        this.isAuditLoading = false;
        this.cdRef.detectChanges();
      },
    });
  }
}
