import { ChangeDetectorRef, Component } from '@angular/core';
import { TrackingColumnInfo, TrackingColsInfo, StatusColor, ReleaseStatus, TrackingAuditColumnInfo, TrackingAuditColsInfo } from '../../../models/constants';
import { DataService } from '../../../services/data-service';
import { ActivatedRoute, Router } from '@angular/router';

import { MenuItem } from 'primeng/api';
import { AdminService } from '../../../services/admin-service';
import jsPDF from 'jspdf';
import 'jspdf-autotable'; // This registers the autoTable plugin
import * as XLSX from 'xlsx'; // Import the xlsx library

@Component({
  selector: 'app-tracking-detail',
  standalone: false,
  templateUrl: './tracking-detail.html',
  styleUrl: './tracking-detail.css',
})
export class TrackingDetail {
  items: MenuItem[] | undefined;

  detailsColumnInfo = TrackingColumnInfo;
  detailsColumns = TrackingColsInfo;
  auditdetailsColumnInfo = TrackingAuditColumnInfo;
  auditdetailsColumns = TrackingAuditColsInfo;
  selectedDetails: any | null = null;
  detailsData: any[] = [];
  auditdetailsData: any[] = [];
  domain: string = '';

  displayAddDetailsDialog: boolean = false;


  isLoading: boolean = false;


  constructor(private dataService: DataService, private service: AdminService, private router: Router, private route: ActivatedRoute, private cdRef: ChangeDetectorRef) {
  }

  async ngOnInit(): Promise<void> {
    this.domain = this.route.snapshot.paramMap.get('domain')!;
    await this.loadTrackingRecords();
  }

  async loadTrackingRecords() {

    this.isLoading = true;
    if (!this.service.loggedUser.WWID) {
      await this.dataService.getUserDetails();
    }

    let _this = this;
    this.dataService.getrackingtRecordsByDomain(this.domain).subscribe((response: any) => {
      this.isLoading = false;
      this.detailsData =
        response.data.map((item: any) => ({
          requestId: item.requestId,
          formattedRequestId: `REQ-${item.requestId}`,
          projectTitle: item.projectTitle || '—',
          pm_scrum_master: item.pm_scrum_master || '—',
          schedule: item.schedule ? this.getStatus(item.schedule) : "—",
          resources: item.resources ? this.getStatus(item.resources) : "—",
          scope: item.scope ? this.getStatus(item.scope) : "—",
          risks: item.risks ? this.getStatus(item.risks) : "—",
          devEndDate: item.devEndDate ? this.getDateStatus(item.devEndDate, item.devActualEndDate, item.releaseStatus, 'dev') : "—",
          qaEndDate: item.qaEndDate ? this.getDateStatus(item.qaEndDate, item.qaActualEndDate, item.releaseStatus, 'qa') : "—",
          prodEndDate: item.prodEndDate ? this.getDateStatus(item.prodEndDate, item.proActualEndDate, item.releaseStatus, 'prod') : "—",

          comments: item.comments || '—',
          domain: item.domain
        }));
      _this.cdRef.detectChanges();
    });
  }

  checkDisableCondition(): boolean {
    // Add your complex logic here
    return !this.selectedDetails ? true : false;

  }


  editRequest() {
    this.router.navigate(['/tracking/edit-form', this.selectedDetails.requestId], { skipLocationChange: true });
  }

  onRowDblClick(evt: any) {
    this.router.navigate(['/tracking/edit-form', evt.requestId], { skipLocationChange: true })
  }

  showVersions() {
    this.isLoading = true;
    let _this = this;
    this.dataService.getTrackingAuditById(this.selectedDetails.requestId).subscribe((response: any) => {
      this.isLoading = false;
      this.auditdetailsData =
        response.data.map((item: any) => ({
          schedule: item.schedule ? this.getStatus(item.schedule) : "—",
          resources: item.resources ? this.getStatus(item.resources) : "—",
          scope: item.scope ? this.getStatus(item.scope) : "—",
          risks: item.risks ? this.getStatus(item.risks) : "—",
          devEndDate: item.devEndDate ? this.formatDateMMDDYYYY(new Date(item.devEndDate)) : '—',
          qaEndDate: item.qaEndDate ? this.formatDateMMDDYYYY(new Date(item.qaEndDate)) : '—',
          prodEndDate: item.prodEndDate ? this.formatDateMMDDYYYY(new Date(item.prodEndDate)) : '—',


          devActualEndDate: item.devActualEndDate ? this.formatDateMMDDYYYY(new Date(item.devActualEndDate)) : '—',
          qaActualEndDate: item.qaActualEndDate ? this.formatDateMMDDYYYY(new Date(item.qaActualEndDate)) : '—',
          proActualEndDate: item.proActualEndDate ? this.formatDateMMDDYYYY(new Date(item.proActualEndDate)) : '—',
          comments: item.comments || '—',
          user_name: item.user_name,
          created_date: item.created_date
        }));

      this.displayAddDetailsDialog = true;
      _this.cdRef.detectChanges();

    });


  }

  goToTrackingDashboard() {
    this.router.navigate(['/tracking'], { skipLocationChange: true });
  }


  getStatus(val: number) {
    return StatusColor[val];
  }

  getDateStatus(est_date: string, act_date: any, status: any, stage: string = "") {
    if (status == 1) return "";
    if (!act_date) act_date = new Date();

    const targetDate = new Date(est_date);
    if (isNaN(targetDate.getTime())) {
      return 'unknown'; // Invalid date string
    }

    const actualDate = new Date(act_date);
    if (isNaN(actualDate.getTime())) {
      return 'unknown'; // Invalid date string
    }

    const targetUtc = Date.UTC(targetDate.getUTCFullYear(), targetDate.getUTCMonth(), targetDate.getUTCDate());
    const actualUtc = Date.UTC(actualDate.getUTCFullYear(), actualDate.getUTCMonth(), actualDate.getUTCDate());

    const msPerDay = 24 * 60 * 60 * 1000;
    const diffDays = Math.floor((targetUtc - actualUtc) / msPerDay);

    let threshold = 6;

    if (stage == 'dev' && parseInt(status) >= 3) {
      return targetUtc >= actualUtc ? "green" : "red"
    }
    else if (stage == 'qa' && parseInt(status) >= 4) {
      return targetUtc >= actualUtc ? "green" : "red"
    }
    else if (stage == 'prod' && parseInt(status) >= 5) {
      return targetUtc >= actualUtc ? "green" : "red"
    }


    if (diffDays > threshold) {
      return "green"
    } else if (diffDays >= 0 && diffDays <= threshold) {
      return "amber"
    } else {
      return "red"
    }








  }

  downloadDetailsAsPdf() {
    if (!this.detailsData || this.detailsData.length === 0) {
      console.warn('No data to download.');
      return;
    }

    this.isLoading = true;
    this.cdRef.detectChanges();

    const doc = new jsPDF();

    const headers = this.detailsColumnInfo.map((col: any) => col.DisplayName);
    const data = this.detailsData.map(row => {
      return this.detailsColumnInfo.map((colInfo: any) => {
        const colKey = colInfo.Name;
        return row[colKey] || '—';
      });
    });

    doc.text('Tracking Details Report', 14, 15);
    (doc as any).autoTable({
      head: [headers],
      body: data,
      startY: 20,
      theme: 'grid',
      styles: {
        fontSize: 8,
        cellPadding: 2,
      },
      headStyles: {
        fillColor: [200, 200, 200],
        textColor: [0, 0, 0],
        fontStyle: 'bold',
      },
      didParseCell: (cellData: any) => {
        this.didParseCell(cellData);
      },
      didDrawCell: (cellData: any) => {
        this.didDrawCell(cellData);
      }
    });



    doc.save(`Tracking-details-${this.domain}.pdf`);

    this.isLoading = false;
    this.cdRef.detectChanges();
  }

  didParseCell(cellData: any) {
    if (cellData.section === 'body' && cellData.cell.text.length > 0) {
      const colKey = this.detailsColumnInfo[cellData.column.index].Name;
      const cellText = cellData.cell.text[0]?.toLowerCase();
      if (['schedule', 'resources', 'scope', 'risks', 'devEndDate', 'qaEndDate', 'prodEndDate'].includes(colKey)) {
        let statusColor: [number, number, number] | null = null;
        if (cellText === 'green') {
          statusColor = [144, 238, 144];
        } else if (cellText === 'amber') {
          statusColor = [255, 204, 0];
        } else if (cellText === 'red') {
          statusColor = [255, 99, 71];
        }

        if (statusColor) {
          cellData.cell.statusColor = statusColor;
          cellData.cell.text = [''];
        }
      }
    }
  }

  didDrawCell(cellData: any) {
    if (cellData.section === 'body' && cellData.cell.statusColor) {
      const fillColor = cellData.cell.statusColor;
      const doc = cellData.doc;
      const centerX = cellData.cell.x + cellData.cell.width / 2;
      const centerY = cellData.cell.y + cellData.cell.height / 2;
      const radius = 3;
      doc.setFillColor(fillColor[0], fillColor[1], fillColor[2]);
      doc.circle(centerX, centerY, radius, 'F');
    }
  }


  downloadDetailsAsExcel() {
    if (!this.detailsData || this.detailsData.length === 0) {
      console.warn('No data to download.');
      // Optionally, you could show a user-facing message here
      return;
    }

    this.isLoading = true;
    this.cdRef.detectChanges();

    // Define colors in ARGB hex format (AA=Alpha, RR=Red, GG=Green, BB=Blue)
    const colors = {
      green: 'FF90EE90', // Light green
      amber: 'FFFFCC00', // Amber/Orange
      red: 'FFFF6347'   // Tomato red
    };
    // Prepare data for Excel
    const excelData = this.detailsData.map(row => {
      const newRow: { [key: string]: any } = {};
      this.detailsColumnInfo.forEach((colInfo: any) => {
        // Use DisplayName as the header for Excel
        newRow[colInfo.DisplayName] = row[colInfo.Name] || '—';
      });
      return newRow;
    });

    // Create a worksheet from the JSON data
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(excelData);

    // Identify columns that need color coding by their DisplayName
    const colorCodedColumnDisplayNames = [
      'Scope', 'Schedule', 'Resources', 'Risks', 'Dev', 'QA', 'PROD'
    ];

    // Create a mapping from the DisplayName to its column index in the Excel sheet
    // XLSX.utils.json_to_sheet uses the keys of the objects in excelData as headers,
    // which are the DisplayNames from detailsColumnInfo.
    const displayNameToExcelIndex: { [key: string]: number } = {};
    this.detailsColumnInfo.forEach((colInfo, index) => {
      if (colorCodedColumnDisplayNames.includes(colInfo.DisplayName)) {
        displayNameToExcelIndex[colInfo.DisplayName] = index;
      }
    });

    // Iterate through rows (starting from 1, as row 0 is header) and apply styles
    for (let R = 1; R <= excelData.length; ++R) {
      for (const colDisplayName of colorCodedColumnDisplayNames) {
        const colIndex = displayNameToExcelIndex[colDisplayName];
        if (colIndex !== undefined) {
          const cellAddress = XLSX.utils.encode_cell({ r: R, c: colIndex });
          const cell = ws[cellAddress];

          if (cell && cell.v) { // Check if cell exists and has a value
            // const cellText = String(cell.v).toLowerCase(); // The cell's value will be "Green", "Amber", "Red"
            const originalCellValue = String(cell.v);
            const cellText = originalCellValue.toLowerCase();
            console.log(`Excel Export Debug: Row: ${R}, Col: ${colDisplayName} (Index: ${colIndex}), Original Cell Value: '${originalCellValue}', Lowercase: '${cellText}'`);

            const fillColor = colors[cellText as keyof typeof colors]; // Get color based on text
            if (fillColor) {
              console.log(`Excel Export Debug:   Applying color: ${fillColor}`);

              if (!cell.s) cell.s = {}; // Initialize style object if it doesn't exist if not already
              cell.s.fill = { bgColor: { rgb: fillColor } }; // Use the variable fillColor, not the string literal
            } else {
              console.log(`Excel Export Debug:   No matching color found for '${cellText}'`);
            }
          }
        }
      }
    }

    // Create a new workbook and add the worksheet
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Tracking Details');

    // Save the workbook as an Excel file
    XLSX.writeFile(wb, `tracking-details-${this.domain}.xlsx`);

    this.isLoading = false;
    this.cdRef.detectChanges();
  }



  getReleaseStatus(val: number) {
    return ReleaseStatus[val];
  }

  openReportModal(evt: any) {
    this.selectedDetails = evt;

  }

  onTblRowUnSelect(evt: any) {
    this.selectedDetails = null;
  }

  formatDateMMDDYYYY(date: Date): string {
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${mm}/${dd}/${yyyy}`;
  }

}
