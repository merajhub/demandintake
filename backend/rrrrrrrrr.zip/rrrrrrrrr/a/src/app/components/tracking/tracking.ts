import { ChangeDetectorRef, Component } from '@angular/core';
import { DataService } from '../../services/data-service';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin-service';

@Component({
  selector: 'app-tracking',
  standalone: false,
  templateUrl: './tracking.html',
  styleUrl: './tracking.css',
})
export class Tracking {
  isloading: boolean = false;
  isHaveAccess: boolean = false;
  dataCount: any = {
    Safety: 0,
    Regulatory: 0,
    Clinical: 0
  };


  constructor(private dataService: DataService, public service: AdminService, private router: Router, private cdRef: ChangeDetectorRef) {
  }

  async ngOnInit(): Promise<void> {
    this.isHaveAccess = this.service.loggedUser.Roles.length > 0 ? true : false;
    this.cdRef.detectChanges();
    if(this.isHaveAccess) await this.getDomainRequestCount();
  }


  async getDomainRequestCount() {
    this.isloading = true;
    let _this = this;
    this.dataService.getDomainRequestCount().subscribe((response: any) => {
      if (response.status) {
        let _record = response.data.find((x: any) => x.domain == 'Safety')
        if (_record) {
          this.dataCount.Safety = _record.count;
        }

        _record = response.data.find((x: any) => x.domain == 'Regulatory')
        if (_record) {
          this.dataCount.Regulatory = _record.count;
        }

        _record = response.data.find((x: any) => x.domain == 'Clinical')
        if (_record) {
          this.dataCount.Clinical = _record.count;
        }

        this.isloading = false;
        _this.cdRef.detectChanges();

      }
    });

  }

  async showDetails(domain: string) {
    this.router.navigate(['/tracking/tracking-form', domain], { skipLocationChange: true });
  }


  enableDisableAction(action: string = "", pname: string = "") {
    if (this.service.loggedUser.IsSuperAdmin) return "";
    let PermissionName = pname



    // if (action == 'view') {
    //   PermissionName = domain == 'Safety' ? 'UpdateSafetyProjectsStatus' : domain == 'Clinical' ? 'UpdateClinicalProjectsStatus' : 'UpdateRegulatoryProjectsStatus'
    // } else if (action == 'approve') {
    //   PermissionName = domain == 'Safety' ? 'ApproveSafetyRequest' : domain == 'Clinical' ? 'ApproveClinicalRequest' : 'ApproveRegulatoryRequest'
    // } else if (action == 'addnew') {
    //   if (this.service.loggedUser.PermissionName.some(x => [pname].includes(x)))
    //     return "";
    //   else
    //     return "disabledbtn"
    // }

    return this.service.actionList[PermissionName] ? "" : "disabledbtn"

  }




}



