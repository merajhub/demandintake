import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { DemandTrackingApiService } from '../services/demand-tracking-api.service';
import { DemandRoleService } from '../../../intake/demand-intake/services/demand-role.service';
import {
  DemandTrackingRecord,
  DemandTrackingSavePayload,
  DemandTrackingAuditRecord,
  RELEASE_STATUS_OPTIONS,
  RAG_STATUS_OPTIONS,
  RELEASE_STATUS_LABELS,
  RAG_STATUS_LABELS,
} from '../models/demand-tracking.models';

@Component({
  selector: 'app-demand-tracking-form',
  standalone: false,
  templateUrl: './demand-tracking-form.html',
  styleUrl: './demand-tracking-form.css',
})
export class DemandTrackingForm implements OnInit {
  requestId: string = '';
  isLoading = false;
  isEditMode = false;

  // Form data
  record: DemandTrackingRecord | null = null;
  formData: any = {
    scope: null,
    schedule: null,
    resources: null,
    risks: null,
    scopeComment: '',
    scheduleComment: '',
    resourcesComment: '',
    risksComment: '',
    releaseStatus: 1,
    devPlannedDate: null,
    qaPlannedDate: null,
    prodPlannedDate: null,
    devActualDate: null,
    qaActualDate: null,
    prodActualDate: null,
    comments: '',
  };

  missingProperties: string[] = [];
  releaseStatusOptions = RELEASE_STATUS_OPTIONS;
  ragStatusOptions = RAG_STATUS_OPTIONS;

  // Audit
  showAuditDialog = false;
  auditRecords: DemandTrackingAuditRecord[] = [];

  constructor(
    private trackingApi: DemandTrackingApiService,
    public roleService: DemandRoleService,
    private messageService: MessageService,
    private route: ActivatedRoute,
    private router: Router,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.requestId = this.route.snapshot.paramMap.get('requestId') || '';
    if (this.requestId) {
      this.loadRecord();
    }
  }

  loadRecord(): void {
    this.isLoading = true;
    this.trackingApi.getTrackingByRequestId(this.requestId).subscribe({
      next: (response) => {
        if (response.status && response.data) {
          this.record = response.data;
          this.isEditMode = !!this.record.tracking_id;
          this.populateForm(this.record);
        }
        this.isLoading = false;
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Failed to load tracking record:', err);
        this.isLoading = false;
        this.cdRef.detectChanges();
      },
    });
  }

  populateForm(rec: DemandTrackingRecord): void {
    const currentStatus = rec.release_status || 1;
    this.releaseStatusOptions = RELEASE_STATUS_OPTIONS.filter(opt => opt.value >= currentStatus);

    this.formData.scope = rec.scope ?? null;
    this.formData.schedule = rec.schedule ?? null;
    this.formData.resources = rec.resources ?? null;
    this.formData.risks = rec.risks ?? null;
    this.formData.scopeComment = rec.scope_comment || '';
    this.formData.scheduleComment = rec.schedule_comment || '';
    this.formData.resourcesComment = rec.resources_comment || '';
    this.formData.risksComment = rec.risks_comment || '';
    this.formData.releaseStatus = currentStatus;
    this.formData.devPlannedDate = rec.dev_planned_date ? this.toDateStr(rec.dev_planned_date) : null;
    this.formData.qaPlannedDate = rec.qa_planned_date ? this.toDateStr(rec.qa_planned_date) : null;
    this.formData.prodPlannedDate = rec.prod_planned_date ? this.toDateStr(rec.prod_planned_date) : null;
    this.formData.devActualDate = rec.dev_actual_date ? this.toDateStr(rec.dev_actual_date) : null;
    this.formData.qaActualDate = rec.qa_actual_date ? this.toDateStr(rec.qa_actual_date) : null;
    this.formData.prodActualDate = rec.prod_actual_date ? this.toDateStr(rec.prod_actual_date) : null;
    this.formData.comments = rec.comments || '';
  }

  saveRecord(): void {
    this.missingProperties = [];

    // Validation
    if (!this.formData.scope) this.missingProperties.push('scope');
    if (!this.formData.schedule) this.missingProperties.push('schedule');
    if (!this.formData.resources) this.missingProperties.push('resources');
    if (!this.formData.risks) this.missingProperties.push('risks');
    if (!this.formData.releaseStatus) this.missingProperties.push('releaseStatus');
    if (!this.formData.devPlannedDate) this.missingProperties.push('devPlannedDate');
    if (!this.formData.qaPlannedDate) this.missingProperties.push('qaPlannedDate');
    if (!this.formData.prodPlannedDate) this.missingProperties.push('prodPlannedDate');

    if (this.missingProperties.length > 0) {
      this.messageService.add({
        severity: 'error',
        summary: 'Validation Failed',
        detail: 'Please fill in all required fields before saving.',
        life: 5000,
      });
      return;
    }

    const payload: DemandTrackingSavePayload = {
      requestId: parseInt(this.requestId),
      trackingId: this.record?.tracking_id || null,
      projectTitle: this.record?.project_title || '',
      domain: this.record?.domain || '',
      priorityLevel: this.record?.priority_level || '',
      pmScrumMaster: this.record?.pm_scrum_master || '',
      scope: this.formData.scope,
      schedule: this.formData.schedule,
      resources: this.formData.resources,
      risks: this.formData.risks,
      scopeComment: this.formData.scopeComment || null,
      scheduleComment: this.formData.scheduleComment || null,
      resourcesComment: this.formData.resourcesComment || null,
      risksComment: this.formData.risksComment || null,
      releaseStatus: this.formData.releaseStatus,
      devPlannedDate: this.formData.devPlannedDate,
      qaPlannedDate: this.formData.qaPlannedDate,
      prodPlannedDate: this.formData.prodPlannedDate,
      devActualDate: this.formData.devActualDate,
      qaActualDate: this.formData.qaActualDate,
      prodActualDate: this.formData.prodActualDate,
      comments: this.formData.comments || null,
      version: this.record?.version || 0,
      createdBy: this.roleService.userId,
      createdByName: this.roleService.userName,
    };

    this.isLoading = true;
    this.trackingApi.saveTracking(payload).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.status) {
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'success',
            summary: 'Saved',
            detail: 'Tracking status updated successfully.',
            life: 3000,
          });
          setTimeout(() => this.goBackToList(), 1500);
        } else {
          this.cdRef.detectChanges();
          this.messageService.add({
            severity: 'error',
            summary: 'Save Failed',
            detail: 'There was a problem saving the record. Please try again.',
            life: 5000,
          });
        }
      },
      error: (err) => {
        console.error('Save failed:', err);
        this.isLoading = false;
        this.cdRef.detectChanges();
        this.messageService.add({
          severity: 'error',
          summary: 'Save Failed',
          detail: 'There was a problem saving the record. Please try again.',
          life: 5000,
        });
      },
    });
  }

  loadAudit(): void {
    this.isLoading = true;
    this.trackingApi.getTrackingAudit(this.requestId).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.auditRecords = response.data || [];
        this.showAuditDialog = true;
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Failed to load audit:', err);
        this.isLoading = false;
        this.cdRef.detectChanges();
      },
    });
  }

  goBackToList(): void {
    this.router.navigate(['/tracking'], { skipLocationChange: true });
  }

  cancel(): void {
    this.goBackToList();
  }

  // ── Computed helpers ──────────────────────────────────────────────────────────

  /** Is Amber or Red selected? Show comment field */
  isDeviationRequired(field: string): boolean {
    return (this.formData[field] || 0) >= 2;
  }

  /** Dev actual date enabled only if release status >= 2 (In Progress) */
  isDevActualEnabled(): boolean {
    return (this.formData.releaseStatus || 0) >= 2;
  }

  /** QA actual date enabled only if release status >= 3 (Dev Completed) */
  isQaActualEnabled(): boolean {
    return (this.formData.releaseStatus || 0) >= 3;
  }

  /** PROD actual date enabled only if release status >= 4 (QA Completed) */
  isProdActualEnabled(): boolean {
    return (this.formData.releaseStatus || 0) >= 4;
  }

  /** When release status changes, clear disabled actual dates */
  onReleaseStatusChange(): void {
    const rs = this.formData.releaseStatus || 0;
    if (rs < 2) {
      this.formData.devActualDate = null;
      this.formData.qaActualDate = null;
      this.formData.prodActualDate = null;
    } else if (rs < 3) {
      this.formData.qaActualDate = null;
      this.formData.prodActualDate = null;
    } else if (rs < 4) {
      this.formData.prodActualDate = null;
    }
  }

  // ── Display helpers ──────────────────────────────────────────────────────────

  getRagLabel(value: number | null): string {
    if (!value) return '—';
    return RAG_STATUS_LABELS[value] || '—';
  }

  getReleaseLabel(value: number | null): string {
    if (!value) return 'Not Started';
    return RELEASE_STATUS_LABELS[value] || 'Not Started';
  }

  formatDate(dateStr: string | null): string {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  toDateStr(date: string): string {
    const d = new Date(date);
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const year = d.getFullYear();
    return `${month}/${day}/${year}`;
  }

  getRagForStage(stage: string): string {
    let planned: string | null = null;
    let actual: string | null = null;
    const rs = this.formData.releaseStatus || 1;

    if (stage === 'dev') {
        if (rs === 1) return '';
        planned = this.formData.devPlannedDate;
        actual = this.formData.devActualDate;
    } else if (stage === 'qa') {
        if (rs < 3) return '';
        planned = this.formData.qaPlannedDate;
        actual = this.formData.qaActualDate;
    } else if (stage === 'prod') {
        if (rs < 4) return '';
        planned = this.formData.prodPlannedDate;
        actual = this.formData.prodActualDate;
    }

    if (!planned) return '';

    const today = new Date();
    today.setHours(0,0,0,0);
    
    const plannedDate = new Date(planned);
    plannedDate.setHours(0,0,0,0);
    
    const plannedMinus7 = new Date(plannedDate);
    plannedMinus7.setDate(plannedMinus7.getDate() - 7);
    
    if (!actual) {
        // Blank Actual Date
        if (today < plannedMinus7) {
            return 'green';
        } else if (today >= plannedMinus7 && today < plannedDate) {
            return 'amber';
        } else if (today >= plannedDate) {
            return 'red';
        }
    } else {
        // Non-blank Actual Date
        const actualDate = new Date(actual);
        actualDate.setHours(0,0,0,0);
        
        if (actualDate <= plannedMinus7 || actualDate.getTime() === plannedDate.getTime()) {
           return 'green';
        } else if (actualDate > plannedMinus7 && actualDate < plannedDate) {
           return 'amber';
        } else if (actualDate > plannedDate) {
           return 'red';
        }
    }

    return '';
  }
}
