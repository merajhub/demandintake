import { ChangeDetectorRef, Component } from '@angular/core';
import { AdminService, AccessRequest } from '../../services/admin-service';
import { SelectItem } from 'primeng/api';
import { DataService } from '../../services/data-service';
import Swal from 'sweetalert2';

interface PageEvent {
  first: number;
  rows: number;
  page: number;
  pageCount: number;
}

@Component({
  selector: 'app-admin',
  standalone: false,
  templateUrl: './admin.html',
  styleUrl: './admin.css',
})
export class Admin {
  isRequestSubmitted: boolean = false;
  reason: string = '';
  isLoading: boolean = false;
  isInitiated: boolean = false;
  // Admin-specific properties
  isSuperAdmin: boolean = false;
  allRequests: AccessRequest[] = [];
  fillteredRequests: AccessRequest[] = [];

  showAddRequestForm: boolean = false;
  newRequestUserId: string = '';
  newRequestDomain: string = '';
  newRequestRole: string = '';
  newRequestReason: string = ''
  selectedDetails: boolean = false;

  selectedDomains: { [key: string]: boolean } = {
    safety: false,
    regulatory: false,
    clinical: false
  };
  selectedRoles: { [key: string]: string } = {
    safety: '',
    regulatory: '',
    clinical: ''
  };

  // For dropdowns in new request form
  domainsList: string[] = ['safety', 'regulatory', 'clinical'];
  availableRoles: string[] = ['User', 'Editor', 'Approver']; // Example roles

  // For filter dropdowns
  statuses: SelectItem[] = [
    { label: 'All', value: null },
    { label: 'Pending', value: 'Pending' },
    { label: 'Approved', value: 'Approved' },
    { label: 'Rejected', value: 'Rejected' }
  ];
  domains: SelectItem[] = [
    { label: 'All', value: null },
    { label: 'Safety', value: 'safety' },
    { label: 'Regulatory', value: 'regulatory' },
    { label: 'Clinical', value: 'clinical' }
  ];
  selectedStatus: string | null = "Pending";
  selectedDomain: string | null = null;

  first: number = 0;
  rows: number = 10;
  totalRows = 0;


  constructor(private service: AdminService, private dataService: DataService, private cdRef: ChangeDetectorRef) { }

  async ngOnInit() {
    this.isLoading = true;
    // Assuming dataService.loggedUser has a 'role' property to identify super admin
    await this.loadPendingRequests();

  }

  onPageChange(event: PageEvent) {
    this.first = event.first;
    this.rows = event.rows;
  }



  // Admin-specific methods
  async loadPendingRequests(): Promise<void> {
    this.isLoading = true;
    try {
      // Convert Observable to Promise for async/await
      const response: any = await this.service.getPendingAccessRequests()
      if (response && response.status) {
        this.allRequests = response.data;
        this.allRequests.forEach(x => {
          x.status = x.request_status == 1 ? "Pending"
            : x.request_status == 2 ? "Approved"
              : x.request_status == 3 ? "Rejected"
                : "";
        });
        this.onFilterChange(); // Apply initial filters (or show all if none selected)
      } else {
        console.error('Failed to load pending requests:', response?.message);
        this.allRequests = []; // Clear all requests on error
      }
    } catch (error) {
      console.error('Error loading pending requests:', error);
      this.allRequests = [];
    } finally {
      this.totalRows = this.allRequests.length;
      this.isLoading = false;
      this.cdRef.detectChanges();
    }
  }

  async approveRequest(request: AccessRequest): Promise<void> {
    if (!request.Id) {
      console.error('Cannot approve request without an ID.');
      return;
    }

    Swal.fire({
      title: "Are you sure to approve this request?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, approve it!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.confirmApproveRequest(request);
      }
    });

  }

  async confirmApproveRequest(request: AccessRequest) {
    const approvedBy = this.service.loggedUser.WWID;
    this.isLoading = true;
     this.cdRef.detectChanges();
    const response = await this.service.updateAccessRequestStatus(request.Id ? request.Id : 0, 2, request.userid, approvedBy, request.role_id)
   
    // After rejection, reload requests to reflect the change and re-apply filters
    await this.loadPendingRequests();
     this.isLoading = false;
    this.cdRef.detectChanges();
    Swal.fire({
      icon: 'info',
      title: 'Access Status',
      text: 'Request approved successfully.',
      confirmButtonText: 'OK',
      customClass: {
        popup: 'custom-swal-popup',
        confirmButton: 'custom-confirm-btn'
      }

    });
  }

  async rejectRequest(request: AccessRequest): Promise<void> {
    if (!request.Id) {
      console.error('Cannot approve request without an ID.');
      return;
    }

    Swal.fire({
      title: "Are you sure to reject this request?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, reject it!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.confirmRejectRequest(request);
      }
    });



  }

  async confirmRejectRequest(request: AccessRequest) {
    const approvedBy = this.service.loggedUser.WWID;
    this.isLoading = true;
    this.cdRef.detectChanges();
    const response = await this.service.updateAccessRequestStatus(request.Id ? request.Id : 0, 3, request.userid, approvedBy, request.role_id)
    
    // After rejection, reload requests to reflect the change and re-apply filters
    await this.loadPendingRequests();
    this.isLoading = false;
    this.cdRef.detectChanges();
    Swal.fire({
      icon: 'info',
      title: 'Access Status',
      text: 'Request rejected successfully.',
      confirmButtonText: 'OK',
      customClass: {
        popup: 'custom-swal-popup',
        confirmButton: 'custom-confirm-btn'
      }

    });
  }

  toggleAddRequestForm(): void {
    this.showAddRequestForm = !this.showAddRequestForm;
    if (!this.showAddRequestForm) {
      // Clear form fields when hiding
      this.newRequestUserId = '';
      this.newRequestDomain = '';
      this.newRequestRole = '';
      this.newRequestReason = '';
    }
  }

  async submitNewApprovedRequest(): Promise<void> {
    // if (!this.newRequestUserId || !this.newRequestDomain || !this.newRequestRole || !this.newRequestReason) {
    //   alert('Please fill all fields for the new approved request.');
    //   return;
    // }

    // const newApprovedRequest: AccessRequest = {
    //   userid: this.newRequestUserId,
    //   domain: this.newRequestDomain,
    //   role: this.newRequestRole,
    //   reason: this.newRequestReason,
    //   // request_status and approved_by will be set by the service to 'approved' and 'SuperAdmin'
    // };

    // this.isLoading = true;
    // try {
    //   const response = await this.service.addApprovedAccessRequest(newApprovedRequest).toPromise();
    //   if (response && response.status) {
    //     alert('New approved request added successfully!');
    //     this.toggleAddRequestForm(); // Hide form and clear fields
    //     await this.loadPendingRequests(); // Refresh pending requests (though this is approved, it might be good to refresh any related lists)
    //   } else {
    //     console.error('Failed to add new approved request:', response?.message);
    //     alert('Failed to add new approved request.');
    //   }
    // } catch (error) {
    //   console.error('Error adding new approved request:', error);
    //   alert('Error adding new approved request.');
    // } finally {
    //   this.isLoading = false;
    //   this.cdRef.detectChanges();
    // }
  }

  onDomainChangeForNewRequest(event: Event): void {
    this.newRequestDomain = (event.target as HTMLSelectElement).value;
  }

  onRoleChangeForNewRequest(event: Event): void {
    this.newRequestRole = (event.target as HTMLSelectElement).value;
  }




  onRowEditInit(product: any) {
    //this.clonedProducts[product.id as string] = { ...product };
  }

  onRowEditSave(product: any) {
    // if (product.price > 0) {
    //     delete this.clonedProducts[product.id as string];
    //     this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Product is updated' });
    // } else {
    //     this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Invalid Price' });
    // }
  }

  onRowEditCancel(product: any, index: number) {
    // this.products[index] = this.clonedProducts[product.id as string];
    // delete this.clonedProducts[product.id as string];
  }

  onFilterChange(): void {
    let filtered = [...this.allRequests]; // Start with all requests

    // Filter by status
    if (this.selectedStatus) {
      filtered = filtered.filter(request => request.status === this.selectedStatus);
    }

    // Filter by domain
    if (this.selectedDomain) {
      filtered = filtered.filter(request => request.domain.toLowerCase() === this.selectedDomain?.toLowerCase());
    }

    this.fillteredRequests = filtered;
    this.cdRef.detectChanges(); // Ensure UI updates
  }

  clearFilters(): void {
    this.selectedStatus = null;
    this.selectedDomain = null;
    this.onFilterChange(); // Re-apply filters, which will now show all data
  }
}
