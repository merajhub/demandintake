import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { DemandIntakeWorkflowService } from '../services/demand-intake-workflow.service';
import { DemandApiService } from '../services/demand-api.service';
import { WorkflowState } from '../models/demand-intake.models';

@Component({
  selector: 'app-demand-approved',
  standalone: false,
  templateUrl: './demand-approved.html',
  styleUrl: './demand-approved.css',
})
export class DemandApproved implements OnInit {
  @Input() requestId: string | null = null;

  state!: WorkflowState;

  constructor(
    private workflowService: DemandIntakeWorkflowService,
    private apiService: DemandApiService,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.state = this.workflowService.current;

    // If we have a requestId, load from API to get fresh data
    if (this.requestId) {
      this.apiService.getRequestById(this.requestId).subscribe({
        next: (request) => {
          if (request.projectOverview) {
            this.state = {
              ...this.state,
              projectOverview: request.projectOverview,
              requestorInformation: request.requestorInformation,
              projectSpecification: request.projectSpecification,
              managementNotes: request.managementNotes,
              status: request.status,
            };
          }
          this.cdRef.detectChanges();
        },
        error: (err) => console.error('Failed to load approved request:', err),
      });
    }
  }

  formatDate(date: Date | null | undefined): string {
    if (!date) return '—';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }
}
