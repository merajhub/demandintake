import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IntakeDetails } from './intake-details';

describe('IntakeDetails', () => {
  let component: IntakeDetails;
  let fixture: ComponentFixture<IntakeDetails>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [IntakeDetails]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IntakeDetails);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
