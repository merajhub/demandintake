import { AfterViewInit, ChangeDetectorRef, Component } from '@angular/core';
import { INTAKE } from '../../models/intake';
import { IntakeColumns, IntakeColumnInfo } from '../../models/constants';
import { DataService } from '../../services/data-service';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-intake',
  standalone: false,
  templateUrl: './intake.html',
  styleUrl: './intake.css',
})
export class Intake {
  detailsData: any[] = [];
  originalRequestId: string = '';
  selectedDetails: any | null = null;
  isAdmin: boolean = true;
  visible: boolean = false;
  detailsColumnInfo = IntakeColumnInfo;
  detailsColumns = IntakeColumns;
  displayAddDetailsDialog: boolean = false;
  isLoading: boolean = false;
  allRequestData: any[] = [];
  isHaveAccess: boolean = false;



  constructor(private dataService: DataService, public service: AdminService, 
    private router: Router, private cdRef: ChangeDetectorRef) {
  }

  async ngOnInit(): Promise<void> {
    // 
    this.isHaveAccess = this.service.loggedUser.Roles.length > 0 ? true : false;
    this.cdRef.detectChanges();
    if (this.isHaveAccess) await this.loadIntakeForms();


  }

  async loadIntakeForms() {

    this.isLoading = true;
    if (!this.service.loggedUser.WWID) {
      await this.dataService.getUserDetails();
    }

    let _this = this;
    let data: any;
    if (this.service.loggedUser.IsSuperAdmin) {
      data = await this.dataService.getAllIntakeForms();

    } else {
      data = await this.dataService.getMyIntakeFormsAsAdmin();
    }

    this.allRequestData = data;
    this.isLoading = false;
    this.detailsData =
      data.map((item: any) => ({
        requestId: item.requestId,
        projectTitle: item.projectTitle || '—',
        requestorName: item.requestorName || '—',
        dateOfSubmission: item.dateOfSubmission ? this.formatDateMMDDYYYY(new Date(item.dateOfSubmission)) : '—',
        typeOfRequest: item.typeOfRequest || '—',
        priorityLevel: item.priorityLevel || '—',
        status: item.status || '—',
        formattedRequestId: `REQ-${item.requestId}`,
        domain: item.domain
      }));
    _this.cdRef.detectChanges();


  }

  addDetails() {
    this.displayAddDetailsDialog = true;
  }


  showIntakeForm(domain: string) {
    this.router.navigate(['/intake/intake-form', domain], { skipLocationChange: true });
  }

  onRowDblClick(evt:any){
    this.router.navigate(['/intake/intake-form', evt.requestId], { skipLocationChange: true });
  }

  updateDetails() {
    this.router.navigate(['/intake/intake-form', this.selectedDetails.requestId] , { skipLocationChange: true });
  }



  downloadAllAsCsv() {
    if (!this.allRequestData || this.allRequestData.length === 0) {
      console.warn('No data to download.');
      // Optionally, you could show a user-facing message here.
      return;
    }

    const dataToExport = this.allRequestData;
    const headers = Object.keys(dataToExport[0]);

    const escapeCsvCell = (cell: any): string => {
      if (cell === null || cell === undefined) {
        return '';
      }
      let cellString = String(cell);
      if (cellString.search(/("|,|\n)/g) >= 0) {
        cellString = `"${cellString.replace(/"/g, '""')}"`;
      }
      return cellString;
    };

    const csvRows = [
      headers.join(','), // Header row
      ...dataToExport.map(row =>
        headers.map(header => escapeCsvCell(row[header])).join(',')
      )
    ];

    const csvString = csvRows.join('\r\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'all-intake-requests.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  approveRequest(status: string) {
    if (this.selectedDetails) {

      Swal.fire({
        title: `${status} Request?`,
        text: `Are you sure you want to ${status.toLowerCase()} request REQ-${this.selectedDetails.requestId}?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'Cancel',
        customClass: {
          popup: 'custom-swal-popup',
          confirmButton: 'grid-btn swal-btn',
          cancelButton: 'grid-btn swal-btn'
        },
        buttonsStyling: false
      }).then((result) => {
        if (result.isConfirmed) {
          this.isLoading = true;
          this.cdRef.detectChanges();
          this.dataService.updateStatus(this.selectedDetails.requestId, status).subscribe({
            next: () => {

              const index = this.detailsData.findIndex(item => item.requestId === this.selectedDetails.requestId);
              if (index !== -1) {
                this.detailsData[index].status = status;

              }
              Swal.fire({
                title: `${status}!`,
                text: `The request has been ${status}.`,
                icon: 'success',
                customClass: {
                  popup: 'custom-swal-popup',
                  confirmButton: 'grid-btn swal-btn'
                },
                buttonsStyling: false
              });
            },
            error: (err) => {
              this.isLoading = true;
              this.cdRef.detectChanges();
              console.error('Approval failed:', err);
              Swal.fire({
                title: 'Error',
                text: 'Failed to update the request.',
                icon: 'error',
                customClass: {
                  popup: 'custom-swal-popup',
                  confirmButton: 'grid-btn swal-btn'
                },
                buttonsStyling: false
              });
            },
            complete: () => {
              this.isLoading = false;
              this.cdRef.detectChanges();
            }
          });
        }
      });
    } else {
      Swal.fire({
        title: 'Please select a request!',
        //text: 'Please select a request!',
        icon: 'error',
        customClass: {
          popup: 'custom-swal-popup',
          confirmButton: 'grid-btn swal-btn'
        },
      });
    }
  }

  openReportModal(evt: any) {
    this.selectedDetails = evt;

  }

  onTblRowUnSelect(evt: any) {
    this.selectedDetails = null;
  }

  saveDetails() {
    // Logic to save the new details goes here
    console.log('Saving details...');
    this.displayAddDetailsDialog = false; // Close dialog on save
  }


  formatDateMMDDYYYY(date: Date): string {
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${mm}/${dd}/${yyyy}`;
  }


  checkPermission(pname: string) {
    if (this.service.loggedUser.IsSuperAdmin) return true;
    switch (pname) {
      case "add":
        if (this.service.loggedUser.PermissionName.some(x => ["AddRequestSafety", "AddRequestClinical", "AddRequestRegulatory"].includes(x)))
          return true;
        break;
    }
    return false;
  }

  enableDisableAction(action: string, pname: string = "") {
    if (this.service.loggedUser.IsSuperAdmin) return "";
    let PermissionName = ""
    if (this.selectedDetails) {
      let domain = this.selectedDetails.domain;

      if (action == 'update') {
        PermissionName = domain == 'Safety' ? 'UpdateSafetyProjectsStatus' : domain == 'Clinical' ? 'UpdateClinicalProjectsStatus' : 'UpdateRegulatoryProjectsStatus'
      } else if (action == 'approve') {
        PermissionName = domain == 'Safety' ? 'ApproveSafetyRequest' : domain == 'Clinical' ? 'ApproveClinicalRequest' : 'ApproveRegulatoryRequest'
      } else if (action == 'addnew') {
        if (this.service.loggedUser.PermissionName.some(x => [pname].includes(x)))
          return "";
        else
          return "disabledbtn"
      }

      return this.service.actionList[PermissionName] ? "" : "disabledbtn"
    } else {
      if (this.service.loggedUser.PermissionName.some(x => [pname].includes(x)))
        return "";
    }
    return "disabledbtn";



  }

}
