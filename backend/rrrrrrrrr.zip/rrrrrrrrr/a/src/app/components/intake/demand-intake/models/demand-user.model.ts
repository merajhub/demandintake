export type DemandRole = 'User' | 'Scrub_member' | 'Committee_member';

export interface DemandUser {
  id: string;
  name: string;
  email: string;
  role: DemandRole;
  domain?: string;
}
