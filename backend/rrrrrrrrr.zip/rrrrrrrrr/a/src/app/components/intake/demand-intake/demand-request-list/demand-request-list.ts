import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription, forkJoin } from 'rxjs';
import { DemandRoleService } from '../services/demand-role.service';
import { DemandApiService } from '../services/demand-api.service';
import { DemandUser } from '../models/demand-user.model';

@Component({
  selector: 'app-demand-request-list',
  standalone: false,
  templateUrl: './demand-request-list.html',
  styleUrl: './demand-request-list.css',
})
export class DemandRequestList implements OnInit, OnDestroy {
  requests: any[] = [];          // master list (merged: own + all)
  myRequests: any[] = [];        // user's own requests (includes drafts)
  allRequests: any[] = [];       // all non-draft requests (from all users)
  filteredRequests: any[] = [];
  selectedRequest: any = null;
  allUsers: DemandUser[] = [];
  isLoading = false;
  viewMode: 'table' | 'card' | 'kanban' = (sessionStorage.getItem('demandListViewMode') as 'table' | 'card' | 'kanban') || 'table';

  // Scope filter: controls which subset of requests to show
  scopeFilter: 'pending' | 'my' | 'all' = 'pending';

  // Kanban lanes – each lane groups multiple statuses
  kanbanLanes: { key: string; label: string; statuses: string[]; colorClass: string }[] = [
    { key: 'submitted', label: 'Submitted', statuses: ['draft', 'submitted'], colorClass: 'kanban-col-submitted' },
    { key: 'scrub', label: 'Scrub Team Review', statuses: ['in_review', 'clarification_requested'], colorClass: 'kanban-col-scrub' },
    { key: 'committee', label: 'Committee Team Review', statuses: ['committee_review', 'committee_clarification_requested'], colorClass: 'kanban-col-committee' },
    { key: 'approved', label: 'Approved / Deferred / Rejected', statuses: ['approved', 'rejected', 'deferred'], colorClass: 'kanban-col-approved' },
  ];
  kanbanColumns: { key: string; label: string; items: any[]; colorClass: string }[] = [];

  // Filter values
  filterDomain: string = '';
  filterStatus: string = '';
  filterType: string = '';

  // Sort
  sortField: string = '';
  sortOrder: 'asc' | 'desc' = 'asc';

  // Dropdown options (populated from data)
  domainOptions: { label: string; value: string }[] = [];
  statusOptions: { label: string; value: string }[] = [];
  typeOptions: { label: string; value: string }[] = [];
  sortOptions: { label: string; value: string }[] = [
    { label: 'Date Created', value: 'createdAt' },
    { label: 'Date Updated', value: 'updatedAt' },
    { label: 'Domain', value: 'domain' },
    { label: 'Type of Request', value: 'typeOfRequest' },
    { label: 'Priority', value: 'priorityLevel' },
  ];

  private sub!: Subscription;

  constructor(
    public roleService: DemandRoleService,
    private apiService: DemandApiService,
    private router: Router,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadUsers();
    this.sub = this.roleService.currentUser$.subscribe((user) => {
      if (user) {
        this.loadRequests();
      }
    });
  }

  ngOnDestroy(): void {
    if (this.sub) this.sub.unsubscribe();
  }

  loadUsers(): void {
    this.apiService.getUsers().subscribe({
      next: (users) => {
        this.allUsers = users;
        this.cdRef.detectChanges();

        // Auto-select first user if none selected
        if (!this.roleService.currentUser && users.length > 0) {
          this.roleService.switchUser(users[0]);
        }
      },
      error: (err) => console.error('Failed to load users:', err),
    });
  }

  loadRequests(): void {
    const user = this.roleService.currentUser;
    if (!user) return;

    // Only show loading spinner on initial load (when no data exists yet)
    if (this.requests.length === 0) {
      this.isLoading = true;
    }

    if (this.roleService.isUser()) {
      // For User role: fetch own requests (includes drafts) AND all non-draft requests
      forkJoin({
        own: this.apiService.getRequests(user.id, 'User', user.domain),
        all: this.apiService.getRequests(user.id, 'Scrub_member', user.domain), // triggers FETCH_ALL_NON_DRAFT_REQUESTS
      }).subscribe({
        next: ({ own, all }) => {
          this.myRequests = own;
          this.allRequests = all;
          // Merge & deduplicate by id (own may have drafts not in all)
          const map = new Map<string, any>();
          own.forEach((r) => map.set(r.id, r));
          all.forEach((r) => { if (!map.has(r.id)) map.set(r.id, r); });
          this.requests = Array.from(map.values());
          this.buildFilterOptions();
          this.applyFilters();
          this.isLoading = false;
          this.cdRef.detectChanges();
        },
        error: (err) => {
          console.error('Failed to load requests:', err);
          this.isLoading = false;
        },
      });
    } else {
      // Scrub / Committee: fetch ALL non-draft requests (no domain filter)
      // Domain filtering is applied client-side in applyFilters()
      this.apiService.getRequests(user.id, user.role).subscribe({
        next: (data) => {
          this.myRequests = [];
          this.allRequests = data;
          this.requests = data;
          this.buildFilterOptions();
          this.applyFilters();
          this.isLoading = false;
          this.cdRef.detectChanges();
        },
        error: (err) => {
          console.error('Failed to load requests:', err);
          this.isLoading = false;
        },
      });
    }
  }

  switchUser(user: DemandUser): void {
    this.scopeFilter = 'pending';
    this.roleService.switchUser(user);
  }

  createNewRequest(): void {
    this.router.navigate(['/intake/demand-intake/new'], { skipLocationChange: true });
  }

  navigateToInsights(): void {
    this.router.navigate(['/intake/demand-intake/insights'], { skipLocationChange: true });
  }

  openRequest(request: any): void {
    this.router.navigate(['/intake/demand-intake', request.id], { skipLocationChange: true });
  }

  getStatusClass(status: string): string {
    const map: Record<string, string> = {
      draft: 'badge-draft',
      submitted: 'badge-submitted',
      in_review: 'badge-review',
      clarification_requested: 'badge-clarification',
      committee_review: 'badge-committee',
      committee_clarification_requested: 'badge-clarification',
      approved: 'badge-approved',
      rejected: 'badge-rejected',
      deferred: 'badge-deferred',
    };
    return map[status] || 'badge-default';
  }

  formatStatus(status: string): string {
    return (status || '').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  }

  formatDate(dateStr: string): string {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  toggleView(mode: 'table' | 'card' | 'kanban'): void {
    this.viewMode = mode;
    sessionStorage.setItem('demandListViewMode', mode);
  }

  /** Toggle scope filter (Pending with Me / My Requests / All) */
  toggleScope(scope: 'pending' | 'my' | 'all'): void {
    this.scopeFilter = scope;
    this.applyFilters();
  }

  /** Returns the available scope options based on the current user's role */
  get scopeOptions(): { key: 'pending' | 'my' | 'all'; label: string; icon: string; tooltip: string }[] {
    if (this.roleService.isUser()) {
      return [
        { key: 'pending', label: 'Pending with Me', icon: 'pi-clock', tooltip: 'Requests needing your action' },
        { key: 'my', label: 'My Requests', icon: 'pi-user', tooltip: 'Requests created by you' },
        { key: 'all', label: 'All Requests', icon: 'pi-list', tooltip: 'All your requests' },
      ];
    }
    const domainLabel = this.roleService.domain ? `My Domain (${this.roleService.domain})` : 'My Domain';
    if (this.roleService.isScrubMember()) {
      return [
        { key: 'pending', label: 'Pending with Me', icon: 'pi-clock', tooltip: 'Requests in your domain awaiting scrub review' },
        { key: 'my', label: domainLabel, icon: 'pi-globe', tooltip: 'All requests in your domain' },
        { key: 'all', label: 'All Requests', icon: 'pi-list', tooltip: 'All submitted requests across all domains' },
      ];
    }
    if (this.roleService.isCommitteeMember()) {
      return [
        { key: 'pending', label: 'Pending with Me', icon: 'pi-clock', tooltip: 'Requests in your domain awaiting committee decision' },
        { key: 'my', label: domainLabel, icon: 'pi-globe', tooltip: 'All requests in your domain' },
        { key: 'all', label: 'All Requests', icon: 'pi-list', tooltip: 'All submitted requests across all domains' },
      ];
    }
    return [];
  }

  getPriorityClass(priority: string): string {
    switch ((priority || '').toLowerCase()) {
      case 'high': return 'priority-high';
      case 'medium': return 'priority-medium';
      case 'low': return 'priority-low';
      default: return 'priority-default';
    }
  }

  /** Returns true when the current user needs to take action on a request */
  isActionNeeded(request: any): boolean {
    const status = request.status;
    if (this.roleService.isUser()) {
      return ['clarification_requested', 'committee_clarification_requested'].includes(status);
    }
    const requestDomain = request.projectOverview?.domain;
    const reviewerDomain = this.roleService.domain;
    const domainMatch = !reviewerDomain || reviewerDomain === requestDomain;
    if (this.roleService.isScrubMember()) {
      return ['submitted', 'in_review'].includes(status) && domainMatch;
    }
    if (this.roleService.isCommitteeMember()) {
      return ['committee_review'].includes(status) && domainMatch;
    }
    return false;
  }

  /* ----------  Filter & Sort  ---------- */

  buildFilterOptions(): void {
    const domains = new Set<string>();
    const statuses = new Set<string>();
    const types = new Set<string>();

    this.requests.forEach((r) => {
      if (r.projectOverview?.domain) domains.add(r.projectOverview.domain);
      if (r.status) statuses.add(r.status);
      if (r.projectOverview?.typeOfRequest) types.add(r.projectOverview.typeOfRequest);
    });

    this.domainOptions = [
      { label: 'All Domains', value: '' },
      ...[...domains].sort().map((d) => ({ label: d, value: d })),
    ];
    this.statusOptions = [
      { label: 'All Statuses', value: '' },
      ...[...statuses].sort().map((s) => ({ label: this.formatStatus(s), value: s })),
    ];
    this.typeOptions = [
      { label: 'All Types', value: '' },
      ...[...types].sort().map((t) => ({ label: t, value: t })),
    ];
  }

  applyFilters(): void {
    debugger;
    let result: any[];

    // Scope filter – pick the right base dataset based on role and scope
    if (this.roleService.isUser()) {
      if (this.scopeFilter === 'pending') {
        // Requestor pending: own requests with clarification requested statuses
        result = this.myRequests.filter((r) =>
          ['clarification_requested', 'committee_clarification_requested'].includes(r.status)
        );
      } else if (this.scopeFilter === 'my') {
        // Requestor my requests: only own requests (includes drafts)
        result = [...this.myRequests];
      } else {
        // Requestor all: all requests from all users (merged set)
        result = [...this.requests];
      }
    } else if (this.roleService.isScrubMember()) {
      const reviewerDomain = this.roleService.domain;
      if (this.scopeFilter === 'pending') {
        result = this.allRequests.filter((r) => {
          const domainMatch = !reviewerDomain || r.projectOverview?.domain === reviewerDomain;
          return domainMatch && (['submitted', 'in_review'].includes(r.status) || ['scrub'].includes(r.stage));
        });
      } else if (this.scopeFilter === 'my') {
        result = this.allRequests.filter((r) => !reviewerDomain || r.projectOverview?.domain === reviewerDomain);
      } else {
        result = [...this.allRequests];
      }
    } else if (this.roleService.isCommitteeMember()) {
      const reviewerDomain = this.roleService.domain;
      if (this.scopeFilter === 'pending') {
        result = this.allRequests.filter((r) => {
          const domainMatch = !reviewerDomain || r.projectOverview?.domain === reviewerDomain;
          return domainMatch && (['committee_review'].includes(r.status) || ['committee'].includes(r.stage));
        });
      } else if (this.scopeFilter === 'my') {
        result = this.allRequests.filter((r) => !reviewerDomain || r.projectOverview?.domain === reviewerDomain);
      } else {
        result = [...this.allRequests];
      }
    } else {
      result = [...this.requests];
    }

    if (this.filterDomain) {
      result = result.filter((r) => r.projectOverview?.domain === this.filterDomain);
    }
    if (this.filterStatus) {
      result = result.filter((r) => r.status === this.filterStatus);
    }
    if (this.filterType) {
      result = result.filter((r) => r.projectOverview?.typeOfRequest === this.filterType);
    }

    // Sort
    if (this.sortField) {
      result.sort((a, b) => {
        let valA: any;
        let valB: any;

        if (this.sortField === 'createdAt' || this.sortField === 'updatedAt') {
          valA = a[this.sortField] ? new Date(a[this.sortField]).getTime() : 0;
          valB = b[this.sortField] ? new Date(b[this.sortField]).getTime() : 0;
        } else if (this.sortField === 'priorityLevel') {
          const priorityOrder: Record<string, number> = { high: 1, medium: 2, low: 3 };
          valA = priorityOrder[(a.projectOverview?.priorityLevel || '').toLowerCase()] || 99;
          valB = priorityOrder[(b.projectOverview?.priorityLevel || '').toLowerCase()] || 99;
        } else {
          valA = (a.projectOverview?.[this.sortField] || '').toLowerCase();
          valB = (b.projectOverview?.[this.sortField] || '').toLowerCase();
        }

        if (valA < valB) return this.sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return this.sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
    }

    this.filteredRequests = result;
    this.buildKanbanColumns();
  }

  buildKanbanColumns(): void {
    // Build columns from the lane definitions, grouping requests by status sets
    this.kanbanColumns = this.kanbanLanes.map((lane) => ({
      key: lane.key,
      label: lane.label,
      items: this.filteredRequests.filter((r) => lane.statuses.includes(r.status)),
      colorClass: lane.colorClass,
    }));
  }

  onFilterChange(): void {
    this.applyFilters();
  }

  onSortChange(): void {
    this.applyFilters();
  }

  toggleSortOrder(): void {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    this.applyFilters();
  }

  clearFilters(): void {
    this.filterDomain = '';
    this.filterStatus = '';
    this.filterType = '';
    this.sortField = '';
    this.sortOrder = 'asc';
    this.scopeFilter = 'pending';
    this.applyFilters();
  }

  get hasActiveFilters(): boolean {
    return !!(this.filterDomain || this.filterStatus || this.filterType || this.sortField);
  }
}
