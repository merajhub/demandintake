import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DemandIntakeWorkflowService } from './services/demand-intake-workflow.service';
import { DemandRoleService } from './services/demand-role.service';
import { DemandApiService } from './services/demand-api.service';
import { STEP_LIST, STEP_INDEX, StepId } from './models/demand-intake.models';

@Component({
  selector: 'app-demand-intake',
  standalone: false,
  templateUrl: './demand-intake.html',
  styleUrl: './demand-intake.css',
})
export class DemandIntake implements OnInit, OnDestroy {
  steps = STEP_LIST;
  activeStepIndex = 0;
  highestStepIndex = 0; // tracks the furthest step reached
  currentView: StepId = 'INTAKE_FORM';
  requestId: string | null = null; // null = new request
  isLoading = false;

  private sub!: Subscription;

  constructor(
    public workflowService: DemandIntakeWorkflowService,
    public roleService: DemandRoleService,
    private apiService: DemandApiService,
    private route: ActivatedRoute,
    private router: Router,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.sub = this.workflowService.state$.subscribe((state) => {
      this.activeStepIndex = STEP_INDEX[state.activeStep];
      this.currentView = state.activeStep;
      // Track the highest step ever reached so earlier steps stay clickable
      if (this.activeStepIndex > this.highestStepIndex) {
        this.highestStepIndex = this.activeStepIndex;
      }
    });

    // Check route param for request ID
    const paramId = this.route.snapshot.paramMap.get('id');
    if (paramId && paramId !== 'new') {
      this.requestId = paramId;
      this.loadRequest(paramId);
    } else {
      // New request
      this.requestId = null;
      this.workflowService.resetState();
      this.setInitialStepForRole();
    }
  }

  ngOnDestroy(): void {
    if (this.sub) this.sub.unsubscribe();
  }

  loadRequest(id: string): void {
    this.isLoading = true;
    this.apiService.getRequestById(id).subscribe({
      next: (request) => {
        // Populate workflow state from server data
        if (request.projectOverview) {
          this.workflowService.saveProjectOverview(request.projectOverview);
        }
        if (request.requestorInformation) {
          this.workflowService.saveRequestorInformation(request.requestorInformation);
        }
        if (request.projectSpecification) {
          this.workflowService.saveProjectSpecification(request.projectSpecification);
        }
        if (request.managementNotes) {
          this.workflowService.saveManagementNotes(request.managementNotes);
        }
        // Populate submitter remarks into scrub review state if present
        if (request.submitterRemarks) {
          const currentScrub = this.workflowService.current.scrubReview;
          this.workflowService.saveScrubReview({
            decision: currentScrub?.decision || '',
            scrubTeamRemarks: currentScrub?.scrubTeamRemarks || '',
            latestSubmitterRemarks: request.submitterRemarks,
            attachments: currentScrub?.attachments || [],
          });
        }
        if (request.status) {
          this.workflowService.advanceTo(
            this.getStepForStatus(request.status),
            request.status
          );
        }
        // For Scrub/Committee roles, jump directly to their step
        this.setInitialStepForRole();
        this.isLoading = false;
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Failed to load request:', err);
        this.isLoading = false;
        this.cdRef.detectChanges();
      },
    });
  }

  setInitialStepForRole(): void {
    const role = this.roleService.role;
    const status = this.workflowService.current.status;

    // Scrub/Committee members jump to their own step only if the request
    // is currently in their active phase. Otherwise let the status-driven
    // step stand so they can view the request in read-only mode at the
    // correct step.
    if (role === 'Scrub_member') {
      const scrubStatuses = ['submitted', 'in_review', 'clarification_requested'];
      if (scrubStatuses.includes(status)) {
        this.workflowService.setStep('SCRUB_TEAM');
      }
    } else if (role === 'Committee_member') {
      const committeeStatuses = ['committee_review', 'committee_clarification_requested'];
      if (committeeStatuses.includes(status)) {
        this.workflowService.setStep('COMMITTEE_TEAM');
      }
    } else if (role === 'User') {
      // Requestor: jump to the review step when clarification is requested
      if (status === 'clarification_requested') {
        this.workflowService.setStep('SCRUB_TEAM');
      } else if (status === 'committee_clarification_requested') {
        this.workflowService.setStep('COMMITTEE_TEAM');
      }
    }
  }

  getStepForStatus(status: string): StepId {
    switch (status) {
      case 'draft':
      case 'submitted':
        return 'INTAKE_FORM';
      case 'in_review':
      case 'clarification_requested':
        return 'SCRUB_TEAM';
      case 'committee_review':
      case 'committee_clarification_requested':
      case 'rejected':
      case 'deferred':
        return 'COMMITTEE_TEAM';
      case 'approved':
        return 'APPROVED';
      default:
        return 'INTAKE_FORM';
    }
  }

  isStepCompleted(index: number): boolean {
    return index < this.highestStepIndex;
  }

  isStepActive(index: number): boolean {
    return index === this.activeStepIndex;
  }

  onStepClick(index: number): void {
    if (index <= this.highestStepIndex) {
      const step = this.steps[index];
      this.workflowService.setStep(step.key);
    }
  }

  goBackToList(): void {
    this.workflowService.resetState();
    this.highestStepIndex = 0;
    this.router.navigate(['/intake/demand-intake'], { skipLocationChange: true });
  }
}
