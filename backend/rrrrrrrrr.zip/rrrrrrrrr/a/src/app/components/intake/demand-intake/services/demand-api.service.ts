import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DemandUser } from '../models/demand-user.model';

@Injectable({
  providedIn: 'root',
})
export class DemandApiService {
  private apiUrl = 'http://localhost:8026';

  constructor(private http: HttpClient) {}

  // ─── Users ───
  getUsers(): Observable<DemandUser[]> {
    return this.http.get<DemandUser[]>(`${this.apiUrl}/api/mysql-demand-users`);
  }

  // ─── Requests ───
  getRequests(userId: string, role: string, domain?: string): Observable<any[]> {
    const params: any = { userId, role };
    if (domain) {
      params.domain = domain;
    }
    return this.http.get<any[]>(`${this.apiUrl}/api/mysql-demand-requests`, { params });
  }

  getRequestById(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-requests/${id}`);
  }

  createRequest(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/mysql-demand-requests`, data);
  }

  updateRequest(id: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/api/mysql-demand-requests/${id}`, data);
  }

  updateRequestStatus(id: string, status: string, stage?: string): Observable<any> {
    const payload: any = { status };
    if (stage) {
      payload.stage = stage;
    }
    return this.http.patch<any>(`${this.apiUrl}/api/mysql-demand-requests/${id}/status`, payload);
  }

 

  // ─── Reviews ───
  getReviews(requestId: string, reviewType?: string): Observable<any[]> {
    const params: any = { requestId };
    if (reviewType) params.reviewType = reviewType;
    return this.http.get<any[]>(`${this.apiUrl}/api/mysql-demand-reviews`, { params });
  }

  createReview(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/mysql-demand-reviews`, data);
  }

  createReviewWithFile(data: any, file: File): Observable<any> {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      formData.append(key, data[key]);
    });
    formData.append('file', file, file.name);
    return this.http.post<any>(`${this.apiUrl}/api/mysql-demand-reviews`, formData);
  }

  getAttachmentUrl(storedName: string): string {
    return `${this.apiUrl}/api/mysql-demand-reviews/attachment/${storedName}`;
  }

  // ─── Comments ───
  getComments(requestId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/api/mysql-demand-comments`, {
      params: { requestId },
    });
  }

  addComment(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/mysql-demand-comments`, data);
  }

  // ─── Insights / Analytics ───
  getInsightsCountByStatus(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-status`);
  }

  getInsightsCountByDomain(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-domain`);
  }

  getInsightsCountByPriority(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-priority`);
  }

  getInsightsCountByType(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-type`);
  }

  getInsightsCountByDomainStatus(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-domain-status`);
  }

  getInsightsCountByMonth(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-month`);
  }

  getInsightsBudgetByDomain(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/budget-by-domain`);
  }

  getInsightsCountByPriorityDomain(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-priority-domain`);
  }

  getInsightsCountByTypeDomain(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-type-domain`);
  }

  getInsightsCountByMonthDomain(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/count-by-month-domain`);
  }

  getInsightsDrilldown(params: Record<string, string>): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/api/mysql-demand-insights/drilldown`, { params });
  }
}
