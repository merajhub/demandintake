import { ChangeDetectorRef, Component } from '@angular/core';
import { INTAKE } from '../../../models/intake';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../../services/data-service';
import Swal from 'sweetalert2';
import { AdminService } from '../../../services/admin-service';

@Component({
  selector: 'app-intake-details',
  standalone: false,
  templateUrl: './intake-details.html',
  styleUrl: './intake-details.css',
})
export class IntakeDetails {

  isLoading = false;
  requestData: any = {
    requestId: '',
    projectTitle: '',
    requestorName: '',
    department: '',
    contactEmail: '',
    contactPhone: '',
    dateOfSubmission: null,
    typeOfRequest: "",
    projectDescription: '',
    projectGoals: '',
    businessProblem: '',
    expectedOutcome: '',
    estimatedCompletionDate: null,
    estimatedStartDate: null,
    resourceRequirements: '',
    targetUsers: '',
    priorityLevel: '',
    dependencies: '',
    platform: '',
    complianceRequirements: '',
    status: '',
    technologyPreference: '',
    estimatedBudget: '',
    stakeholders: '',
    risks: '',
    reviewNotes: '',
    additionalNotes: '',
    approvalSignoff: '',
    attachments: '',
    domain: '',
    requestorEmail: '',
    requestor_wwid: '',
    pm_scrum_master: ''
  };

  mandatoryProps: any[] = [
    { name: "projectTitle", datatype: "string" },
    { name: "projectTitle", datatype: "string" },
    { name: "dateOfSubmission", datatype: "date" },
    { name: "estimatedCompletionDate", datatype: "date" },
    { name: "estimatedStartDate", datatype: "date" },
    { name: "typeOfRequest", datatype: "string" },
    { name: "priorityLevel", datatype: "string" },
    { name: "requestorName", datatype: "string" },
    { name: "department", datatype: "string" },
    { name: "contactEmail", datatype: "email" },
    { name: "expectedOutcome", datatype: "string" },
    { name: "projectDescription", datatype: "string" },
    { name: "targetUsers", datatype: "string" },
    { name: "platform", datatype: "string" },
    { name: "technologyPreference", datatype: "string" },
    { name: "projectGoals", datatype: "string" },
    { name: "businessProblem", datatype: "string" },
    { name: "resourceRequirements", datatype: "string" },
    { name: "dependencies", datatype: "string" },
    { name: "complianceRequirements", datatype: "string" },
    { name: "domain", datatype: "string" },
    { name: "pm_scrum_master", datatype: "string" },
  ]

  missingproperties: any[] = [];


  formSection: any = {
    overViewExpanded: true,
    requestorExpanded: true,
    specificationsExpanded: false,
    managementExpanded: false

  }

  selectedFile: File | null = null;
  isEditMode = false;
  requestId!: string;
  currentDate = new Date();
  formSubmitted = false;

  domains = [
    { label: 'Safety', value: 'Safety' },
    { label: 'Clinical', value: 'Clinical' },
    { label: 'Regulatory', value: 'Regulatory' }
  ];

  requestTypes = [
    { label: 'New Development', value: 'New Development' },
    { label: 'Enhancement', value: 'Enhancement' }
  ];

  priorityOptions = [
    { label: 'Low', value: 'Low' },
    { label: 'Medium', value: 'Medium' },
    { label: 'High', value: 'High' }
  ];

  statusOptions = [
    { label: 'Approve', value: 'Approve' },
    { label: 'Reject', value: 'Reject' },
    { label: 'Revert', value: 'Revert' }
  ];

  yesNoOptions = [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
  ];


  breadCrumbData = [
    { name: 'Intake', link: '/intake' },
    { name: '', link: '/addtopic' }
  ]

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private dataService: DataService,
    private cdRef: ChangeDetectorRef,
    private service: AdminService

  ) {
    const _domain = this.route.snapshot.paramMap.get('domain');
    console.log("----------------------------------", _domain);
    if (_domain != null)
      this.requestData.domain = _domain

  }

  ngOnInit(): void {
    this.initPage();
    this.missingproperties = [];
  }

  async initPage() {
    if (!this.service.loggedUser.WWID) {
      await this.dataService.getUserDetails();
    }


    this.requestData.requestorName = this.service.loggedUser.UserName;
    this.requestData.dateOfSubmission = this.formatDate(new Date());
   // this.requestData.estimatedCompletionDate
    this.requestId = this.route.snapshot.paramMap.get('domain')!;

    if (this.requestId) {
      let isNew = this.domains.find(x => x.label == this.requestId);
      if (isNew) {
        this.isEditMode = false;
        this.breadCrumbData[1].name = `New ${this.requestData.domain} Request`
    
      } else {
        this.isEditMode = true;
        this.loadRecordForEdit(this.requestId);
      }

    }


    
  }

  loadRecordForEdit(id: string): void {
    this.isLoading = true;
    let _this = this;
    this.dataService.getRecordById(id).subscribe({
      next: (data: any) => {
        if (data && data.length > 0) {
          this.requestData = data[0];
          this.requestData.dateOfSubmission = this.formatDate(new Date(this.requestData.dateOfSubmission));
          this.requestData.estimatedCompletionDate = this.formatDate(new Date(this.requestData.estimatedCompletionDate));
          this.requestData.estimatedStartDate = this.formatDate(new Date(this.requestData.estimatedStartDate));
          this.breadCrumbData[1].name = `Edit ${this.requestData.domain} Request`
          _this.cdRef.detectChanges();
        }
        this.isLoading = false;
      },
      error: (err: any) => {
        this.isLoading = false;
        console.error('Error loading record:', err)
      }
    });
  }

  saveRecord() {
    this.missingproperties = [];
    let payload = { ...this.requestData };
    if (!this.areAllPropertiesPopulated(payload)) {
      Swal.fire({
        icon: 'warning',
        title: 'Missing Fields',
        text: 'Please fill all the required fields.',
        confirmButtonText: 'OK',
        customClass: {
          popup: 'custom-swal-popup',
          confirmButton: 'custom-confirm-btn'
        },
        buttonsStyling: false
      });
      return;
    }

    if (this.isEditMode) {
      // Logic for updating an existing record
      //payload.Attachments = this.selectedFile ? this.selectedFile.name : (payload.Attachments || null);
      this.isLoading = true;
      this.cdRef.detectChanges();
      payload.attachments = this.selectedFile ? this.selectedFile.name : null;
      this.dataService.updateRecord(payload.requestId, payload, this.selectedFile).subscribe({
        next: () => {
          this.isLoading = false;
          Swal.fire({
            icon: 'success',
            title: 'Saved!',
            text: 'Record saved successfully.',
            confirmButtonText: 'OK',
            customClass: {
              popup: 'custom-swal-popup',
              confirmButton: 'custom-confirm-btn'
            },
            buttonsStyling: false

          }).then(() => {
            this.isLoading = false;
            this.missingproperties = [];
            this.router.navigate(['/intake'], { skipLocationChange: true });
          });
        },
        error: (err: any) => {
          this.isLoading = false;
          Swal.fire({
            icon: 'error',
            title: 'Update Failed',
            text: 'There was a problem saving the record. Please try again.',
            confirmButtonText: 'OK',
            customClass: {
              popup: 'custom-swal-popup',
              confirmButton: 'custom-confirm-btn'
            },
            buttonsStyling: false
          });
        }
      });

    } else {
      //   // Logic for creating a new record
      const newRecord: any = { ...payload, dateOfSubmission: new Date(), status: 'Pending' };
      newRecord.attachments = this.selectedFile ? this.selectedFile.name : null;

      this.dataService.saveIntakeForm(newRecord, this.selectedFile).subscribe({
        next: () => {
          Swal.fire({
            icon: 'success',
            title: 'Saved!',
            text: 'Record saved successfully.',
            confirmButtonText: 'OK',
            customClass: {
              popup: 'custom-swal-popup',
              confirmButton: 'custom-confirm-btn'
            },
            buttonsStyling: false
          }).then(() => {
            this.missingproperties = [];
            //this.router.navigate(['/delivery/intake/intake'], { skipLocationChange: true });
             this.router.navigate(['/intake'], { skipLocationChange: true });
          });
        },
        error: (err) => {
          console.error('Save failed:', err);
          Swal.fire({
            icon: 'error',
            title: 'Save Failed',
            text: 'There was a problem saving the record. Please try again.',
            confirmButtonText: 'OK',
            customClass: {
              popup: 'custom-swal-popup',
              confirmButton: 'custom-confirm-btn'
            },
            buttonsStyling: false
          });
        }
      });
    }


  }


  areAllPropertiesPopulated(obj: any) {

    /// debugger;
    this.mandatoryProps.forEach(item => {
      if (item.datatype === "string") {
        if (!obj[item.name] || obj[item.name].trim() === "") {
          this.missingproperties.push(item.name);
        }
      }
      else if (item.datatype === "date") {
        if (!obj[item.name] || obj[item.name] === null) {
          this.missingproperties.push(item.name);
        }
      }
      else if (item.datatype === "email") {
        if (!obj[item.name] || !this.validateEmail(obj[item.name])) {
          this.missingproperties.push(item.name);
        }
      }
    });

    if (this.requestData.estimatedBudget && this.requestData.estimatedBudget.length > 0) {
      if (!Number.isFinite(Number(this.requestData.estimatedBudget))) {
        this.missingproperties.push("estimatedBudget");
      }
    }
    if (this.missingproperties.length > 0)
      return false;
    return true;

  }

  validateEmail(email: string) {
    return email.match(
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
  };

  cancel() {
    this.router.navigate(['/intake'], { skipLocationChange: true });
  }

  downloadFile() {
     if (this.isEditMode) {
      let filename = this.requestData.attachments;
      let requestId = this.requestId;
      //debugger;
      this.dataService.getSignedURL(filename, requestId).subscribe((response: any) => {
       // debugger;

        const fileUrl = response[0]; // Replace with your actual file URL


        const link = document.createElement('a');
        link.setAttribute('target', '_blank'); // Open in a new tab/window
        link.setAttribute('href', fileUrl);
        link.setAttribute('download', filename);

        document.body.appendChild(link); // Temporarily add to DOM
        link.click(); // Trigger download
        document.body.removeChild(link); // Clean up
      });


    }
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      this.requestData.attachments = file.name;
    }
  }

  removeFile(): void {
    this.selectedFile = null;
    this.requestData.attachments = "";
  }


  formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }
}
