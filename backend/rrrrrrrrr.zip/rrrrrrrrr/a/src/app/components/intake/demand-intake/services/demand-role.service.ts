import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { DemandUser, DemandRole } from '../models/demand-user.model';

@Injectable({
  providedIn: 'root',
})
export class DemandRoleService {
  private currentUserSubject = new BehaviorSubject<DemandUser | null>(null);
  currentUser$ = this.currentUserSubject.asObservable();

  get currentUser(): DemandUser | null {
    return this.currentUserSubject.getValue();
  }

  get role(): DemandRole | null {
    return this.currentUser?.role ?? null;
  }

  get userId(): string {
    return this.currentUser?.id ?? '';
  }

  get userName(): string {
    return this.currentUser?.name ?? '';
  }

  get domain(): string {
    return this.currentUser?.domain ?? '';
  }

  switchUser(user: DemandUser): void {
    this.currentUserSubject.next(user);
  }

  isUser(): boolean {
    return this.role === 'User';
  }

  isScrubMember(): boolean {
    return this.role === 'Scrub_member';
  }

  isCommitteeMember(): boolean {
    return this.role === 'Committee_member';
  }

  // Check if user can edit the intake form (Step 1)
  canEditIntakeForm(requestStatus: string): boolean {
    if (!this.isUser()) return false;
    return ['draft'].includes(requestStatus);
  }
}
