import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { DemandApiService } from '../services/demand-api.service';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-demand-insights',
  standalone: false,
  templateUrl: './demand-insights.html',
  styleUrl: './demand-insights.css',
})
export class DemandInsights implements OnInit {
  isLoading = true;

  // ─── Chart data objects ───
  statusChartData: any;
  domainChartData: any;
  priorityChartData: any;
  typeChartData: any;
  monthlyChartData: any;
  budgetChartData: any;
  domainStatusChartData: any;

  // ─── Chart options ───
  pieOptions: any;
  doughnutOptions: any;
  barOptions: any;
  barHorizontalOptions: any;
  lineBarOptions: any;
  stackedBarOptions: any;

  // ─── Drilldown dialog state ───
  drilldownVisible = false;
  drilldownTitle = '';
  drilldownData: any[] = [];
  drilldownLoading = false;

  // ─── Summary widgets ───
  widgetTotalRequests = 0;
  widgetScrubReview = 0;
  widgetCommitteeReview = 0;
  widgetApproved = 0;
  widgetDeferredRejected = 0;

  // ─── Domain filter for individual charts ───
  domainOptions: { label: string; value: string }[] = [];
  statusDomainFilter = '';
  priorityDomainFilter = '';
  typeDomainFilter = '';
  monthlyDomainFilter = '';

  // ─── Raw data for drilldown mapping ───
  private rawByStatus: any[] = [];
  private rawByDomain: any[] = [];
  private rawByPriority: any[] = [];
  private rawByType: any[] = [];
  private rawByMonth: any[] = [];
  private rawBudgetByDomain: any[] = [];
  private rawByDomainStatus: any[] = [];
  private rawByPriorityDomain: any[] = [];
  private rawByTypeDomain: any[] = [];
  private rawByMonthDomain: any[] = [];

  // ─── Color palettes ───
  private statusColors: Record<string, string> = {
    submitted: '#3B82F6',
    in_review: '#F59E0B',
    clarification_requested: '#EF4444',
    committee_review: '#8B5CF6',
    committee_clarification_requested: '#EC4899',
    approved: '#10B981',
    rejected: '#DC2626',
    deferred: '#6B7280',
    draft: '#94A3B8',
  };

  private domainColors: string[] = ['#EB1700', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899'];
  private priorityColors: Record<string, string> = {
    High: '#EF4444',
    Medium: '#F59E0B',
    Low: '#10B981',
    Unspecified: '#94A3B8',
  };
  private typeColors: string[] = ['#3B82F6', '#8B5CF6', '#EC4899', '#F97316', '#10B981', '#6366F1'];

  constructor(
    private apiService: DemandApiService,
    private router: Router,
     private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.initChartOptions();
    this.loadInsights();
  }

  goBack(): void {
    this.router.navigate(['/intake/demand-intake'], { skipLocationChange: true });
  }

  private initChartOptions(): void {
    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = '#495057';
    const surfaceBorder = '#dee2e6';

    this.pieOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'right', labels: { color: textColor, usePointStyle: true, padding: 16 } },
        tooltip: {
          callbacks: {
            label: (ctx: any) => {
              const total = ctx.dataset.data.reduce((a: number, b: number) => a + b, 0);
              const pct = total ? ((ctx.raw / total) * 100).toFixed(1) : 0;
              return `${ctx.label}: ${ctx.raw} (${pct}%)`;
            },
          },
        },
      },
    };

    this.doughnutOptions = {
      ...this.pieOptions,
      cutout: '55%',
    };

    this.barOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
      },
      scales: {
        x: { ticks: { color: textColor }, grid: { color: surfaceBorder } },
        y: { ticks: { color: textColor, precision: 0 }, grid: { color: surfaceBorder }, beginAtZero: true },
      },
    };

    this.barHorizontalOptions = {
      indexAxis: 'y' as const,
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
      },
      scales: {
        x: { ticks: { color: textColor, precision: 0 }, grid: { color: surfaceBorder }, beginAtZero: true },
        y: { ticks: { color: textColor }, grid: { color: surfaceBorder } },
      },
    };

    this.lineBarOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: textColor, usePointStyle: true } },
      },
      scales: {
        x: { ticks: { color: textColor }, grid: { color: surfaceBorder } },
        y: { ticks: { color: textColor, precision: 0 }, grid: { color: surfaceBorder }, beginAtZero: true },
      },
    };

    this.stackedBarOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: textColor, usePointStyle: true, padding: 12 } },
      },
      scales: {
        x: { stacked: true, ticks: { color: textColor }, grid: { color: surfaceBorder } },
        y: { stacked: true, ticks: { color: textColor, precision: 0 }, grid: { color: surfaceBorder }, beginAtZero: true },
      },
    };
  }

  private loadInsights(): void {
    this.isLoading = true;

    forkJoin({
      byStatus: this.apiService.getInsightsCountByStatus(),
      byDomain: this.apiService.getInsightsCountByDomain(),
      byPriority: this.apiService.getInsightsCountByPriority(),
      byType: this.apiService.getInsightsCountByType(),
      byMonth: this.apiService.getInsightsCountByMonth(),
      budgetByDomain: this.apiService.getInsightsBudgetByDomain(),
      byDomainStatus: this.apiService.getInsightsCountByDomainStatus(),
      byPriorityDomain: this.apiService.getInsightsCountByPriorityDomain(),
      byTypeDomain: this.apiService.getInsightsCountByTypeDomain(),
      byMonthDomain: this.apiService.getInsightsCountByMonthDomain(),
    }).subscribe({
      next: (results) => {
        this.rawByStatus = results.byStatus?.data || [];
        this.rawByDomain = results.byDomain?.data || [];
        this.rawByPriority = results.byPriority?.data || [];
        this.rawByType = results.byType?.data || [];
        this.rawByMonth = results.byMonth?.data || [];
        this.rawBudgetByDomain = results.budgetByDomain?.data || [];
        this.rawByDomainStatus = results.byDomainStatus?.data || [];
        this.rawByPriorityDomain = results.byPriorityDomain?.data || [];
        this.rawByTypeDomain = results.byTypeDomain?.data || [];
        this.rawByMonthDomain = results.byMonthDomain?.data || [];

        // Build domain dropdown options from domain data
        this.domainOptions = [
          { label: 'All Domains', value: '' },
          ...this.rawByDomain.map((d: any) => ({
            label: d.domain || 'Unspecified',
            value: d.domain || '',
          })),
        ];

        this.computeWidgets(this.rawByStatus);

        this.buildStatusChart(this.rawByStatus);
        this.buildDomainChart(this.rawByDomain);
        this.buildPriorityChart(this.rawByPriority);
        this.buildTypeChart(this.rawByType);
        this.buildMonthlyChart(this.rawByMonth);
        this.buildBudgetChart(this.rawBudgetByDomain);
        this.buildDomainStatusChart(this.rawByDomainStatus);
        this.isLoading = false;
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Failed to load insights:', err);
        this.isLoading = false;
      },
    });
  }

  // ─── Widget computation ───

  private getStatusCount(data: any[], statuses: string[]): number {
    return data
      .filter((d) => statuses.includes(d.status))
      .reduce((sum, d) => sum + (Number(d.total) || 0), 0);
  }

  private computeWidgets(statusData: any[]): void {
    const nonDraft = statusData.filter((d) => d.status !== 'draft');
    this.widgetTotalRequests = nonDraft.reduce((sum, d) => sum + (Number(d.total) || 0), 0);
    this.widgetScrubReview = this.getStatusCount(statusData, ['submitted', 'in_review', 'clarification_requested']);
    this.widgetCommitteeReview = this.getStatusCount(statusData, ['committee_review', 'committee_clarification_requested']);
    this.widgetApproved = this.getStatusCount(statusData, ['approved']);
    this.widgetDeferredRejected = this.getStatusCount(statusData, ['deferred', 'rejected']);
  }

  onWidgetClick(type: string): void {
    let params: Record<string, string> = {};
    let title = '';
    switch (type) {
      case 'total':
        title = 'All Requests';
        break;
      case 'scrub':
        params = { status: 'submitted,in_review,clarification_requested' };
        title = 'Scrub Review Requests';
        break;
      case 'committee':
        params = { status: 'committee_review,committee_clarification_requested' };
        title = 'Committee Review Requests';
        break;
      case 'approved':
        params = { status: 'approved' };
        title = 'Approved Requests';
        break;
      case 'deferred_rejected':
        params = { status: 'deferred,rejected' };
        title = 'Deferred / Rejected Requests';
        break;
    }
    this.fetchDrilldown(params, title);
  }

  // ─── Domain filter handlers (client-side, no API calls) ───

  private filterCrossTab(crossTabData: any[], domain: string, groupKey: string): any[] {
    if (!domain) return [];
    const filtered = crossTabData.filter((d) => (d.domain || 'Unspecified') === domain);
    // Aggregate by groupKey in case there are multiple entries
    const map = new Map<string, number>();
    filtered.forEach((d) => {
      const key = d[groupKey] || 'Unspecified';
      map.set(key, (map.get(key) || 0) + Number(d.total || 0));
    });
    return Array.from(map.entries()).map(([key, total]) => ({ [groupKey]: key, total }));
  }

  onStatusDomainChange(domain: string): void {
    this.statusDomainFilter = domain;
    if (!domain) {
      this.buildStatusChart(this.rawByStatus);
    } else {
      const filtered = this.filterCrossTab(this.rawByDomainStatus, domain, 'status');
      this.buildStatusChart(filtered);
    }
    this.cdRef.detectChanges();
  }

  onPriorityDomainChange(domain: string): void {
    this.priorityDomainFilter = domain;
    if (!domain) {
      this.buildPriorityChart(this.rawByPriority);
    } else {
      const filtered = this.filterCrossTab(this.rawByPriorityDomain, domain, 'priority_level');
      this.buildPriorityChart(filtered);
    }
    this.cdRef.detectChanges();
  }

  onTypeDomainChange(domain: string): void {
    this.typeDomainFilter = domain;
    if (!domain) {
      this.buildTypeChart(this.rawByType);
    } else {
      const filtered = this.filterCrossTab(this.rawByTypeDomain, domain, 'type_of_request');
      this.buildTypeChart(filtered);
    }
    this.cdRef.detectChanges();
  }

  onMonthlyDomainChange(domain: string): void {
    this.monthlyDomainFilter = domain;
    if (!domain) {
      this.buildMonthlyChart(this.rawByMonth);
    } else {
      const filtered = this.filterCrossTab(this.rawByMonthDomain, domain, 'month');
      this.buildMonthlyChart(filtered);
    }
    this.cdRef.detectChanges();
  }

  // ─── Chart builders ───

  private formatStatus(status: string): string {
    return (status || '').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  }

  private buildStatusChart(data: any[]): void {
    const labels = data.map((d) => this.formatStatus(d.status));
    const values = data.map((d) => d.total);
    const bgColors = data.map((d) => this.statusColors[d.status] || '#94A3B8');

    this.statusChartData = {
      labels,
      datasets: [{ data: values, backgroundColor: bgColors, hoverBackgroundColor: bgColors }],
    };
  }

  private buildDomainChart(data: any[]): void {
    const labels = data.map((d) => d.domain || 'Unspecified');
    const values = data.map((d) => d.total);
    const bgColors = labels.map((_, i) => this.domainColors[i % this.domainColors.length]);

    this.domainChartData = {
      labels,
      datasets: [{ data: values, backgroundColor: bgColors, hoverBackgroundColor: bgColors }],
    };
  }

  private buildPriorityChart(data: any[]): void {
    const labels = data.map((d) => d.priority_level || 'Unspecified');
    const values = data.map((d) => d.total);
    const bgColors = labels.map((l) => this.priorityColors[l] || '#94A3B8');

    this.priorityChartData = {
      labels,
      datasets: [{ data: values, backgroundColor: bgColors, hoverBackgroundColor: bgColors }],
    };
  }

  private buildTypeChart(data: any[]): void {
    const labels = data.map((d) => d.type_of_request || 'Unspecified');
    const values = data.map((d) => d.total);
    const bgColors = labels.map((_, i) => this.typeColors[i % this.typeColors.length]);

    this.typeChartData = {
      labels,
      datasets: [
        {
          label: 'Requests',
          data: values,
          backgroundColor: bgColors,
          borderColor: bgColors,
          borderWidth: 1,
        },
      ],
    };
  }

  private buildMonthlyChart(data: any[]): void {
    const labels = data.map((d) => d.month);
    const values = data.map((d) => d.total);

    this.monthlyChartData = {
      labels,
      datasets: [
        {
          label: 'Requests',
          data: values,
          backgroundColor: '#3B82F680',
          borderColor: '#3B82F6',
          borderWidth: 2,
          fill: true,
          tension: 0.3,
        },
      ],
    };
  }

  private buildBudgetChart(data: any[]): void {
    const labels = data.map((d) => d.domain || 'Unspecified');
    const values = data.map((d) => Number(d.total_budget || 0));
    const bgColors = labels.map((_, i) => this.domainColors[i % this.domainColors.length]);

    this.budgetChartData = {
      labels,
      datasets: [
        {
          label: 'Budget (USD)',
          data: values,
          backgroundColor: bgColors,
          borderColor: bgColors,
          borderWidth: 1,
        },
      ],
    };
  }

  private buildDomainStatusChart(data: any[]): void {
    const domains = [...new Set(data.map((d) => d.domain || 'Unspecified'))];
    const statuses = [...new Set(data.map((d) => d.status))];

    const datasets = statuses.map((status) => ({
      label: this.formatStatus(status),
      data: domains.map((domain) => {
        const match = data.find(
          (d) => (d.domain || 'Unspecified') === domain && d.status === status
        );
        return match ? match.total : 0;
      }),
      backgroundColor: this.statusColors[status] || '#94A3B8',
    }));

    this.domainStatusChartData = {
      labels: domains,
      datasets,
    };
  }

  // ─── Chart click handlers ───

  onStatusChartClick(event: any): void {
    const idx = event?.element?.index;
    if (idx == null || !this.rawByStatus[idx]) return;
    const status = this.rawByStatus[idx].status;
    this.fetchDrilldown({ status }, `Requests with Status: ${this.formatStatus(status)}`);
  }

  onDomainChartClick(event: any): void {
    const idx = event?.element?.index;
    if (idx == null || !this.rawByDomain[idx]) return;
    const domain = this.rawByDomain[idx].domain || 'Unspecified';
    this.fetchDrilldown({ domain }, `Requests in Domain: ${domain}`);
  }

  onPriorityChartClick(event: any): void {
    const idx = event?.element?.index;
    if (idx == null || !this.rawByPriority[idx]) return;
    const priority = this.rawByPriority[idx].priority_level || 'Unspecified';
    this.fetchDrilldown({ priority_level: priority }, `Requests with Priority: ${priority}`);
  }

  onTypeChartClick(event: any): void {
    const idx = event?.element?.index;
    if (idx == null || !this.rawByType[idx]) return;
    const type = this.rawByType[idx].type_of_request || 'Unspecified';
    this.fetchDrilldown({ type_of_request: type }, `Requests of Type: ${type}`);
  }

  onMonthlyChartClick(event: any): void {
    const idx = event?.element?.index;
    if (idx == null || !this.rawByMonth[idx]) return;
    const month = this.rawByMonth[idx].month;
    this.fetchDrilldown({ month }, `Requests for Month: ${month}`);
  }

  onBudgetChartClick(event: any): void {
    const idx = event?.element?.index;
    if (idx == null || !this.rawBudgetByDomain[idx]) return;
    const domain = this.rawBudgetByDomain[idx].domain || 'Unspecified';
    this.fetchDrilldown({ domain }, `Budget Requests in Domain: ${domain}`);
  }

  onDomainStatusChartClick(event: any): void {
    const datasetIdx = event?.element?.datasetIndex;
    const idx = event?.element?.index;
    if (datasetIdx == null || idx == null) return;

    const domains = [...new Set(this.rawByDomainStatus.map((d) => d.domain || 'Unspecified'))];
    const statuses = [...new Set(this.rawByDomainStatus.map((d) => d.status))];

    const domain = domains[idx];
    const status = statuses[datasetIdx];
    if (!domain || !status) return;

    this.fetchDrilldown(
      { domain: domain, status: status },
      `${domain} – ${this.formatStatus(status)}`
    );
  }

  // ─── Drilldown fetch ───

  private fetchDrilldown(params: Record<string, string>, title: string): void {
    this.drilldownTitle = title;
    this.drilldownData = [];
    this.drilldownLoading = true;
    this.drilldownVisible = true;

    this.apiService.getInsightsDrilldown(params).subscribe({
      next: (res) => {
        this.drilldownData = res?.data || [];
        this.drilldownLoading = false;
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Drilldown fetch error:', err);
        this.drilldownData = [];
        this.drilldownLoading = false;
      },
    });
  }

  // ─── Export to Excel ───

  exportToExcel(): void {
    if (!this.drilldownData || this.drilldownData.length === 0) return;

    const exportRows = this.drilldownData.map((row: any) => ({
      'Project Title': row.project_title || '',
      'Domain': row.domain || '',
      'Status': this.formatStatus(row.status || ''),
      'Priority': row.priority_level || '',
      'Type': row.type_of_request || '',
      'Budget (USD)': row.estimated_budget_usd || '',
      'Requestor': row.requestor_name || '',
      'Department': row.department || '',
      'Created At': row.created_at || '',
    }));

    const ws = XLSX.utils.json_to_sheet(exportRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Drilldown');
    XLSX.writeFile(wb, `Demand_Insights_Drilldown.xlsx`);
  }
}
