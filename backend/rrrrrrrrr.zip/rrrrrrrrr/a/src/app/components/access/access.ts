import { ChangeDetectorRef, Component } from '@angular/core';
import { DataService } from '../../services/data-service';
import { AdminService } from '../../services/admin-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-access',
  standalone: false,
  templateUrl: './access.html',
  styleUrl: './access.css',
})
export class Access {
  isRequestSubmitted: boolean = false;
  reason: string = '';

  selectedDomains: { [key: string]: boolean } = {
    Safety: false,
    Regulatory: false,
    Clinical: false
  };

  selectedRoles: { [key: string]: string } = {
    Safety: '',
    Regulatory: '',
    Clinical: '',
  };

  selectedRoleIds: { [key: string]: string } = {
    Safety: '',
    Regulatory: '',
    Clinical: '',

  };

  isLoading: boolean = false;
  isInitiated: boolean = false;



  constructor(private service: AdminService, private dataService: DataService, private cdRef: ChangeDetectorRef) { }

  async ngOnInit() {
    this.isLoading = true;
    let response = await this.service.getAccessRequesbyUserId(this.service.loggedUser.WWID);
    this.isLoading = false;
    this.isInitiated = true;
    this.cdRef.detectChanges();
    if (response.status && response.data.length > 0) {
      this.isRequestSubmitted = true;
      this.cdRef.detectChanges();
    }

  }


  onDomainChange(event: Event, domain: string, roleid: string): void {
    const isChecked = (event.target as HTMLInputElement).checked;
    this.selectedDomains[domain] = isChecked;
    this.selectedRoles[domain] = 'Analyst';
    this.selectedRoleIds[domain] = roleid;
    // If domain is unchecked, clear its role selection
    if (!isChecked) {
      this.selectedRoles[domain] = '';
      this.selectedRoles[domain] = '';
      this.selectedRoleIds[domain] = '';
    }
  }

  onRoleChange(domain: string, role: string, roleid: string): void {
    this.selectedRoles[domain] = role;
    this.selectedRoleIds[domain] = roleid;
  }

  save(): void {
    const accessRequest = {
      reason: this.reason,
      userid: this.service.loggedUser.WWID,
      domains: Object.keys(this.selectedDomains)
        .filter(domain => this.selectedDomains[domain])
        .map(domain => ({ name: domain, role: this.selectedRoles[domain] || 'No role selected', roleid: this.selectedRoleIds[domain] || 'No role selected' }))
    };


    let message = "";
    if (accessRequest.reason.trim().length == 0) {
      message = "Reason for Access is required! </br>"
    }

    if (accessRequest.domains.length === 0) {
      message += "Please select domain"
    } else {
      let isnorolefound = accessRequest.domains.find(x => x.role == 'No role selected');
      if (isnorolefound) {
        message += "Please selct role for selected domain"
      }
    }

    if (message.length > 0) {
      Swal.fire({
        icon: 'warning',
        title: 'Access Request',
        html: message,
        confirmButtonText: 'OK',
        customClass: {
          popup: 'custom-swal-popup',
          confirmButton: 'custom-confirm-btn'
        }
      });
      return;
    }

    this.isLoading = true;
    this.cdRef.detectChanges(); 
    this.service.saveReuest(accessRequest).subscribe(response => {

      this.isRequestSubmitted = true;
      this.isLoading = false;
      this.cdRef.detectChanges();
    });


    console.log('Access Request Submitted:', accessRequest);

  }
}
