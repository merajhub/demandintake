import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartModule } from 'primeng/chart';

@Component({
  selector: 'app-chart-display',
  standalone: true,
  imports: [CommonModule, ChartModule],
  template: `
    <div class="chart-container">
      <p-chart [type]="chartType" [data]="chartData" [options]="chartOptions"></p-chart>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 400px;
      height: 300px; /* Default height for charts, adjust as needed */
    }
    .chart-container {
      height: 100%;
    }
  `]
})
export class ChartDisplayComponent {
  @Input() chartData: any;
  @Input() chartOptions: any;
  @Input() chartType: 'bar' | 'line' | 'scatter' | 'bubble' | 'pie' | 'doughnut' | 'polarArea' | 'radar' = 'bar';
}
