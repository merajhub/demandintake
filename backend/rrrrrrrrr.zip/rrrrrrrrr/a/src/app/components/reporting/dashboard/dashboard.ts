import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';
import { DataService } from '../../../services/data-service';
import { AdminService } from '../../../services/admin-service';
import { ReleaseStatus } from '../../../models/constants';

// Interfaces for expected aggregated data (these would come from your backend)
interface KpiData {
  totalRequests: number;
  openRequests: number;
  completedRequests: number;
  avgProdCycleTimeDays: number;
}

interface ChartData {
  labels: string[];
  datasets: {
    label?: string;
    data: number[];
    backgroundColor?: string[];
    borderColor?: string[];
    borderWidth?: number;
    fill?: boolean;
    tension?: number;
    hoverBackgroundColor?: string[];
    type?: string;
  }[];
}

interface RequestDetail {
  requestId: number;
  projectTitle: string;
  dateOfSubmission: string;
  typeOfRequest: string;
  priorityLevel: string;
  status: string;
  domain: string;
  devEndDate: string;
  qaEndDate: string;
  prodEndDate: string;
  devActualEndDate: string;
  qaActualEndDate: string;
  proActualEndDate: string;
  releaseStatus: string;
  schedule: string;
  resources: string;
  risks: string;
  scope: string;
  comments: string;
}

@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Dashboard {
  isLoading: boolean = false;

  // KPI Data
  kpiData: KpiData = {
    totalRequests: 0,
    openRequests: 0,
    completedRequests: 0,
    avgProdCycleTimeDays: 0,
  };

  // Chart Data
  requestsByStatusChart: ChartData | undefined;
  requestsByTypeChart: ChartData | undefined;
  requestsByDomainChart: ChartData | undefined;
  requestsByPriorityChart: ChartData | undefined;
  requestsOverTimeChart: ChartData | undefined;
  plannedVsActualChart: ChartData | undefined;
  releaseStatusChart: ChartData | undefined;

  // Chart Options
  chartOptions: any;

  // Detailed Table Data
  allRequests: RequestDetail[] = [];
  filteredRequests: RequestDetail[] = [];
  selectedRequest: RequestDetail | null = null;

  // Filters for the detailed table
  statusFilterOptions: { label: string; value: string }[] = [];
  typeFilterOptions: { label: string; value: string }[] = [];
  domainFilterOptions: { label: string; value: string }[] = [];
  priorityFilterOptions: { label: string; value: string }[] = [];

  selectedStatusFilter: string | null = null;
  selectedTypeFilter: string | null = null;
  selectedDomainFilter: string | null = null;
  selectedPriorityFilter: string | null = null;
  globalFilter: string = '';

  constructor(
    private dataService: DataService,
    private adminService: AdminService,
    private cdRef: ChangeDetectorRef
  ) { }

  async ngOnInit(): Promise<void> {
    await this.loadDashboardData();
    this.setChartOptions();
  }

  async loadDashboardData(): Promise<void> {
    this.isLoading = true;
    this.cdRef.detectChanges();

    // In a real application, you would call your DataService here
    // Example: this.dataService.getDashboardKpis().subscribe(data => this.kpiData = data);
    // For now, we'll use mock data.
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Mock KPI Data
      this.kpiData = {
        totalRequests: 150,
        openRequests: 45,
        completedRequests: 80,
        avgProdCycleTimeDays: 65,
      };

      // Mock Chart Data
      this.requestsByStatusChart = this.generateRequestsByStatusChart();
      this.requestsByTypeChart = this.generateRequestsByTypeChart();
      this.requestsByDomainChart = this.generateRequestsByDomainChart();
      this.requestsByPriorityChart = this.generateRequestsByPriorityChart();
      this.requestsOverTimeChart = this.generateRequestsOverTimeChart();
      this.plannedVsActualChart = this.generatePlannedVsActualChart();
      this.releaseStatusChart = this.generateReleaseStatusChart();

      // Mock Detailed Table Data
      this.allRequests = this.generateMockRequests(this.kpiData.totalRequests);
      this.filteredRequests = [...this.allRequests]; // Initialize filtered with all requests

      // Populate filter options from mock data
      this.statusFilterOptions = this.getUniqueOptions(this.allRequests, 'status');
      this.typeFilterOptions = this.getUniqueOptions(this.allRequests, 'typeOfRequest');
      this.domainFilterOptions = this.getUniqueOptions(this.allRequests, 'domain');
      this.priorityFilterOptions = this.getUniqueOptions(this.allRequests, 'priorityLevel');

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      // Handle error (e.g., show a message to the user)
    } finally {
      this.isLoading = false;
      this.cdRef.detectChanges();
    }
  }

  setChartOptions() {
    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = documentStyle.getPropertyValue('--text-color');
    const textColorSecondary = documentStyle.getPropertyValue('--text-color-secondary');
    const surfaceBorder = documentStyle.getPropertyValue('--surface-border');

    this.chartOptions = {
      plugins: {
        legend: {
          labels: {
            color: textColor,
          },
        },
      },
      scales: {
        x: {
          ticks: {
            color: textColorSecondary,
          },
          grid: {
            color: surfaceBorder,
          },
        },
        y: {
          ticks: {
            color: textColorSecondary,
          },
          grid: {
            color: surfaceBorder,
          },
        },
      },
    };
  }

  // --- Mock Data Generation Functions ---
  private generateRequestsByStatusChart(): ChartData {
    const statuses = ['Open', 'In Progress', 'Completed', 'Rejected', 'On Hold'];
    const data = [25, 30, 40, 5, 10]; // Example counts
    const backgroundColors = [
      '#FF6384', '#36A2EB', '#4CAF50', '#FFCD56', '#9966FF'
    ];
    return {
      labels: statuses,
      datasets: [{
        data: data,
        backgroundColor: backgroundColors,
        hoverBackgroundColor: backgroundColors
      }]
    };
  }

  private generateRequestsByTypeChart(): ChartData {
    const types = ['New Development', 'Enhancement', 'Operation', 'Migration'];
    const data = [40, 20, 30, 10];
    const backgroundColors = [
      '#FFBB80', '#80FFBB', '#BB80FF', '#80BBFF'
    ];
    return {
      labels: types,
      datasets: [{
        label: 'Requests by Type',
        data: data,
        backgroundColor: backgroundColors,
        borderColor: backgroundColors,
        borderWidth: 1
      }]
    };
  }

  private generateRequestsByDomainChart(): ChartData {
    const domains = ['Finance', 'HR', 'IT', 'Marketing', 'Operations'];
    const data = [30, 15, 40, 20, 25];
    const backgroundColors = [
      '#FFD700', '#ADFF2F', '#87CEEB', '#DA70D6', '#FFA07A'
    ];
    return {
      labels: domains,
      datasets: [{
        label: 'Requests by Domain',
        data: data,
        backgroundColor: backgroundColors,
        borderColor: backgroundColors,
        borderWidth: 1
      }]
    };
  }

  private generateRequestsByPriorityChart(): ChartData {
    const priorities = ['High', 'Medium', 'Low', 'Critical'];
    const data = [20, 50, 20, 10];
    const backgroundColors = [
      '#b0adeeff', '#eae4c3ff', '#32CD32', '#e72e2eff'
    ];
    return {
      labels: priorities,
      datasets: [{
        data: data,
        backgroundColor: backgroundColors,
        hoverBackgroundColor: backgroundColors
      }]
    };
  }


  private generateRequestsOverTimeChart(): ChartData {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const data = [10, 12, 15, 18, 20, 22, 19, 25, 23, 28, 30, 27];
    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = documentStyle.getPropertyValue('--text-color');
    return {
      labels: months,
      datasets: [{
        label: 'New Requests',
        data: data,
        fill: false,
        borderColor: [textColor],
        tension: 0.4
      }]
    };
  }


  private generatePlannedVsActualChart(): ChartData {
    const projectTitles = ['Project A', 'Project B', 'Project C', 'Project D', 'Project E'];
    const plannedDev = [20, 30, 25, 35, 28];
    const actualDev = [22, 28, 27, 32, 30];
    const plannedQA = [10, 15, 12, 18, 14];
    const actualQA = [11, 14, 13, 17, 15];
    const plannedProd = [5, 7, 6, 8, 7];
    const actualProd = [6, 8, 7, 9, 8];

    return {
      labels: projectTitles,
      datasets: [
        {
          type: 'bar',
          label: 'Planned Dev (Days)',
          backgroundColor: ['#42A5F5'],
          data: plannedDev
        },
        {
          type: 'bar',
          label: 'Actual Dev (Days)',
          backgroundColor: ['#66BB6A'],
          data: actualDev
        },
        {
          type: 'bar',
          label: 'Planned QA (Days)',
          backgroundColor: ['#FFA726'],
          data: plannedQA
        },
        {
          type: 'bar',
          label: 'Actual QA (Days)',
          backgroundColor: ['#FFCA28'],
          data: actualQA
        },
        {
          type: 'bar',
          label: 'Planned Prod (Days)',
          backgroundColor: ['#AB47BC'],
          data: plannedProd
        },
        {
          type: 'bar',
          label: 'Actual Prod (Days)',
          backgroundColor: ['#BA68C8'],
          data: actualProd
        }
      ]
    };
  }

  private generateReleaseStatusChart(): ChartData {
    const releaseStatuses = Object.values(ReleaseStatus).filter(value => typeof value === 'string');
    const data = [30, 40, 30]; // Example counts for Not Started, In Progress, Completed
    const backgroundColors = [
      '#ffe7aeff', '#93cff7ff', '#9feaa1ff'
    ];
    return {
      labels: releaseStatuses,
      datasets: [{
        data: data,
        backgroundColor: backgroundColors,
        hoverBackgroundColor: backgroundColors
      }]
    };
  }

  private generateMockRequests(count: number): RequestDetail[] {
    const mockRequests: RequestDetail[] = [];
    const statuses = ['Open', 'In Progress', 'Completed', 'Rejected', 'On Hold'];
    const types = ['Operation', 'New Development', 'Enhancement', 'Migration'];
    const domains = ['Finance', 'HR', 'IT', 'Marketing', 'Operations'];
    const priorities = ['High', 'Medium', 'Low', 'Critical'];
    const releaseStatuses = ['Not Started', 'In Progress', 'Completed'];
    const scheduleStatus = ['green', 'amber', 'red'];

    for (let i = 1; i <= count; i++) {
      const status = statuses[Math.floor(Math.random() * statuses.length)];
      const type = types[Math.floor(Math.random() * types.length)];
      const domain = domains[Math.floor(Math.random() * domains.length)];
      const priority = priorities[Math.floor(Math.random() * priorities.length)];
      const releaseStatus = releaseStatuses[Math.floor(Math.random() * releaseStatuses.length)];
      const submissionDate = new Date(2023, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1);

      const devEndDate = new Date(submissionDate);
      devEndDate.setDate(submissionDate.getDate() + 30 + Math.floor(Math.random() * 10));
      const devActualEndDate = new Date(devEndDate);
      devActualEndDate.setDate(devEndDate.getDate() + (Math.random() > 0.5 ? 5 : -5));

      const qaEndDate = new Date(devEndDate);
      qaEndDate.setDate(devEndDate.getDate() + 15 + Math.floor(Math.random() * 5));
      const qaActualEndDate = new Date(qaEndDate);
      qaActualEndDate.setDate(qaEndDate.getDate() + (Math.random() > 0.5 ? 3 : -3));

      const prodEndDate = new Date(qaEndDate);
      prodEndDate.setDate(qaEndDate.getDate() + 7 + Math.floor(Math.random() * 3));
      const proActualEndDate = new Date(prodEndDate);
      proActualEndDate.setDate(prodEndDate.getDate() + (Math.random() > 0.5 ? 2 : -2));

      mockRequests.push({
        requestId: i,
        projectTitle: `Project ${String.fromCharCode(64 + Math.ceil(i / 5))}-${i}`,
        dateOfSubmission: submissionDate.toISOString().split('T')[0],
        typeOfRequest: type,
        priorityLevel: priority,
        status: status,
        domain: domain,
        devEndDate: devEndDate.toISOString().split('T')[0],
        qaEndDate: qaEndDate.toISOString().split('T')[0],
        prodEndDate: prodEndDate.toISOString().split('T')[0],
        devActualEndDate: devActualEndDate.toISOString().split('T')[0],
        qaActualEndDate: qaActualEndDate.toISOString().split('T')[0],
        proActualEndDate: proActualEndDate.toISOString().split('T')[0],
        releaseStatus: releaseStatus,
        schedule: scheduleStatus[Math.floor(Math.random() * scheduleStatus.length)],
        resources: scheduleStatus[Math.floor(Math.random() * scheduleStatus.length)],
        risks: scheduleStatus[Math.floor(Math.random() * scheduleStatus.length)],
        scope: scheduleStatus[Math.floor(Math.random() * scheduleStatus.length)],
        comments: `Comments for Project ${i}`,
      });
    }
    return mockRequests;
  }



  private getUniqueOptions(data: any[], field: string): { label: string; value: string }[] {
    const uniqueValues = [...new Set(data.map(item => item[field]))];
    return uniqueValues.map(value => ({ label: value, value: value }));
  }

  // --- Filtering Logic for Detailed Table ---
  applyFilters(): void {
    this.filteredRequests = this.allRequests.filter(request => {
      const matchesStatus = this.selectedStatusFilter ? request.status === this.selectedStatusFilter : true;
      const matchesType = this.selectedTypeFilter ? request.typeOfRequest === this.selectedTypeFilter : true;
      const matchesDomain = this.selectedDomainFilter ? request.domain === this.selectedDomainFilter : true;
      const matchesPriority = this.selectedPriorityFilter ? request.priorityLevel === this.selectedPriorityFilter : true;
      const matchesGlobal = this.globalFilter ?
        Object.values(request).some(value =>
          String(value).toLowerCase().includes(this.globalFilter.toLowerCase())
        ) : true;

      return matchesStatus && matchesType && matchesDomain && matchesPriority && matchesGlobal;
    });
    this.cdRef.detectChanges();
  }

  clearFilters(): void {
    this.selectedStatusFilter = null;
    this.selectedTypeFilter = null;
    this.selectedDomainFilter = null;
    this.selectedPriorityFilter = null;
    this.globalFilter = '';
    this.applyFilters();
  }

  // Helper to get status color for table cells (similar to tracking-detail.ts)
  getStatusColorClass(statusValue: string): string {
    const status = statusValue.toLowerCase();
    if (status === 'green') return 'status-green';
    if (status === 'amber') return 'status-amber';
    if (status === 'red') return 'status-red';
    return '';
  }

  // Helper to format dates for display
  formatDate(dateString: string): string {
    if (!dateString) return '—';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  }

  // Example of a drill-down action (can navigate to tracking-detail or open a modal)
  onRowSelect(event: any): void {
    // You can implement navigation or open a detailed modal here
    console.log('Selected Request:', this.selectedRequest);
    // Example: this.router.navigate(['/tracking/edit-form', this.selectedRequest?.requestId]);
  }

  onRowUnselect(event: any): void {
    this.selectedRequest = null;
  }

}
