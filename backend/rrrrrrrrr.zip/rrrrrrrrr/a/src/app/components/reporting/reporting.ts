import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data-service';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin-service';

@Component({
  selector: 'app-reporting',
  standalone: false,
  templateUrl: './reporting.html',
  styleUrl: './reporting.css',
})
export class Reporting implements OnInit {
  isLoading = false;
  isHaveAccess: boolean = false;

  pieChartData: any;
  pieChartOptions: any;

  barChartData: any;
  barChartOptions: any;

  doughnutChartData: any;
  doughnutChartOptions: any;
  constructor(private dataService: DataService, public service: AdminService, private router: Router, private cdRef: ChangeDetectorRef) {
  }


  async ngOnInit() {
    this.isHaveAccess = this.service.loggedUser.Roles.length > 0 ? true : false;
    this.cdRef.detectChanges();
    if (this.isHaveAccess) await this.loadReportingData();

  }

  loadReportingData() {
    this.isLoading = true;
    this.dataService.getReportingChartData().subscribe({
      next: (data) => {
        this.isLoading = false;
        let ds1 = data.res.filter((x: any) => x.dataset == 'ds1');
        let ds2 = data.res.filter((x: any) => x.dataset == 'ds2');
        let ds3 = data.res.filter((x: any) => x.dataset == 'ds3');

        if (!ds3.find((x: any) => x.status == 'Pending')) {
          ds3.push({ dataset: "ds3", status: "Pending", records: 0 })
        }
        if (!ds3.find((x: any) => x.status == 'Approved')) {
          ds3.push({ dataset: "ds3", status: "Approved", records: 0 })
        }
        if (!ds3.find((x: any) => x.status == 'Rejected')) {
          ds3.push({ dataset: "ds3", status: "Rejected", records: 0 })
        }


        // Assuming 'data' contains structures suitable for different chart types
        // This is a hypothetical mapping; actual structure depends on backend API response
        this.pieChartData = {
          labels: ds1.map((x: any) => x.domain),
          datasets: [
            {
              data: ds1.map((x: any) => x.records),
              backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
              hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
            }
          ]
        };

        this.pieChartOptions = {
          plugins: {
            legend: {
              labels: {
                usePointStyle: true
              }
            }
          }
        };

        this.barChartData = {
          labels: [...new Set(ds2.map((x: any) => x.domain))],
          datasets: [
            {
              label: 'Not Started',
              backgroundColor: '#42A5F5',
              borderColor: '#1E88E5',
              data: ds2.filter((x: any) => x.status_description == 'Not Started').map((x: any) => x.records) //   data.barDataset1Values || [65, 59, 80, 81, 56, 55, 40]
            },
            {
              label: data.barDataset2Label || 'In Progress',
              backgroundColor: '#9CCC65',
              borderColor: '#7CB342',
              data: ds2.filter((x: any) => x.status_description == 'In Progress').map((x: any) => x.records)// || [28, 48, 40, 19, 86, 27, 90]
            },
            {
              label: data.barDataset2Label || 'Completed',
              backgroundColor: '#da3a67ff',
              borderColor: '#751b2fff',
              data: ds2.filter((x: any) => x.status_description == 'Completed').map((x: any) => x.records) || [28, 48, 40, 19, 86, 27, 90]
            }

          ]
        };


        this.barChartOptions = {
          plugins: {
            legend: {
              labels: {
                usePointStyle: true
              }
            }
          },
          scales: {
            x: {
              grid: {
                display: false
              }
            },
            y: {
              beginAtZero: true,
              grid: {
                display: true
              }
            }
          }
        };

        this.doughnutChartData = {
          labels: ds3.map((x: any) => x.status),
          datasets: [
            {
              data: ds3.map((x: any) => x.records),
              backgroundColor: data.doughnutColors || ['#ff6363ff', '#150559ff', '#fbff1fff'],
              hoverBackgroundColor: data.doughnutColors || ['#FF6384', '#36A2EB', '#FFCE56']
            }
          ]
        };

        this.doughnutChartOptions = {
          plugins: {
            legend: {
              labels: {
                usePointStyle: true
              }
            }
          }
        };

        this.cdRef.detectChanges(); // Manually trigger change detection if data updates asynchronously
      },
      error: (err) => {
        console.error('Error fetching reporting chart data:', err);
        this.initializeDefaultChartData(); // Fallback to default data on error
      }
    });
  }

  // Method to initialize default data if API call fails or for initial state
  initializeDefaultChartData() {
    // Default Pie Chart Data
    this.pieChartData = {
      labels: ['Red', 'Blue', 'Yellow'],
      datasets: [
        {
          data: [300, 50, 100],
          backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
          hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
        }
      ]
    };

    this.pieChartOptions = {
      plugins: {
        legend: {
          labels: {
            usePointStyle: true
          }
        }
      }
    };

    // Default Bar Chart Data
    this.barChartData = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [
        {
          label: 'My First dataset',
          backgroundColor: '#42A5F5',
          borderColor: '#1E88E5',
          data: [65, 59, 80, 81, 56, 55, 40]
        },
        {
          label: 'My Second dataset',
          backgroundColor: '#9CCC65',
          borderColor: '#7CB342',
          data: [28, 48, 40, 19, 86, 27, 90]
        }
      ]
    };

    this.barChartOptions = {
      plugins: {
        legend: {
          labels: {
            usePointStyle: true
          }
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          }
        },
        y: {
          beginAtZero: true,
          grid: {
            display: true
          }
        }
      }
    };

    // Default Doughnut Chart Data
    this.doughnutChartData = {
      labels: ['A', 'B', 'C'],
      datasets: [
        {
          data: [540, 325, 700],
          backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
          hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
        }
      ]
    };

    this.doughnutChartOptions = {
      plugins: {
        legend: {
          labels: {
            usePointStyle: true
          }
        }
      }
    };
  }
}


