import { ChangeDetectorRef, Component, signal } from '@angular/core';
import { Router } from '@angular/router';
import { MenuService } from './services/menu';
import { DataService } from './services/data-service';
import { Location } from '@angular/common'
import { AdminService } from './services/admin-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: false,
  styleUrl: './app.css',
  providers: [Location]
})
export class App {
  protected readonly title = signal('Client');
  selectedFeature: string = 'home';
  isLoading: boolean = false;
  isloggedIn: boolean = false;
  


  constructor(
    private router: Router,
    private menuService: MenuService,
    public dataService: DataService,
    private cdRef: ChangeDetectorRef,
    private location: Location,
    public adminService: AdminService
  ) { }


  async ngOnInit() {

    await this.initalizePage();
  }


  async initalizePage() {
    this.isLoading = true;
    await this.dataService.getUserDetails();
    this.isLoading = false;
    this.isloggedIn = true;
    this.cdRef.detectChanges();
    
    this.location.go("/");
  }

  selectFeature(feature: string): void {
    this.selectedFeature = feature;

    this.router.navigate([`/${feature}`], { skipLocationChange: true });
  }

}
