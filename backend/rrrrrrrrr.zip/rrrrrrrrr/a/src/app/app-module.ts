import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { provideHttpClient } from '@angular/common/http';
import { TableModule } from 'primeng/table';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { AccordionModule } from 'primeng/accordion';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';
import { CardModule } from 'primeng/card';
import { MenubarModule } from 'primeng/menubar';
import { TooltipModule } from 'primeng/tooltip';
import { ChartModule } from 'primeng/chart';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Intake } from './components/intake/intake';
import { Home } from './components/home/home';
import { IntakeDetails } from './components/intake/intake-details/intake-details';
import { providePrimeNG } from 'primeng/config';

import Aura from '@primeuix/themes/aura';
import { GccGrid } from './utils/gcc-grid/gcc-grid';
import { Tracking } from './components/tracking/tracking';
import { TrackingDetail } from './components/tracking/tracking-detail/tracking-detail';
import { EditTracking } from './components/tracking/edit-tracking/edit-tracking';
import { GccBreadCrumb } from './utils/gcc-bread-crumb/gcc-bread-crumb';
import { Reporting } from './components/reporting/reporting';
import { ChartDisplayComponent } from './components/reporting/chart-display';
import { Access } from './components/access/access';
import { Admin } from './components/admin/admin';
import { Dashboard } from './components/reporting/dashboard/dashboard'; // Import the standalone component
import { DemandIntake } from './components/intake/demand-intake/demand-intake';
import { DemandIntakeForm } from './components/intake/demand-intake/demand-intake-form/demand-intake-form';
import { DemandScrubReview } from './components/intake/demand-intake/demand-scrub-review/demand-scrub-review';
import { DemandCommitteeReview } from './components/intake/demand-intake/demand-committee-review/demand-committee-review';
import { DemandApproved } from './components/intake/demand-intake/demand-approved/demand-approved';
import { DemandRequestList } from './components/intake/demand-intake/demand-request-list/demand-request-list';
import { DemandInsights } from './components/intake/demand-intake/demand-insights/demand-insights';

import { DemandTrackingList } from './components/tracking/demand-tracking/demand-tracking-list/demand-tracking-list';
import { DemandTrackingForm } from './components/tracking/demand-tracking/demand-tracking-form/demand-tracking-form';
import { DemandTrackingInsightsComponent } from './components/tracking/demand-tracking/demand-tracking-insights/demand-tracking-insights.component';

@NgModule({
  declarations: [
    App,
    Intake,
    Home,
    IntakeDetails,
    GccGrid,
    Tracking,
    TrackingDetail,
    EditTracking,
    GccBreadCrumb,
    Reporting,
    Access,
    Admin,
    Dashboard,
    DemandIntake,
    DemandIntakeForm,
    DemandScrubReview,
    DemandCommitteeReview,
    DemandApproved,
    DemandRequestList,
    DemandInsights,
  DemandTrackingList,
  DemandTrackingForm,
  DemandTrackingInsightsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    TableModule,
    DatePickerModule,
    DialogModule,
    ButtonModule,
    AccordionModule,
    InputTextModule,
    SelectModule,
    TextareaModule,
    CardModule,
    MenubarModule,
    TooltipModule,
    ChartModule,
    ProgressSpinnerModule,
    ToastModule,
    ChartDisplayComponent // Standalone components are imported, not declared
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideHttpClient(),
    MessageService,
    providePrimeNG({
            theme: {
                preset: Aura,
                options: {
                    prefix: 'p',
                    darkModeSelector: 'system',
                    cssLayer: false
                }
            }
        })
  ],
  bootstrap: [App]
})
export class AppModule { }
