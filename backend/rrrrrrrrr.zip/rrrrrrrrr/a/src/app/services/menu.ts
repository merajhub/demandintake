import { Injectable } from '@angular/core';
import { MENU_ITEMS, MenuItem, MenuItemChild } from '../data/menu-items';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
   private menuItems: MenuItem[] = MENU_ITEMS;

  getMenuItems(): MenuItem[] {
    return this.menuItems;
  }

  getMenuByKey(menuKey: string): MenuItem | undefined {
    return this.menuItems.find(item => item.key === menuKey);
  }

  getSubmenuItemsWithChildren(menuKey: string): MenuItemChild[] {
    const menuItem = this.getMenuByKey(menuKey);
    return menuItem?.children.filter(child => child.children && child.children.length > 0) || [];
  }

  getSubmenuItemsWithoutChildren(menuKey: string): MenuItemChild[] {
    const menuItem = this.getMenuByKey(menuKey);
    return menuItem?.children.filter(child => !child.children || child.children.length === 0) || [];
  }

  hasChildren(menuKey: string): boolean {
    const menuItem = this.getMenuByKey(menuKey);
    return menuItem?.children && menuItem.children.length > 0 || false;
  }

  hasItemsWithChildren(menuKey: string): boolean {
    return this.getSubmenuItemsWithChildren(menuKey).length > 0;
  }

  hasItemsWithoutChildren(menuKey: string): boolean {
    return this.getSubmenuItemsWithoutChildren(menuKey).length > 0;
  }
}