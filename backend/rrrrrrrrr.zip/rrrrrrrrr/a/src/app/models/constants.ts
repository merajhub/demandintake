export const IntakeColumns = [
  'formattedRequestId',
  'domain',
  'projectTitle',
  'requestorName',
  'dateOfSubmission',
  'typeOfRequest',
  'priorityLevel',
  'status'
];

export const IntakeColumnInfo = [
  { Name: 'formattedRequestId', DisplayName: 'Request ID' },
  { Name: 'domain', DisplayName: 'Domain' },
  { Name: 'projectTitle', DisplayName: 'Project Title' },
  { Name: 'requestorName', DisplayName: 'Requestor Name' },
  { Name: 'dateOfSubmission', DisplayName: 'Date of Submission' },
  { Name: 'typeOfRequest', DisplayName: 'Type of Request' },
  { Name: 'priorityLevel', DisplayName: 'Priority Level' },
  { Name: 'status', DisplayName: 'Status' }
];


export const TrackingColumnInfo = [
  { Name: 'formattedRequestId', DisplayName: 'Request ID', Width: '5' },
  { Name: 'projectTitle', DisplayName: 'Project Title', Width: '15' },
  { Name: 'pm_scrum_master', DisplayName: 'PM/Scrum Master', Width: '10' },
  { Name: 'scope', DisplayName: 'Scope', ProjStatus: true, Width: '5' },
  { Name: 'schedule', DisplayName: 'Schedule', ProjStatus: true, Width: '5' },
  { Name: 'resources', DisplayName: 'Resources', ProjStatus: true, Width: '5' },
  { Name: 'risks', DisplayName: 'Risks', ProjStatus: true, Width: '5' },
  { Name: 'devEndDate', DisplayName: 'Dev', ProjStatus: true, Width: '5' },
  { Name: 'qaEndDate', DisplayName: 'QA', ProjStatus: true, Width: '5' },
  { Name: 'prodEndDate', DisplayName: 'PROD', ProjStatus: true, Width: '5' },
  { Name: 'comments', DisplayName: 'Comments', Width: '20' }
];


export const TrackingColsInfo = [
  'formattedRequestId',
  'projectTitle',
  'pm_scrum_master',
  'schedule',
  'resources',
  'risks',
  'scope',
  'devEndDate',
  'qaEndDate',
  'prodEndDate',
  
  'comments',
];




export const TrackingAuditColumnInfo = [
  { Name: 'scope', DisplayName: 'Scope', ProjStatus: true, Width: '5', IsAuditCol: true },
  { Name: 'schedule', DisplayName: 'Schedule', ProjStatus: true, Width: '5', IsAuditCol: true },
  { Name: 'resources', DisplayName: 'Resources', ProjStatus: true, Width: '5', IsAuditCol: true },
  { Name: 'risks', DisplayName: 'Risks', ProjStatus: true, Width: '5', IsAuditCol: true },
  { Name: 'devEndDate', DisplayName: 'Dev', Width: '5', IsAuditCol: true },
  { Name: 'qaEndDate', DisplayName: 'QA', Width: '5', IsAuditCol: true },
  { Name: 'prodEndDate', DisplayName: 'PROD', Width: '5', IsAuditCol: true },

  { Name: 'devActualEndDate', DisplayName: 'Actual Dev', Width: '5', IsAuditCol: true },
  { Name: 'qaActualEndDate', DisplayName: 'Actual QA', Width: '5', IsAuditCol: true },
  { Name: 'proActualEndDate', DisplayName: 'Actual PROD', Width: '5', IsAuditCol: true },
  { Name: 'comments', DisplayName: 'Comments', Width: '30', IsAuditCol: true },
  { Name: 'user_name', DisplayName: 'User', Width: '10' },
  { Name: 'created_date', DisplayName: 'Date', Width: '15' }
];


export const TrackingAuditColsInfo = [

  'schedule',
  'resources',
  'risks',
  'scope',
  'devEndDate',
  'qaEndDate',
  'prodEndDate',
  'comments',
  'user_name',
  'created_date',
  'devActualEndDate',
  'qaActualEndDate',
  'proActualEndDate',
];


export enum StatusColor {
  green = 1,
  amber = 2,
  red = 3
}


export enum ReleaseStatus {
  'Not Started' = 1,
  'In Progress' = 2,
  'Completed' = 3
}