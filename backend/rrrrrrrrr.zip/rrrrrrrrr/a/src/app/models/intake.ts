export interface INTAKE {
    requestId: string;
    projectTitle: string;
    requestorName: string;
    department: string;
    contactEmail: string;
    contactPhone: string;
    dateOfSubmission: Date | null;
    platform: string;
    complianceRequirements: string;
    typeOfRequest: string;
    projectDescription: string;
    projectGoals: string;
    businessProblem: string;
    expectedOutcome: string;
    estimatedCompletionDate: Date | null;
    estimatedStartDate: Date | null;
    resourceRequirements: string;
    targetUsers: string;
    priorityLevel: string;
    dependencies: string;
    status: string;
    reviewNotes: string;
    additionalNotes: string;
    approvalSignoff: string;
    attachments: string;
    technologyPreference: string;
    estimatedBudget: string;
    stakeholders: string;
    risks: string;
    requestor_wwid: string;
    domain: string;
    requestorEmail: string;

}