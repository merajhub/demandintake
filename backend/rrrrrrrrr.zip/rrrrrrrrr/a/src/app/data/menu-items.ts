export interface MenuItemChild {
  name: string;
  link: string;
  key: string;
  children?: MenuItemChild[];
}

export interface MenuItem {
  name: string;
  link: string;
  key: string;
  message: string;
  children: MenuItemChild[];
}

export const MENU_ITEMS: MenuItem[] = [
  {
    name: 'Home',
    link: '/home',
    key: 'home',
    message: "",
    "children": []
  },
  {
    name: 'People',
    link: '/dashboard',
    key: 'dashboard',
    message: 'Manage your team members, track employee profiles, performance metrics, and foster collaboration across your organization.',
    children: [
      {
        name: 'Engineering Pool',
        link: '/dashboard/overview',
        key: 'overview',
        children: [
          { name: 'Full Stack', link: '/people/engineering/full-stack', key: 'summary' },
          { name: 'Data Science', link: '/people/engineering//data-science', key: 'metrics' },
          { name: 'Project Management', link: '/people/engineering/project-management', key: 'projects' },
          { name: 'Platform Management', link: '/people/engineering/platform-management', key: 'platform' }
        ]
      },
      {
        name: 'Functional Pool',
        link: '/people/functional',
        key: 'analytics',
        children: [
          { name: 'Veeva', link: '/people/functional/veeva', key: 'veeva' },
          { name: 'Pharma Covigilance', link: '/people/functional/pharma-covigilance', key: 'pharma-covigilance' },
          { name: 'Clinical Trials', link: '/people/functional/clinical-trials', key: 'clinical-trials' },
          { name: 'Regulatory Affairs', link: '/people/functional/regulatory-affairs', key: 'regulatory-affairs' }
        ]
      }

    ]
  },
  {
    name: 'Delivery',
    link: '/resources',
    key: 'delivery',
    message: 'Track project deliverables, manage timelines, monitor delivery status, and ensure successful project completion.',
    children: [
      {
        name: 'Intake Management',
        link: '/resources/rooms',
        key: 'rooms',
        children: [
          { name: 'Development', link: '/delivery/intake/intake', key: 'usage' }
          // { name: 'Enhancement', link: '/delivery/intake/intake', key: 'performance' },
          // { name: 'Operations', link: '/delivery/intake/intake', key: 'trends' }
        ]
      },
      {
        name: 'Tracking',
        link: '/resources/desks',
        key: 'desks'
      },
      {
        name: 'Reporting',
        link: '/resources/equipment',
        key: 'equipment'
      }
    ]
  },
  {
    name: 'Innovation',
    link: '/resources',
    key: 'innovation',
    message: 'Foster creative thinking, manage innovation projects, track new ideas, and drive continuous improvement initiatives.',
    children: [
      {
        name: 'POCs',
        link: '/innovation/pocs',
        key: 'pocs'
      },
      {
        name: 'Innovation Management',
        link: 'innovation/ideas',
        key: 'desks'
      },
      {
        name: 'IP Creation',
        link: '/innovation/ip',
        key: 'equipment'
      }
    ]
  },
  {
    name: 'Talent Eco System',
    link: '/resources',
    key: 'talent',
    message: 'Manage your office resources - Book meeting rooms, reserve desks, and manage equipment efficiently.',
    children: [
      {
        name: 'Vendor Management',
        link: '/talent-ecosystem/vendor-management',
        key: 'vendor-management'
      },
      {
        name: 'University Collaboration',
        link: '/talent-ecosystem/university-collaboration',
        key: 'university-collaboration'
      }
    ]
  },
  {
    name: 'Organization',
    link: '/organization',
    key: 'organization',
    message: "",
    "children": []
  }
];