import { NgModule } from '@angular/core';
import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { Home } from './components/home/home';
import { Intake } from './components/intake/intake';
import { IntakeDetails } from './components/intake/intake-details/intake-details';
import { Tracking } from './components/tracking/tracking';
import { TrackingDetail } from './components/tracking/tracking-detail/tracking-detail';
import { EditTracking } from './components/tracking/edit-tracking/edit-tracking';
import { Reporting } from './components/reporting/reporting';
import { Admin } from './components/admin/admin';
import { Dashboard } from './components/reporting/dashboard/dashboard';
import { DemandIntake } from './components/intake/demand-intake/demand-intake';
import { DemandRequestList } from './components/intake/demand-intake/demand-request-list/demand-request-list';
import { DemandInsights } from './components/intake/demand-intake/demand-insights/demand-insights';

import { DemandTrackingList } from './components/tracking/demand-tracking/demand-tracking-list/demand-tracking-list';
import { DemandTrackingForm } from './components/tracking/demand-tracking/demand-tracking-form/demand-tracking-form';
import { DemandTrackingInsightsComponent } from './components/tracking/demand-tracking/demand-tracking-insights/demand-tracking-insights.component';

const routes: Routes = [
  { path: 'home', component: Home },
  { path: 'intake', component: DemandRequestList },
  { path: 'intake/intake-form/:domain', component: IntakeDetails },
  { path: 'intake/demand-intake', component: DemandRequestList },
  { path: 'intake/demand-intake/insights', component: DemandInsights },
  { path: 'intake/demand-intake/new', component: DemandIntake },
  { path: 'intake/demand-intake/:id', component: DemandIntake },
  { path: 'tracking', component: DemandTrackingList },
  { path: 'tracking/insights', component: DemandTrackingInsightsComponent },
  { path: 'tracking/demand-tracking/:requestId', component: DemandTrackingForm },
  { path: 'tracking/tracking-form/:domain', component: TrackingDetail },
  { path: 'tracking/edit-form/:id', component: EditTracking },
  { path: 'reporting', component: Dashboard },
  { path: 'admin', component: Admin },
  { path: '', component: Home, pathMatch: 'full' },
  { path: '**', component: Home } // Wildcard route for a 404 page or redirect
];


const routerOptions: ExtraOptions = {
  // This will trigger a full navigation cycle (including ngOnInit)
  // even if only the URL parameters change
  onSameUrlNavigation: 'reload'
}

@NgModule({
  // imports: [RouterModule.forRoot(routes )],
  imports: [RouterModule.forRoot(routes, routerOptions)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
