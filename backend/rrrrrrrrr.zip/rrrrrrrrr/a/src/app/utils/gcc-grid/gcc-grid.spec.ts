import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GccGrid } from './gcc-grid';

describe('GccGrid', () => {
  let component: GccGrid;
  let fixture: ComponentFixture<GccGrid>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GccGrid]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GccGrid);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
