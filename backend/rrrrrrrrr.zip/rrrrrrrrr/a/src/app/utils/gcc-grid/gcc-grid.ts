import { Component, EventEmitter, Input, Output } from '@angular/core';

interface PageEvent {
  first: number;
  rows: number;
  page: number;
  pageCount: number;
}

@Component({
  selector: 'app-gcc-grid',
  standalone: false,
  templateUrl: './gcc-grid.html',
  styleUrl: './gcc-grid.css',
})
export class GccGrid {
  @Input() cpdData: any[] = []
  @Input() cpdCols: any[] = [];
  @Input() filterCols: any[] = [];
  @Input() isPagination: boolean = true;
  @Input() dataKey: string = ''; 
  @Input() tblSize: any = 'small';
  @Output() onTblRowSelect = new EventEmitter<any>();
  @Output() onTblRowUnSelect = new EventEmitter<any>();
  @Output() onTblRowDblClick = new EventEmitter<any>();



  tblData: any[] = [];

  products!: any[];
  selectedProduct!: any;

  first: number = 0;
  rows: number = 10;
  totalRows = 0;

  ngOnInit(): void {
    this.totalRows = this.cpdData.length;
  }

  onPageChange(event: PageEvent) {
    this.first = event.first;
    this.rows = event.rows;
  }

  onRowSelect(evt: any) {
    //debugger;
    // let obj = {
    //   rowData: row,
    //   colName: colname
    // }
    this.onTblRowSelect.emit(evt.data);
  }

  handleRowUnselect(evt: any) {
    this.onTblRowUnSelect.emit(evt.data);
  }

  onRowDblClick(row: any) {
    //alert(row.domain)
    this.onTblRowDblClick.emit(row);
  }


  getCellClass(col: any, index: number) {
    let classes = ""
    if (col.ProjStatus) {
      classes = "center_content"
    }

    if (col.IsAuditCol && index < this.cpdData.length-1 ) {
    
      if(this.cpdData[index + 1][col.Name] != this.cpdData[index][col.Name]){
        classes += " highlight_background"
      
      }
    }
    return classes
  }



}
