import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-gcc-bread-crumb',
  standalone: false,
  templateUrl: './gcc-bread-crumb.html',
  styleUrl: './gcc-bread-crumb.css',
})
export class GccBreadCrumb {
  @Input () breadCrumbsData:any;
  constructor() { }

  ngOnInit(): void {
  }
}
