import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GccBreadCrumb } from './gcc-bread-crumb';

describe('GccBreadCrumb', () => {
  let component: GccBreadCrumb;
  let fixture: ComponentFixture<GccBreadCrumb>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GccBreadCrumb]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GccBreadCrumb);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
